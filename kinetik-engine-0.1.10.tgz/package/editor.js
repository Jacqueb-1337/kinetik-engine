﻿// editor.js - Sinister Level Editor
// Runs inside Electron via editor.html (importmap â†’ node_modules/three)
import * as THREE from 'three';
import { OrbitControls }    from 'three/examples/jsm/controls/OrbitControls';
import { TransformControls } from 'three/examples/jsm/controls/TransformControls';
import { GLTFLoader }        from 'three/examples/jsm/loaders/GLTFLoader';
import { GLTFExporter }      from 'three/examples/jsm/exporters/GLTFExporter';
import { FBXLoader }         from 'three/examples/jsm/loaders/FBXLoader';
import { OBJLoader }         from 'three/examples/jsm/loaders/OBJLoader';
import { MTLLoader }         from 'three/examples/jsm/loaders/MTLLoader';
import { Evaluator, Brush, SUBTRACTION } from 'three-bvh-csg';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry';

let _highlightedMesh = null;
let _highlightSavedEmissive = null;
let _highlightedRow = null;

function _normalizeLinks(arr) {
  if (!arr?.length) return arr;
  return arr.map(l => typeof l === 'number' ? { id: l } : l);
}

function _edKeyDisplay(code) {
  if (!code) return '—';
  if (code === 'MouseLeft') return 'LMB';
  if (code === 'MouseRight') return 'RMB';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code === 'Space') return 'SPACE';
  if (code === 'ShiftLeft' || code === 'ShiftRight') return 'SHIFT';
  if (code === 'ControlLeft' || code === 'ControlRight') return 'CTRL';
  if (code === 'AltLeft' || code === 'AltRight') return 'ALT';
  return code;
}

function _setMeshHighlight(mesh, row) {
  if (_highlightedMesh && _highlightSavedEmissive) {
    const mats = Array.isArray(_highlightedMesh.material) ? _highlightedMesh.material : [_highlightedMesh.material];
    mats.forEach((m, i) => { if (m.emissive && _highlightSavedEmissive[i]) m.emissive.copy(_highlightSavedEmissive[i]); });
  }
  if (_highlightedRow) _highlightedRow.style.background = '#0d0d20';
  _highlightedMesh = null;
  _highlightSavedEmissive = null;
  _highlightedRow = null;
  if (!mesh) return;
  const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
  _highlightSavedEmissive = mats.map(m => m.emissive ? m.emissive.clone() : null);
  mats.forEach(m => { if (m.emissive) m.emissive.set(0x004488); });
  _highlightedMesh = mesh;
  _highlightedRow = row;
  if (row) row.style.background = '#1a2a4a';
}

// â”€â”€â”€ Constants â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const RAD = Math.PI / 180;
const DEG = 180 / Math.PI;
const ASSET_ROOT = '../';


// â”€â”€â”€ State â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const E = {
  scene:     null,
  camera:    null,
  renderer:  null,
  orbit:     null,
  transform: null,

  // Current level
  levelName:   null,          // null until a level is opened/created
  isDirty:     false,

  // Object tracking
  placedGroup:   null,        // Group containing only user-placed objects
  gridHelper:    null,
  colHelpers:    [],           // BoxHelper list for collision wireframes

  selected:      null,        // currently selected placed object (null if ref/none)
  placingType:   null,        // 'box'|'sphere'|'cylinder'|'plane'|'model:<path>' while placing
  ghostMesh:     null,        // semi-transparent placement preview
  floorPlane:    null,        // invisible raycasting floor

  importedModels: [],         // [{name, path}]
  importedActors: [],         // [{name, path}]
  availableTextures: [],      // ['floor', 'wall', 'ceiling', ...]
  texCache:       new Map(),  // texName -> THREE.Texture (editor-side cache)
  groups:         {},         // { gid: { name, ids: Set } }
  groupCollapsed: {},         // { gid: bool } — true = collapsed in panel
  levelVars:      {},         // { "lv_name": { type: "number"|"bool"|"string", initial: value } }
  sceneScripts:   [],         // top-level scene script module paths
  nextId:         1,
  undoStack:      [],
  redoStack:      [],

  // toolbar toggles
  showGrid:       true,
  showColliders:  false,
  previewLighting: false,   // when true, simulate game lighting instead of editor lighting

  // camera WASD pan
  keys:          {},
  panSpeed:      15,           // units/sec
  lastTime:      0,

  // dragging state
  wasDragging:   false,

  // group transform pivot
  groupPivot:         null,
  groupPivotMembers:  [],
  activeGroupGid:     null,  // gid of current group being transformed

  // CSG cut mode
  cutMode:       false,
  cutSource:     null,   // the cutter mesh (selected when Cut was initiated)
  csgEvaluator:  null,   // lazy-created Evaluator instance

  // Link pick mode
  linkMode:      false,
  linkSource:    null,   // the object whose links we're adding to

  // Pivot pick mode
  pivotMode:     false,
  pivotSource:   null,   // the object whose pivot we're setting

  // Rope anchor attach mode
  ropeAnchorMode:   null,   // null | 'A' | 'B'
  ropeAnchorSource: null,   // the rope object being edited

  // Per-face texture selection
  selectedFace:      null,   // null = 'all', 0-5 = specific box face
  facePickMode:      false,
  faceHighlightMesh: null,   // THREE.Mesh child of selected object
  uvEditorImage:     null,   // Image loaded for UV canvas preview

  // Face mode
  faceModeActive:    false,
  faceModeGroups:    [],     // computed coplanar groups for the active object
  faceModeHovered:   -1,     // index of group under cursor
  faceModeSelected:  -1,     // index of selected group (-1 = none)
  faceHoverMesh:     null,   // scene-level hover highlight mesh
  faceSelectMesh:    null,   // scene-level selected highlight mesh

  _stateDragSrc: undefined,  // index of state item being dragged for reorder

  // Model / bone editor
  _modelEditorObj:  null,   // object open in model editor
  _modelEditorBone: null,   // currently selected bone id
  _boneMarkerGroup: null,   // THREE.Group in scene containing bone marker spheres
  _boneMarkers:     new Map(), // boneId → THREE.Mesh (world-space bone gizmo target)
  _stateExpanded:   new Set(), // keys 'edId_idx' of states that are explicitly expanded
  fogDensity:       null,      // number or null (null = use game default)
};

// â”€â”€â”€ Init â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
async function init() {
  // Scene
  E.scene = new THREE.Scene();
  E.scene.background = new THREE.Color(0x12121e);

  // Camera - start above and looking at origin (matches game room)
  E.camera = new THREE.PerspectiveCamera(60, viewportAspect(), 0.1, 500);
  E.camera.position.set(10, 18, 22);
  E.camera.lookAt(0, 3, 0);

  // Renderer
  const viewport = document.getElementById('viewport');
  E.renderer = new THREE.WebGLRenderer({ antialias: true });
  E.renderer.setPixelRatio(devicePixelRatio);
  E.renderer.outputColorSpace = THREE.SRGBColorSpace;
  E.renderer.shadowMap.enabled = true;
  E.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  resizeRenderer();
  viewport.appendChild(E.renderer.domElement);

  // Orbit controls - right-drag to orbit, middle to zoom
  E.orbit = new OrbitControls(E.camera, E.renderer.domElement);
  E.orbit.enableDamping   = true;
  E.orbit.dampingFactor   = 0.08;
  E.orbit.mouseButtons    = { LEFT: null, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.ROTATE };
  E.orbit.target.set(0, 3, 0);
  E.orbit.update();

  // Transform controls
  E.transform = new TransformControls(E.camera, E.renderer.domElement);
  E.transform.setMode('translate');
  E.transform.setTranslationSnap(null); // free by default; Ctrl = grid snap
  E.transform.setRotationSnap(THREE.MathUtils.degToRad(5));
  E.scene.add(E.transform);
  E.transform.addEventListener('change', () => {
    if (E._modelEditorBone) { _onBoneMarkerMoved(); }
    // If rotating around a custom pivot, keep pivot point fixed in world space.
    // NOTE: updateMatrixWorld must be called first — TC fires 'change' before updating matrixWorld.
    if (E._pivotDragStart && E.selected?.userData.pivotOffset && E.transform.mode === 'rotate') {
      const obj = E.selected;
      obj.updateMatrixWorld(true);   // force-flush the new quaternion/position into matrixWorld
      const localOffset = new THREE.Vector3().fromArray(obj.userData.pivotOffset);
      const currentPivotWorld = localOffset.clone().applyMatrix4(obj.matrixWorld);
      const diff = E._pivotDragStart.clone().sub(currentPivotWorld);
      obj.position.add(diff);
      obj.updateMatrixWorld(true);
    }
    // Alt held during translate drag → snap selected face to nearest primitive face
    if (E.transform.mode === 'translate' && (E.groupPivot || E.selected) &&
        (E.keys['AltLeft'] || E.keys['AltRight'])) {
      snapToNearestFace(E.groupPivot || E.selected);
    }
    syncPropsFromSelected();
    E.renderer.render(E.scene, E.camera);
  });
  E.transform.addEventListener('dragging-changed', e => {
    E.orbit.enabled = !e.value;
    if (e.value) {
      // Drag started — push undo before transform happens, then record pivot
      // (group transforms push undo in beginGroupTransform, before reparenting)
      if (E.selected && !E.groupPivot) pushUndo();
      if (E.selected?.userData.pivotOffset && E.transform.mode === 'rotate') {
        const obj = E.selected;
        const localOffset = new THREE.Vector3().fromArray(obj.userData.pivotOffset);
        E._pivotDragStart = localOffset.clone().applyMatrix4(obj.matrixWorld);
      } else {
        E._pivotDragStart = null;
      }
    } else {
      E._pivotDragStart = null;
      if (E.groupPivot) {
        // Re-enter group mode so user can keep dragging without re-pressing G.
        // Finalize to flush world positions, then immediately re-create the pivot.
        const regid = E.activeGroupGid;
        finalizeGroupTransform();
        if (regid && E.groups[regid]) beginGroupTransform(regid);
      }
      if (E.transform.mode === 'scale' && E.selected?.userData.faceTextures) {
        _reapplyWorldTiling(E.selected);
      }
      E.wasDragging = true;
      markDirty();
      syncPropsFromSelected();
      if (E.selected?.userData._restPos) E.selected.userData._restPos.copy(E.selected.position);
      setTimeout(() => { E.wasDragging = false; }, 80);
    }
  });

  // Groups
  E.placedGroup = new THREE.Group();
  E.placedGroup.name = '__placed__';
  E.scene.add(E.placedGroup);

  // Grid
  E.gridHelper = new THREE.GridHelper(60, 60, 0x333360, 0x222240);
  E.scene.add(E.gridHelper);

  // Player origin marker — shows where the actor spawns (0, 0, 0)
  const originDot = new THREE.Mesh(
    new THREE.SphereGeometry(0.18, 12, 10),
    new THREE.MeshBasicMaterial({ color: 0xe94560, toneMapped: false, depthTest: false })
  );
  originDot.name = '__playerOrigin__';
  originDot.renderOrder = 999;
  E.scene.add(originDot);
  // Cross lines so it's visible from far away
  const crossMat = new THREE.LineBasicMaterial({ color: 0xe94560, opacity: 0.7, transparent: true, depthTest: false });
  const crossGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(-0.6,0,0), new THREE.Vector3(0.6,0,0),
    new THREE.Vector3(0,0,-0.6), new THREE.Vector3(0,0,0.6),
  ]);
  const originCross = new THREE.LineSegments(crossGeo, crossMat);
  originCross.name = '__playerOriginCross__';
  originCross.renderOrder = 999;
  E.scene.add(originCross);

  // Editor-only ambient + directional (always bright for editing)
  const editorAmbient = new THREE.AmbientLight(0xffffff, 0.7);
  editorAmbient.name = '__editorAmbient__';
  E.scene.add(editorAmbient);
  const editorSun = new THREE.DirectionalLight(0xffffff, 0.9);
  editorSun.position.set(8, 20, 12);
  editorSun.name = '__editorSun__';
  E.scene.add(editorSun);

  // Game-preview ambient (very dim — matches scene.js ambientBrightness 0.05)
  const previewAmbient = new THREE.AmbientLight(0xffffff, 0.05);
  previewAmbient.name = '__previewAmbient__';
  previewAmbient.visible = false;
  E.scene.add(previewAmbient);

  // Invisible floor for ghost placement raycasting
  E.floorPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(200, 200),
    new THREE.MeshBasicMaterial({ visible: false, side: THREE.DoubleSide })
  );
  E.floorPlane.rotation.x = -Math.PI / 2;
  E.floorPlane.name = '__floor__';
  E.scene.add(E.floorPlane);

  // List imported models from electron
  await refreshModelList();
  await refreshActorList();

  // Wire up UI
  setupUI();
  setupKeys();
  setupMouse();
  setupRuler();

  // Disable props until a level is open
  updateProps(null);

  // Open level picker, or auto-load if --level arg was provided
  const startupLevel = window.electron?.getStartupLevel ? await window.electron.getStartupLevel() : null;
  if (startupLevel) {
    const levelName = startupLevel.replace(/\.json$/i, '');
    await loadLevel(levelName);
  } else {
    openLevelModal();
  }

  setStatus('Ready - create or open a level to start building');
  animate();
}

// â”€â”€â”€ Viewport helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function viewportAspect() {
  const vp = document.getElementById('viewport');
  return vp ? vp.clientWidth / Math.max(1, vp.clientHeight) : innerWidth / innerHeight;
}

function resizeRenderer() {
  const vp = document.getElementById('viewport');
  const w = vp.clientWidth, h = vp.clientHeight;
  E.renderer.setSize(w, h);
  E.camera.aspect = w / Math.max(1, h);
  E.camera.updateProjectionMatrix();
}

// â”€â”€â”€ Reference scene (read-only hardcoded room visuals) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function _removedSinisterReferenceScene() {
  const tl = new THREE.TextureLoader();
  function loadTex(url, rep) {
    const t = tl.load(url);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(rep, rep);
    return t;
  }
  const floorTex = loadTex('textures/floor.png',   8);
  const wallTex  = loadTex('textures/wall.png',     8);
  const ceilTex  = loadTex('textures/ceiling.png',  8);

  function mat(map) { return new THREE.MeshStandardMaterial({ map, side: THREE.FrontSide }); }
  function addRef(geo, material, px=0, py=0, pz=0, rx=0, ry=0, rz=0) {
    const m = new THREE.Mesh(geo, material);
    m.position.set(px, py, pz);
    m.rotation.set(rx, ry, rz);
    m.receiveShadow = m.castShadow = true;
    m.userData.isRef = true;
    E.refGroup.add(m);
    return m;
  }

  // Floors
  addRef(new THREE.PlaneGeometry(24,24), mat(floorTex),  0, 0,  0, -Math.PI/2);
  addRef(new THREE.PlaneGeometry(24,24), mat(floorTex), 24, 0,  0, -Math.PI/2);
  // Ceilings
  addRef(new THREE.PlaneGeometry(24,24), mat(ceilTex),  0, 6,  0,  Math.PI/2);
  addRef(new THREE.PlaneGeometry(24,24), mat(ceilTex), 24, 6,  0,  Math.PI/2);
  // Main room walls — thickness 0.4 to match ground.js (wallThickness=0.4, wallExtension=0.5)
  addRef(new THREE.BoxGeometry(24.5,6,0.4), mat(wallTex),  0, 3, -12); // front
  addRef(new THREE.BoxGeometry(24.5,6,0.4), mat(wallTex),  0, 3,  12); // back
  addRef(new THREE.BoxGeometry(0.4,6,24.5), mat(wallTex), -12, 3,   0); // left
  // Right wall split around door opening (doorWidth=3.5, doorHeight=4.5, doorOffset=-0.5)
  // Matches ground.js sections exactly:
  //   top:   BoxGeometry(0.4, 1.5, 24.5) at [12, 5.25, 0]
  //   left:  BoxGeometry(0.4, 4.5, 10.25) at [12, 2.25, -7.125]  (leftSectionZ = -12 + 9.75/2 = -7.125)
  //   right: BoxGeometry(0.4, 4.5, 11.25) at [12, 2.25,  6.625]  (rightSectionZ = 1.25 + 10.75/2 = 6.625)
  addRef(new THREE.BoxGeometry(0.4,1.5,24.5), mat(wallTex),  12, 5.25,     0);
  addRef(new THREE.BoxGeometry(0.4,4.5,10.25), mat(wallTex), 12, 2.25, -7.125);
  addRef(new THREE.BoxGeometry(0.4,4.5,11.25), mat(wallTex), 12, 2.25,  6.625);
  // Adjacent room walls
  addRef(new THREE.BoxGeometry(24.5,6,0.4), mat(wallTex), 24, 3, -12);
  addRef(new THREE.BoxGeometry(24.5,6,0.4), mat(wallTex), 24, 3,  12);
  addRef(new THREE.BoxGeometry(0.4,6,24.5), mat(wallTex), 36, 3,   0);

  // Desk
  const gltfLoader = new GLTFLoader();
  gltfLoader.load(ASSET_ROOT + 'low_poly_desk.glb', gltf => {
    const desk = gltf.scene;
    desk.position.set(0, 0, -8);
    desk.scale.setScalar(2.5);
    desk.traverse(c => { if (c.isMesh) { c.castShadow = c.receiveShadow = true; c.userData.isRef = true; } });
    E.refGroup.add(desk);
  });

  // TV
  gltfLoader.load(ASSET_ROOT + 'tv1.glb', gltf => {
    const tv = gltf.scene;
    tv.position.set(0, 2.7, -8);
    tv.scale.setScalar(0.8);
    tv.rotation.y = Math.PI / 2;
    tv.traverse(c => { if (c.isMesh) { c.castShadow = c.receiveShadow = true; c.userData.isRef = true; } });
    E.refGroup.add(tv);
  });

  // Hardcoded bulb light — mirrors ground.js: PointLight(0xc9a876, 1.2, 200, 1) at (0, 5.6, 0)
  const refBulb = new THREE.PointLight(0xc9a876, 1.2, 200, 1);
  refBulb.position.set(0, 5.6, 0);
  refBulb.castShadow = true;
  refBulb.shadow.mapSize.set(2048, 2048);
  refBulb.shadow.radius = 4;
  refBulb.name = '__refBulb__';
  E.refGroup.add(refBulb);

  // Bulb fixture visuals — matches ground.js bulbGroup at position (0, wallHeight=6, 0)
  const refBulbGroup = new THREE.Group();
  refBulbGroup.position.set(0, 6, 0);
  refBulbGroup.userData.isRef = true;
  E.refGroup.add(refBulbGroup);
  function refMesh(geo, color) {
    const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color }));
    m.userData.isRef = true;
    return m;
  }
  // Base plate
  const refBase = refMesh(new THREE.CylinderGeometry(0.4, 0.35, 0.1, 32), 0x2a2a2a);
  refBulbGroup.add(refBase);
  // Chain
  const refChain = refMesh(new THREE.CylinderGeometry(0.02, 0.02, 1.8, 4), 0x333333);
  refChain.position.y = -0.95;
  refBulbGroup.add(refChain);
  // Pull tab
  const refTab = refMesh(new THREE.SphereGeometry(0.08, 8, 8), 0x555555);
  refTab.position.set(0.2, -1.85, 0);
  refBulbGroup.add(refTab);
  // Bulb sphere
  const refBulbMesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.15, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0xc9a876, emissive: 0xc9a876, emissiveIntensity: 0.5 })
  );
  refBulbMesh.position.y = -0.40;
  refBulbMesh.userData.isRef = true;
  refBulbGroup.add(refBulbMesh);
  // Socket
  const refSocket = refMesh(new THREE.CylinderGeometry(0.08, 0.08, 0.15, 8), 0x444444);
  refSocket.position.y = -0.175;
  refBulbGroup.add(refSocket);

  // TV frame spotlight — fixed position from pauseMenu.js: SpotLight at (-0.14, 2.75, -8.17)
  // pointing toward (0.16, 3.05, 1.82), intensity=3.4, distance=10, angle=1.17 rad (~67°)
  {
    const tvFCol = new THREE.Color(0xffffff);
    const tvFMat = new THREE.LineBasicMaterial({ color: tvFCol, opacity: 0.45, transparent: true });
    const tvFGroup = new THREE.Group();
    tvFGroup.name = '__refTVFrameLight__';
    tvFGroup.userData.isRef = true;
    tvFGroup.position.set(-0.14, 2.75, -8.17);
    E.refGroup.add(tvFGroup);
    // Origin dot
    const tvFDot = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8),
      new THREE.MeshBasicMaterial({ color: tvFCol, toneMapped: false }));
    tvFGroup.add(tvFDot);
    // Direction line toward target (0.16, 3.05, 1.82)
    const tvFDir = new THREE.Vector3(0.16 - (-0.14), 3.05 - 2.75, 1.82 - (-8.17)).normalize();
    const tvFDist = 10;
    const tvFAngleDeg = THREE.MathUtils.radToDeg(1.17);
    const tvFRad = Math.tan(THREE.MathUtils.degToRad(Math.min(tvFAngleDeg, 89))) * tvFDist;
    // Cone along direction
    const perpA = new THREE.Vector3(1, 0, 0);
    const perpB = new THREE.Vector3().crossVectors(tvFDir, perpA).normalize();
    perpA.crossVectors(perpB, tvFDir).normalize();
    const N = 24;
    const rimPts = [];
    for (let i = 0; i <= N; i++) {
      const a = (i / N) * Math.PI * 2;
      rimPts.push(new THREE.Vector3()
        .addScaledVector(perpA, Math.cos(a) * tvFRad)
        .addScaledVector(perpB, Math.sin(a) * tvFRad)
        .addScaledVector(tvFDir, tvFDist));
    }
    tvFGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(rimPts), tvFMat));
    [0, Math.PI/2, Math.PI, 3*Math.PI/2].forEach(a => {
      const tip = rimPts[Math.round((a / (Math.PI*2)) * N)];
      const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0,0,0), tip.clone()]);
      tvFGroup.add(new THREE.Line(geo, tvFMat));
    });
  }

  // Range wire for the hardcoded bulb — PointLight at (0,5.6,0), distance=200
  // Added to refGroup at the light's world position so it moves with Ref toggle
  const bulbWireCol = new THREE.Color(0xc9a876);
  const bulbWireMat = new THREE.LineBasicMaterial({ color: bulbWireCol, opacity: 0.35, transparent: true });
  const bulbDist = 200;
  const refRangeGroup = new THREE.Group();
  refRangeGroup.name = '__refBulbRange__';
  refRangeGroup.userData.isRef = true;
  refRangeGroup.position.set(0, 5.6, 0);
  function makeRefCircle(r, axis) {
    const pts = [];
    for (let i = 0; i <= 64; i++) {
      const a = (i / 64) * Math.PI * 2;
      if      (axis === 'y') pts.push(new THREE.Vector3(Math.cos(a) * r, 0, Math.sin(a) * r));
      else if (axis === 'x') pts.push(new THREE.Vector3(0, Math.cos(a) * r, Math.sin(a) * r));
      else                   pts.push(new THREE.Vector3(Math.cos(a) * r, Math.sin(a) * r, 0));
    }
    return new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), bulbWireMat);
  }
  refRangeGroup.add(makeRefCircle(bulbDist, 'y'));
  refRangeGroup.add(makeRefCircle(bulbDist, 'x'));
  refRangeGroup.add(makeRefCircle(bulbDist, 'z'));
  E.refGroup.add(refRangeGroup);
}

// â”€â”€â”€ Level save / load â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function levelToJSON(options = {}) {
  const includeEditorUi = options.includeEditorUi === true;
  // If a group pivot is active, temporarily reparent members into placedGroup with
  // their world-space transforms so the serialization loop sees them correctly.
  const _pivotSaved = [];
  if (E.groupPivot && E.groupPivotMembers.length) {
    E.groupPivotMembers.forEach(m => {
      const wp = new THREE.Vector3();
      const wq = new THREE.Quaternion();
      const ws = new THREE.Vector3();
      m.updateMatrixWorld(true);
      m.getWorldPosition(wp);
      m.getWorldQuaternion(wq);
      m.getWorldScale(ws);
      _pivotSaved.push({ m, lp: m.position.clone(), lq: m.quaternion.clone(), ls: m.scale.clone() });
      E.groupPivot.remove(m);
      m.position.copy(wp);
      m.quaternion.copy(wq);
      m.scale.copy(ws);
      E.placedGroup.add(m);
    });
  }

  const objects = [];
  E.placedGroup.children.forEach(obj => {
    if (obj.userData.isEditorHelper) return;
    // CSG result: store the recipe, not pos/rot/size (result lives at world origin)
    if (obj.userData.primType === 'csg-result') {
      const matColor = Array.isArray(obj.material) ? obj.material[0]?.color : obj.material?.color;
      const csgEntry = {
        id:         obj.userData.editorId,
        label:      obj.userData.label || '',
        type:       'csg-result',
        collidable: obj.userData.collidable !== false,
        castShadow: obj.castShadow !== false,
        pos:        [+obj.position.x.toFixed(4), +obj.position.y.toFixed(4), +obj.position.z.toFixed(4)],
        rot:        [+(obj.rotation.x*DEG).toFixed(4), +(obj.rotation.y*DEG).toFixed(4), +(obj.rotation.z*DEG).toFixed(4)],
        size:       [1, 1, 1],
        color:      matColor ? '#' + matColor.getHexString() : '#aaaacc',
        csgRecipe:  obj.userData.csgRecipe,
      };
      if (obj.userData.emissiveIntensity > 0) {
        csgEntry.emissiveIntensity = obj.userData.emissiveIntensity;
        csgEntry.emissiveColor     = obj.userData.emissiveColor ?? '#ffffff';
      }
      if (obj.userData.scripts?.length) csgEntry.scripts = [...obj.userData.scripts];
      if (obj.userData.roughness !== undefined) csgEntry.roughness = obj.userData.roughness;
      if (obj.userData.metalness !== undefined) csgEntry.metalness = obj.userData.metalness;
      if (obj.userData.faceTextures) csgEntry.faceTextures = obj.userData.faceTextures;
      objects.push(csgEntry);
      return;
    }
    if (obj.userData.primType === 'merged-model') {
      const mergedEntry = {
        id:           obj.userData.editorId,
        label:        obj.userData.label || '',
        type:         'merged-model',
        collidable:   obj.userData.collidable !== false,
        castShadow:   obj.castShadow !== false,
        pos:          [+obj.position.x.toFixed(4), +obj.position.y.toFixed(4), +obj.position.z.toFixed(4)],
        rot:          [+(obj.rotation.x*DEG).toFixed(2), +(obj.rotation.y*DEG).toFixed(2), +(obj.rotation.z*DEG).toFixed(2)],
        size:         [+obj.scale.x.toFixed(4), +obj.scale.y.toFixed(4), +obj.scale.z.toFixed(4)],
        mergedMeshes: _serializeMergedMeshes(obj),
      };
      if (obj.userData.meshOverrides) mergedEntry.meshOverrides = obj.userData.meshOverrides;
      if (obj.userData._baseColor) mergedEntry.color = obj.userData._baseColor;
      if (obj.userData.doubleSide) mergedEntry.doubleSide = true;
      if (obj.userData.invertNormals) mergedEntry.invertNormals = true;
      if (obj.userData.scripts?.length) mergedEntry.scripts = [...obj.userData.scripts];
      if (obj.userData.states?.length) mergedEntry.states = obj.userData.states;
      if (obj.userData.links?.length)  mergedEntry.links  = obj.userData.links;
      if (obj.userData.noSelfInteract) mergedEntry.noSelfInteract = true;
      objects.push(mergedEntry);
      return;
    }
    if (obj.userData.primType === 'image-model') {
      const imgEntry = {
        id:         obj.userData.editorId,
        label:      obj.userData.label || '',
        type:       'image-model',
        imagePath:  obj.userData.imagePath,
        wallColor:  obj.userData.wallColor,
        collidable: obj.userData.collidable !== false,
        castShadow: obj.castShadow !== false,
        pos:        [+obj.position.x.toFixed(4), +obj.position.y.toFixed(4), +obj.position.z.toFixed(4)],
        rot:        [+(obj.rotation.x*DEG).toFixed(2), +(obj.rotation.y*DEG).toFixed(2), +(obj.rotation.z*DEG).toFixed(2)],
        size:       [+obj.scale.x.toFixed(4), +obj.scale.y.toFixed(4), +obj.scale.z.toFixed(4)],
      };
      if (obj.userData.states?.length) imgEntry.states = obj.userData.states;
      if (obj.userData.links?.length)  imgEntry.links  = obj.userData.links;
      if (obj.userData.scripts?.length) imgEntry.scripts = [...obj.userData.scripts];
      objects.push(imgEntry);
      return;
    }
    const entry = {
      id:         obj.userData.editorId,
      label:      obj.userData.label || '',
      type:       obj.userData.primType || 'model',
      collidable: obj.userData.collidable !== false,
      castShadow: isLightType(obj.userData.primType) ? obj.userData.castShadow !== false : obj.castShadow !== false,
      pos:        [+obj.position.x.toFixed(4), +obj.position.y.toFixed(4), +obj.position.z.toFixed(4)],
      rot:        [+(obj.rotation.x*DEG).toFixed(2), +(obj.rotation.y*DEG).toFixed(2), +(obj.rotation.z*DEG).toFixed(2)],
      size:       [+obj.scale.x.toFixed(4), +obj.scale.y.toFixed(4), +obj.scale.z.toFixed(4)],
      color:      obj.userData._baseColor ?? (Array.isArray(obj.material) ? ('#' + (obj.material[0]?.color?.getHexString() ?? 'aaaacc')) : (obj.material?.color ? '#' + obj.material.color.getHexString() : '#aaaacc')),
    };
    if (obj.userData.emissiveIntensity > 0) {
      entry.emissiveIntensity = obj.userData.emissiveIntensity;
      entry.emissiveColor     = obj.userData.emissiveColor ?? '#ffffff';
    }
    const _opacity = getMeshOpacity(obj);
    if (_opacity < 1) entry.opacity = +_opacity.toFixed(3);
    if (obj.userData.primType === 'model') entry.modelPath = obj.userData.modelPath;
    if (obj.userData.primType === 'actor-spawn') {
      entry.actorModel      = obj.userData.actorModel;
      entry.spawnRadius     = obj.userData.spawnRadius ?? 0;
      entry.persistent      = obj.userData.persistent !== false;
      entry.singleInstance  = obj.userData.singleInstance === true;
      if (obj.userData.actorSourceId)              entry.actorSourceId      = obj.userData.actorSourceId;
      if (obj.userData.actorSpawnInterval != null) entry.actorSpawnInterval = obj.userData.actorSpawnInterval;
      if (obj.userData.actorSpawnMax      != null) entry.actorSpawnMax      = obj.userData.actorSpawnMax;
      if (obj.userData.actorHealth        != null) entry.actorHealth        = obj.userData.actorHealth;
      if (obj.userData.actorSpeed         != null) entry.actorSpeed         = obj.userData.actorSpeed;
      if (obj.userData.actorDamage        != null) entry.actorDamage        = obj.userData.actorDamage;
      if (obj.userData.actorCrit          != null) entry.actorCrit          = obj.userData.actorCrit;
      if (obj.userData.meshOverrides && Object.keys(obj.userData.meshOverrides).length)
        entry.meshOverrides = obj.userData.meshOverrides;
      if (obj.userData.animations?.length)
        entry.animations = obj.userData.animations;
      if (obj.userData.actorRoles && Object.keys(obj.userData.actorRoles).length)
        entry.actorRoles = obj.userData.actorRoles;
      if (obj.userData.actorVariants?.length)
        entry.actorVariants = obj.userData.actorVariants;
    }
    if (obj.userData.faceTextures)   entry.faceTextures   = obj.userData.faceTextures;
    if (obj.userData.meshOverrides)  entry.meshOverrides  = obj.userData.meshOverrides;
    if (obj.userData.masterTexture)  entry.masterTexture  = obj.userData.masterTexture;
    if (obj.userData.scripts?.length) entry.scripts        = [...obj.userData.scripts];
    if (obj.userData.roughness !== undefined) entry.roughness = obj.userData.roughness;
    if (obj.userData.metalness !== undefined) entry.metalness = obj.userData.metalness;
    if (obj.userData.doubleSide) entry.doubleSide = true;
    if (obj.userData.invertNormals) entry.invertNormals = true;
    if (obj.userData.colorSpace) entry.colorSpace = obj.userData.colorSpace;
    if (obj.userData.pbrConverted) entry.pbrConverted = true;
    if (obj.userData.modelMaps)    entry.modelMaps = obj.userData.modelMaps;
    if (obj.userData.modelMapRes)  entry.modelMapRes = obj.userData.modelMapRes;
    if (obj.userData.geomParams)    entry.geomParams    = obj.userData.geomParams;
    if (obj.userData.isMainFloor)   entry.isMainFloor   = true;
    if (obj.userData.isAdjFloor)    entry.isAdjFloor    = true;
    // Light-specific fields
    if (isLightType(obj.userData.primType)) {
      entry.lightColor = obj.userData.lightColor || '#ffffff';
      entry.intensity  = obj.userData.intensity  ?? 1;
      entry.distance   = obj.userData.distance   ?? 0;
      entry.decay      = obj.userData.decay      ?? 2;
      if (obj.userData.primType === 'spot-light') {
        entry.angle    = obj.userData.angle    ?? 30;
        entry.penumbra = obj.userData.penumbra ?? 0.15;
      }
    }
    if (obj.userData.states?.length)   entry.states         = obj.userData.states;
    if (obj.userData.links?.length)      entry.links          = obj.userData.links;
    if (obj.userData.pivotOffset)        entry.pivotOffset    = obj.userData.pivotOffset;
    if (obj.userData.noSelfInteract)     entry.noSelfInteract = true;
    if (obj.userData.bones?.length)      { entry.bones = obj.userData.bones; entry.boneMode = obj.userData.boneMode || 'rigid'; }
    // Trigger-specific fields
    if (isTriggerType(obj.userData.primType)) {
      if (obj.userData.primType === 'custom-trigger') {
        entry.triggerVar      = obj.userData.triggerVar      || '';
        entry.triggerVarOp    = obj.userData.triggerVarOp    || 'set';
        entry.triggerVarValue = obj.userData.triggerVarValue ?? 'true';
        entry.presenceVar     = obj.userData.presenceVar     || '';
      } else {
        entry.saveSlot = obj.userData.saveSlot || 'autosave';
        entry.onceOnly = obj.userData.onceOnly !== false;
      }
      entry.scale = entry.size;
    }
    if (isZombieType(obj.userData.primType)) {
      const t = obj.userData.primType;
      if (t === 'zombie-spawn') {
        entry.spawnRadius = obj.userData.spawnRadius ?? 0;
        if (obj.userData.actorModel)                                          entry.actorModel    = obj.userData.actorModel;
        if (obj.userData.actorVariants?.length)                               entry.actorVariants = obj.userData.actorVariants;
        if (obj.userData.actorRoles && Object.keys(obj.userData.actorRoles).length) entry.actorRoles = obj.userData.actorRoles;
        if (obj.userData.meshOverrides && Object.keys(obj.userData.meshOverrides).length) entry.meshOverrides = obj.userData.meshOverrides;
        if ((obj.userData.roundMin ?? 1) !== 1) entry.roundMin = obj.userData.roundMin;
        if (obj.userData.roundMax != null)      entry.roundMax = obj.userData.roundMax;
      } else if (t === 'zom-wallbuy') {
        entry.weaponSlug      = obj.userData.weaponSlug      ?? '';
        entry.wallBuyCost     = obj.userData.wallBuyCost     ?? 500;
        entry.wallBuyAmmoCost = obj.userData.wallBuyAmmoCost ?? 250;
        if (obj.userData.weaponDef && Object.keys(obj.userData.weaponDef).length) entry.weaponDef = obj.userData.weaponDef;
        if (obj.userData.weaponModelPath) entry.weaponModelPath = obj.userData.weaponModelPath;
        if (obj.userData.weaponModelOpacity != null && obj.userData.weaponModelOpacity !== 1) entry.weaponModelOpacity = obj.userData.weaponModelOpacity;
      } else if (t === 'zom-perk') {
        entry.perkId       = obj.userData.perkId       ?? '';
        if (obj.userData.perkCost != null) entry.perkCost = obj.userData.perkCost;
        entry.requirePower = obj.userData.requirePower !== false;
      } else if (t === 'zom-mystery') {
        if (obj.userData.mysteryBoxCost != null) entry.mysteryBoxCost = obj.userData.mysteryBoxCost;
        entry.weaponPool = obj.userData.weaponPool ?? [];
      } else if (t === 'zom-pap') {
        if (obj.userData.tierCount != null)    entry.papTierCount = obj.userData.tierCount;
        entry.requirePower = obj.userData.requirePower !== false;
      } else if (t === 'zom-ammo') {
        entry.ammoCost = obj.userData.ammoCost ?? 500;
      } else if (t === 'zom-door') {
        entry.doorCost = obj.userData.doorCost ?? 750;
      }
    }
    objects.push(entry);
  });

  const groups = {};
  for (const [gid, g] of Object.entries(E.groups)) {
    groups[gid] = { name: g.name, ids: [...g.ids] };
  }

  // Restore any group pivot members back to their local-pivot transforms
  _pivotSaved.forEach(({ m, lp, lq, ls }) => {
    E.placedGroup.remove(m);
    m.position.copy(lp);
    m.quaternion.copy(lq);
    m.scale.copy(ls);
    E.groupPivot.add(m);
  });

  const out = { levelName: E.levelName, nextId: E.nextId };
  if (E.isZombiesMap) {
    out.isZombiesMap = true;
    if (E.zombiesMapDisplayName) out.zombiesMapDisplayName = E.zombiesMapDisplayName;
    if (E.zombiesConfig) out.zombiesConfig = E.zombiesConfig;
  }
  out.objects = objects;
  out.groups = groups;
  out.vars = E.levelVars;
  if (E.sceneScripts?.length) out.sceneScripts = E.sceneScripts;
  if (E.fogDensity != null) out.fogDensity = E.fogDensity;
  if (includeEditorUi) {
    out.editorUi = {
      selectedId: E.selected?.userData?.editorId ?? null,
      selectedFace: E.selectedFace,
      groupCollapsed: { ...E.groupCollapsed },
      stateExpanded: [...E._stateExpanded],
    };
  }
  return out;
}

async function saveLevel() {
  if (!E.levelName) { setStatus('No level open'); return; }
  if (!window.electron) { setStatus('Not running in Electron - cannot save to disk'); return; }
  const data = levelToJSON();
  try {
    await window.electron.saveLevel(E.levelName, data);
    E.isDirty = false;
    refreshLevelNameDisplay();
    setStatus(`Saved "${E.levelName}" - ${data.objects.length} object(s)`);
  } catch (err) {
    setStatus('Save failed: ' + err.message);
  }
}

async function loadLevel(name) {
  clearPlaced();
  E.undoStack = [];
  E.redoStack = [];
  E.levelName = name;

  let data = null;
  if (window.electron) {
    try { data = await window.electron.readLevel(name); } catch { /* new */ }
  }

  E.nextId = data?.nextId || 1;
  E.groups = {};
  E.groupCollapsed = {};
  if (data?.groups) {
    for (const [gid, g] of Object.entries(data.groups)) {
      E.groups[gid] = { name: g.name, ids: new Set(g.ids) };
    }
  }
  E.levelVars = data?.vars ? { ...data.vars } : {};
  E.sceneScripts = Array.isArray(data?.sceneScripts) ? [...data.sceneScripts] : [];
  E.fogDensity = (data?.fogDensity != null) ? data.fogDensity : null;
  E.isZombiesMap = data?.isZombiesMap ?? false;
  E.zombiesMapDisplayName = data?.zombiesMapDisplayName ?? null;
  E.zombiesConfig = data?.zombiesConfig ?? null;
  _updateFogInput();
  const sceneScriptsEl = document.getElementById('scene-scripts');
  if (sceneScriptsEl && document.activeElement !== sceneScriptsEl) {
    sceneScriptsEl.value = _scriptListToText(E.sceneScripts);
  }
  renderVarsPanel();

  if (data?.objects?.length) {
    const gltfLoader = new GLTFLoader();
    const fbxLoader  = new FBXLoader();
    const promises = data.objects.map(entry => {
      if (entry.type === 'csg-result')    return spawnCsgResult(entry, gltfLoader, fbxLoader).catch(err => console.warn('CSG spawn failed:', err));
      if (entry.type === 'model')          return loadModelIntoPlaced(entry, gltfLoader, fbxLoader);
      if (entry.type === 'merged-model')   return Promise.resolve(spawnMergedModel(entry));
      if (entry.type === 'image-model')    return spawnImageModel(entry);
      return Promise.resolve(spawnPrimFromEntry(entry));
    });
    await Promise.allSettled(promises);
  }

  E.isDirty = false;
  refreshLevelNameDisplay();
  updateSceneList();
  updateGroupsPanel();

  const objCount = data?.objects?.length ?? 0;
  setStatus(objCount ? `Loaded "${name}" - ${objCount} object(s)` : `New level "${name}" - add objects to get started`);
}

function clearPlaced() {
  E.transform.detach();
  E.selected = null;
  E.selectedFace = null;
  E._stateExpanded = new Set();
  E.sceneScripts = [];
  _clearFaceOverlay('hover');
  _clearFaceOverlay('select');
  if (E.groupPivot) {
    E.scene.remove(E.groupPivot);
    E.groupPivot = null;
    E.groupPivotMembers = [];
    E.activeGroupGid = null;
  }
  closeModelEditor();
  if (E.linkMode) cancelLink();
  if (E.cutMode) cancelCut();
  if (E.pivotMode) cancelPivot();
  if (E.ropeAnchorMode) cancelRopeAnchor();
  if (E.facePickMode) cancelFacePick();
  if (E.faceModeActive) exitFaceMode();
  cancelPlace();
  while (E.placedGroup.children.length) E.placedGroup.remove(E.placedGroup.children[0]);
  E.colHelpers.forEach(h => E.scene.remove(h));
  E.colHelpers = [];
  E.groups = {};
  E.groupCollapsed = {};
  E.levelVars = {};
  E.fogDensity = null;
  E.isZombiesMap = false;
  E.zombiesMapDisplayName = null;
  E.zombiesConfig = null;
  _updateFogInput();
  const sceneScriptsEl = document.getElementById('scene-scripts');
  if (sceneScriptsEl && document.activeElement !== sceneScriptsEl) {
    sceneScriptsEl.value = '';
  }
  updateSceneList();
  updateGroupsPanel();
  renderVarsPanel();
  updateProps(null);
}

async function loadModelIntoPlaced(entry, gltfLoader, fbxLoader) {
  return new Promise(resolve => {
    const ext = (entry.modelPath || '').split('.').pop().toLowerCase();

    if (ext === 'obj') {
      const objBase  = ASSET_ROOT + entry.modelPath;          // e.g. ../models/editor/foo.obj
      const dir      = objBase.substring(0, objBase.lastIndexOf('/') + 1);
      const baseName = objBase.substring(objBase.lastIndexOf('/') + 1, objBase.lastIndexOf('.'));
      const mtlUrl   = dir + baseName + '.mtl';

      const _applyObjRoot = root => {
        root.castShadow = entry.castShadow !== false;
        root.traverse(c => { if (c.isMesh) { c.castShadow = entry.castShadow !== false; c.receiveShadow = true; } });
        applyEntryTransform(root, entry);
        root.userData.primType   = 'model';
        root.userData.modelPath  = entry.modelPath;
        root.userData.editorId   = entry.id;
        root.userData.label      = entry.label || '';
        root.userData.collidable = entry.collidable !== false;
        root.name = entry.label || ('Model_' + entry.id);
        if (entry.states?.length) { root.userData.states = entry.states; root.userData.currentState = 0; }
        if (entry.links?.length)  root.userData.links  = _normalizeLinks(entry.links);
        if (entry.noSelfInteract) root.userData.noSelfInteract = true;
        if (entry.pivotOffset)    root.userData.pivotOffset = entry.pivotOffset;
        if (entry.bones?.length)  { root.userData.bones = entry.bones; root.userData.boneMode = entry.boneMode || 'rigid'; }
        if (entry.colorSpace)     root.userData.colorSpace = entry.colorSpace;
        if (entry.pbrConverted)   root.userData.pbrConverted = true;
        if (entry.modelMapRes)    root.userData.modelMapRes = entry.modelMapRes;
        if (entry.modelMaps)      { root.userData.modelMaps = entry.modelMaps; _applyModelMapsToObj(root, entry.modelMaps); }
        E.placedGroup.add(root);
        resolve(root);
      };

      const loadWithMtl = materials => {
        const objLoader = new OBJLoader();
        if (materials) { materials.preload(); objLoader.setMaterials(materials); }
        objLoader.load(objBase, _applyObjRoot, undefined, err => {
          console.warn('OBJ load error:', err);
          resolve(null);
        });
      };

      const mtlLoader = new MTLLoader();
      mtlLoader.setPath(dir);
      mtlLoader.load(baseName + '.mtl', loadWithMtl, undefined, () => loadWithMtl(null));
      return;
    }

    const loader = ext === 'fbx' ? fbxLoader : gltfLoader;
    loader.load(ASSET_ROOT + entry.modelPath, result => {
      const root = result.scene || result;
      root.castShadow = entry.castShadow !== false;
      root.traverse(c => {
        if (c.isMesh) {
          c.castShadow = entry.castShadow !== false;
          c.receiveShadow = true;
          if (ext === 'fbx') {
            const threeCS = entry.colorSpace === 'linear' ? THREE.LinearSRGBColorSpace : THREE.SRGBColorSpace;
            const roughness = entry.roughness ?? 1;
            const metalness = entry.metalness ?? 0;
            const mats = Array.isArray(c.material) ? c.material : [c.material];
            const newMats = mats.map(m => {
              if (!m) return m;
              if (entry.pbrConverted && !('roughness' in m)) {
                const pbr = new THREE.MeshStandardMaterial({
                  color: m.color?.clone() ?? new THREE.Color(0xffffff),
                  map: m.map ?? null, normalMap: m.normalMap ?? null,
                  emissiveMap: m.emissiveMap ?? null, aoMap: m.aoMap ?? null,
                  emissive: m.emissive?.clone() ?? new THREE.Color(0x000000),
                  emissiveIntensity: m.emissiveIntensity ?? 1,
                  roughness, metalness, side: m.side,
                  transparent: m.transparent, opacity: m.opacity,
                });
                ['map','emissiveMap','normalMap','roughnessMap','metalnessMap','aoMap'].forEach(k => {
                  if (pbr[k]) { pbr[k].colorSpace = threeCS; pbr[k].needsUpdate = true; }
                });
                return pbr;
              }
              ['map','emissiveMap','normalMap','roughnessMap','metalnessMap','aoMap'].forEach(k => {
                if (m[k]) { m[k].colorSpace = threeCS; m[k].needsUpdate = true; }
              });
              m.needsUpdate = true;
              return m;
            });
            c.material = Array.isArray(c.material) ? newMats : newMats[0];
          }
        }
      });
      applyEntryTransform(root, entry);
      root.userData.primType   = 'model';
      root.userData.modelPath  = entry.modelPath;
      root.userData.editorId   = entry.id;
      root.userData.label      = entry.label || '';
      root.userData.collidable = entry.collidable !== false;
      root.name = entry.label || ('Model_' + entry.id);
      if (entry.states?.length) { root.userData.states = entry.states; root.userData.currentState = 0; }
      if (entry.links?.length)  root.userData.links  = _normalizeLinks(entry.links);
      if (entry.noSelfInteract) root.userData.noSelfInteract = true;
      if (entry.pivotOffset)    root.userData.pivotOffset = entry.pivotOffset;
      if (entry.colorSpace)     root.userData.colorSpace = entry.colorSpace;
      if (entry.pbrConverted)   root.userData.pbrConverted = true;
      if (entry.modelMapRes)     root.userData.modelMapRes = entry.modelMapRes;
      if (entry.modelMaps)      { root.userData.modelMaps = entry.modelMaps; _applyModelMapsToObj(root, entry.modelMaps); }
      if (entry.emissiveIntensity > 0) {
        root.userData.emissiveIntensity = entry.emissiveIntensity;
        root.userData.emissiveColor     = entry.emissiveColor ?? '#ffffff';
        const col = new THREE.Color(entry.emissiveColor ?? '#ffffff');
        root.traverse(c => {
          if (c.isMesh && c.material) {
            const mats = Array.isArray(c.material) ? c.material : [c.material];
            mats.forEach(m => { if ('emissive' in m) { m.emissive.copy(col); m.emissiveIntensity = entry.emissiveIntensity; } });
          }
        });
      }
      if (entry.meshOverrides) {
        root.userData.meshOverrides = entry.meshOverrides;
        root.traverse(c => {
          if (!c.isMesh) return;
          const key = c.name || c.uuid;
          const ovr = entry.meshOverrides[key];
          if (!ovr) return;
          if (ovr.visible === false) {
            if (Array.isArray(c.material)) {
              c.material = c.material.map(m => { const n = m.clone(); n.visible = false; return n; });
            } else if (c.material) {
              c.material = c.material.clone();
              c.material.visible = false;
            }
          }
          if (ovr.texture) _applyMeshEditorTexture(c, ovr.texture);
        });
      }
      if (entry.masterTexture) {
        root.userData.masterTexture = entry.masterTexture;
        root.userData.roughness = entry.roughness;
        root.userData.metalness = entry.metalness;
        const col = new THREE.Color(entry.color ?? '#aaaacc');
        const roughness = entry.roughness ?? 1;
        const metalness = entry.metalness ?? 0;
        const loader = new THREE.TextureLoader();
        const tryUrl = url => new Promise(res => loader.load(ASSET_ROOT + 'textures/' + url, res, undefined, () => res(null)));
        (async () => {
          let tex = await tryUrl(entry.masterTexture + '.png');
          if (!tex) tex = await tryUrl(entry.masterTexture + '.jpg');
          if (!tex) return;
          tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
          root.traverse(c => {
            if (!c.isMesh) return;
            c.material = new THREE.MeshStandardMaterial({ color: col, map: tex, roughness, metalness });
          });
        })();
      } else if (entry.roughness !== undefined || entry.metalness !== undefined) {
        root.userData.roughness = entry.roughness;
        root.userData.metalness = entry.metalness;
        root.traverse(c => {
          if (!c.isMesh || !c.material) return;
          const mats = Array.isArray(c.material) ? c.material : [c.material];
          mats.forEach((m, i) => {
            if (!m.isMeshStandardMaterial) {
              const nm = new THREE.MeshStandardMaterial({ color: m.color, map: m.map, roughness: entry.roughness ?? 1, metalness: entry.metalness ?? 0 });
              if (Array.isArray(c.material)) c.material[i] = nm; else c.material = nm;
            } else {
              if (entry.roughness !== undefined) { m.roughness = entry.roughness; m.needsUpdate = true; }
              if (entry.metalness !== undefined) { m.metalness = entry.metalness; m.needsUpdate = true; }
            }
          });
        });
      }
      if (entry.doubleSide) {
        root.userData.doubleSide = true;
        root.traverse(c => {
          if (c.isMesh && c.material) {
            const mats = Array.isArray(c.material) ? c.material : [c.material];
            mats.forEach(m => { m.side = THREE.DoubleSide; m.needsUpdate = true; });
          }
        });
      }
      if (entry.invertNormals) {
        root.userData.invertNormals = true;
        root.traverse(c => { if (c.isMesh && c.geometry) _flipGeometryNormals(c.geometry); });
      }
      E.placedGroup.add(root);
      // FBXLoader loads textures asynchronously internally — re-apply colorSpace at increasing
      // delays to catch late-loading textures regardless of disk/decode speed
      const _applyCS = () => {
        const threeCS2 = entry.colorSpace === 'linear' ? THREE.LinearSRGBColorSpace : THREE.SRGBColorSpace;
        root.traverse(c => {
          if (!c.isMesh) return;
          const mats2 = Array.isArray(c.material) ? c.material : [c.material];
          mats2.forEach(m => {
            if (!m) return;
            ['map','emissiveMap','normalMap','roughnessMap','metalnessMap','aoMap'].forEach(k => {
              if (m[k]) { m[k].colorSpace = threeCS2; m[k].needsUpdate = true; }
            });
            m.needsUpdate = true;
          });
        });
      };
      setTimeout(_applyCS, 0);
      setTimeout(_applyCS, 300);
      setTimeout(_applyCS, 1500);
      resolve();
    }, undefined, () => resolve());
  });
}

function applyEntryTransform(obj, entry) {
  obj.position.set(...entry.pos);
  obj.rotation.set(entry.rot[0]*RAD, entry.rot[1]*RAD, entry.rot[2]*RAD);
  const sz = entry.size ?? entry.scale ?? [1, 1, 1];
  obj.scale.set(...sz);
  obj.userData._restPos   = obj.position.clone();
  obj.userData._restRot   = [entry.rot[0], entry.rot[1], entry.rot[2]];
  obj.userData._restScale = obj.scale.clone();
}

// â”€â”€â”€ Primitives â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const PRIM_GEOS = {
  box:      () => new THREE.BoxGeometry(1,1,1),
  sphere:   () => new THREE.SphereGeometry(0.5, 16, 12),
  cylinder: () => new THREE.CylinderGeometry(0.5, 0.5, 1, 16),
  plane:    () => new THREE.PlaneGeometry(1,1),
  // save-trigger and custom-trigger use a box geometry but are rendered as a wireframe-only volume
  'save-trigger':   () => new THREE.BoxGeometry(2, 2, 2),
  'custom-trigger': () => new THREE.BoxGeometry(2, 2, 2),
  'player-spawn':   () => { const g = new THREE.ConeGeometry(0.3, 1.0, 8); g.translate(0, 0.5, 0); return g; },
  'zombie-spawn': () => new THREE.CylinderGeometry(0.5, 0.5, 1, 8),
  'zom-wallbuy':  () => new THREE.BoxGeometry(1, 1, 1),
  'zom-perk':     () => new THREE.CylinderGeometry(0.5, 0.5, 1, 8),
  'zom-mystery':  () => new THREE.BoxGeometry(1, 1, 1),
  'zom-pap':      () => new THREE.BoxGeometry(1, 1, 1),
  'zom-ammo':     () => new THREE.CylinderGeometry(0.5, 0.5, 1, 8),
  'zom-power':    () => new THREE.BoxGeometry(1, 1, 1),
  'zom-door':     () => new THREE.BoxGeometry(1, 1, 1),
  'zom-drop':     () => new THREE.SphereGeometry(0.5, 8, 6),
  'zom-jackpot':  () => new THREE.BoxGeometry(1, 1.5, 1),
  rope:            () => new THREE.CylinderGeometry(0.015, 0.015, 0.5, 6),
};

function isLightType(t) {
  return t === 'point-light' || t === 'spot-light' || t === 'dir-light';
}

function isTriggerType(t) {
  return t === 'save-trigger' || t === 'custom-trigger';
}

function isPlayerSpawnType(t) {
  return t === 'player-spawn';
}

function isZombieType(t) {
  return ['zombie-spawn','zom-wallbuy','zom-perk','zom-mystery','zom-pap','zom-ammo','zom-power','zom-door','zom-drop','zom-jackpot'].includes(t);
}

function zombieTypeColor(t) {
  return ({'zombie-spawn':0x44ff44,'zom-wallbuy':0xffaa33,'zom-perk':0xff3333,'zom-mystery':0xffdd00,
           'zom-pap':0xdd44ff,'zom-ammo':0x44ddff,'zom-power':0xffffff,'zom-door':0xaa6622,'zom-drop':0x88ff44,'zom-jackpot':0xffcc00})[t] ?? 0xffffff;
}

const LIGHT_DEFAULTS = {
  'point-light': { intensity: 1.0, distance: 10, decay: 2 },
  'spot-light':  { intensity: 1.0, distance: 20, decay: 2, angle: 30, penumbra: 0.15 },
  'dir-light':   { intensity: 1.0 },
};

// ─── Geometry param system ─────────────────────────────────────────────────────
// Default params per primitive type (used when geomParams is absent)
const GEOM_DEFAULTS = {
  box:      { bevel: 0, bevelSegs: 2, wSegs: 1, hSegs: 1, dSegs: 1 },
  sphere:   { wSegs: 16, hSegs: 12, phi: 360, theta: 180 },
  cylinder: { radSegs: 16, hSegs: 1, radTop: 1, open: false },
  plane:    { wSegs: 1, hSegs: 1 },
  rope:     { ropeLength: 1.2, ropeRadius: 0.015, ropeSegs: 12, ropeSag: 0.5, ropeDamping: 0.985, anchorBOffset: [0, -0.5, 0], anchorBId: null },
};

// Build the correct BufferGeometry from a primitive type + params
function buildGeometry(type, p = {}) {
  const d = GEOM_DEFAULTS[type] ?? {};
  if (type === 'box') {
    const bevel = p.bevel ?? d.bevel;
    if (bevel > 0.001) {
      return new RoundedBoxGeometry(1, 1, 1, p.bevelSegs ?? d.bevelSegs, bevel);
    }
    return new THREE.BoxGeometry(1, 1, 1, p.wSegs ?? d.wSegs, p.hSegs ?? d.hSegs, p.dSegs ?? d.dSegs);
  }
  if (type === 'sphere') {
    const phiLen   = ((p.phi   ?? d.phi)   * Math.PI) / 180;
    const thetaLen = ((p.theta ?? d.theta) * Math.PI) / 180;
    return new THREE.SphereGeometry(0.5, p.wSegs ?? d.wSegs, p.hSegs ?? d.hSegs,
      0, phiLen, 0, thetaLen);
  }
  if (type === 'cylinder') {
    const radTop = (p.radTop ?? d.radTop) * 0.5; // user sets 0–1, geo uses 0–0.5
    return new THREE.CylinderGeometry(radTop, 0.5, 1,
      p.radSegs ?? d.radSegs, p.hSegs ?? d.hSegs, p.open ?? d.open);
  }
  if (type === 'plane') {
    return new THREE.PlaneGeometry(1, 1, p.wSegs ?? d.wSegs, p.hSegs ?? d.hSegs);
  }
  if (type === 'rope') {
    return _buildRopeCatenaryGeo(p);
  }
  // Triggers / unsupported — return as-is
  return PRIM_GEOS[type]?.() ?? new THREE.BoxGeometry(1, 1, 1);
}

function _buildRopeCatenaryGeo(p) {
  const d = GEOM_DEFAULTS.rope;
  const segs   = Math.max(2, Math.round(p.ropeSegs   ?? d.ropeSegs));
  const radius = Math.max(0.001, p.ropeRadius ?? d.ropeRadius);
  const sag    = p.ropeSag   ?? d.ropeSag;
  const bOff   = p.anchorBOffset ?? d.anchorBOffset;
  const B      = new THREE.Vector3(bOff[0], bOff[1], bOff[2]);
  const len    = B.length() || 1;
  const pts    = [];
  for (let i = 0; i <= segs; i++) {
    const t = i / segs;
    pts.push(new THREE.Vector3(
      B.x * t,
      B.y * t - sag * len * 0.25 * 4 * t * (1 - t),
      B.z * t
    ));
  }
  const curve = new THREE.CatmullRomCurve3(pts);
  return new THREE.TubeGeometry(curve, segs, radius, 6, false);
}

// Swap geometry on an existing mesh (preserves material, position, scale etc.)
function rebuildGeometry(mesh, silent = false) {
  const type = mesh.userData.primType;
  if (!GEOM_DEFAULTS[type]) return; // only primitive types that have geom params
  const p = mesh.userData.geomParams ?? {};
  const oldGeo = mesh.geometry;
  mesh.geometry = buildGeometry(type, p);
  oldGeo.dispose();
  if (!silent) markDirty();
}

// Populate geom panel inputs from current object's geomParams
function refreshGeomPanel(obj) {
  if (!obj) return;
  const type = obj.userData.primType;
  const p = obj.userData.geomParams ?? {};
  const d = GEOM_DEFAULTS[type] ?? {};
  const set = (id, v) => { const el = document.getElementById(id); if (el && document.activeElement !== el) el.value = v; };
  const setChk = (id, v) => { const el = document.getElementById(id); if (el) el.checked = v; };

  // Hide all sub-sections, show the right one
  ['box','sphere','cylinder','plane','rope'].forEach(t => {
    const el = document.getElementById('geom-' + t);
    if (el) el.style.display = (t === type) ? '' : 'none';
  });

  if (type === 'box') {
    set('geom-bevel',      p.bevel     ?? d.bevel);
    set('geom-bevel-segs', p.bevelSegs ?? d.bevelSegs);
    set('geom-box-ws',     p.wSegs     ?? d.wSegs);
    set('geom-box-hs',     p.hSegs     ?? d.hSegs);
    set('geom-box-ds',     p.dSegs     ?? d.dSegs);
  } else if (type === 'sphere') {
    set('geom-sph-ws',    p.wSegs ?? d.wSegs);
    set('geom-sph-hs',    p.hSegs ?? d.hSegs);
    set('geom-sph-phi',   p.phi   ?? d.phi);
    set('geom-sph-theta', p.theta ?? d.theta);
  } else if (type === 'cylinder') {
    set('geom-cyl-rs', p.radSegs ?? d.radSegs);
    set('geom-cyl-hs', p.hSegs   ?? d.hSegs);
    set('geom-cyl-rt', p.radTop  ?? d.radTop);
    setChk('geom-cyl-open', p.open ?? d.open);
  } else if (type === 'plane') {
    set('geom-plane-ws', p.wSegs ?? d.wSegs);
    set('geom-plane-hs', p.hSegs ?? d.hSegs);
  } else if (type === 'rope') {
    set('geom-rope-len',  p.ropeLength  ?? d.ropeLength);
    set('geom-rope-rad',  p.ropeRadius  ?? d.ropeRadius);
    set('geom-rope-segs', p.ropeSegs    ?? d.ropeSegs);
    set('geom-rope-sag',  p.ropeSag     ?? d.ropeSag);
    set('geom-rope-damp', p.ropeDamping ?? d.ropeDamping);
    const bOff = p.anchorBOffset ?? d.anchorBOffset;
    set('geom-rope-bx', bOff[0]);
    set('geom-rope-by', bOff[1]);
    set('geom-rope-bz', bOff[2]);
    const el = document.getElementById('geom-rope-bid');
    if (el && document.activeElement !== el) el.value = (p.anchorBId != null) ? p.anchorBId : '';

    const aLabel  = document.getElementById('geom-rope-aid-label');
    const detachA = document.getElementById('btn-rope-detach-a');
    if (aLabel && detachA) {
      if (p.anchorAId != null) {
        let name = '#' + p.anchorAId;
        obj.parent?.traverse(o => { if (o.userData.editorId === p.anchorAId && o.name) name = o.name; });
        aLabel.textContent = name;
        detachA.style.display = '';
      } else {
        aLabel.textContent = '(free)';
        detachA.style.display = 'none';
      }
    }
    const bLabel  = document.getElementById('geom-rope-bid-label');
    const detachB = document.getElementById('btn-rope-detach-b');
    if (bLabel && detachB) {
      if (p.anchorBId != null) {
        let name = '#' + p.anchorBId;
        obj.parent?.traverse(o => { if (o.userData.editorId === p.anchorBId && o.name) name = o.name; });
        bLabel.textContent = name;
        detachB.style.display = '';
      } else {
        bLabel.textContent = '(free)';
        detachB.style.display = 'none';
      }
    }
  }
}

// Create a light group: actual THREE.Light + a small visual mesh, grouped together.
// The group is what gets added to E.placedGroup and attached to TransformControls.
function updateLightRangeHelper(group) {
  if (!group?.userData?.isLightGroup) return;
  // Remove old helper group
  const old = group.getObjectByName('__rangeWire__');
  if (old) { old.traverse(c => c.geometry?.dispose()); group.remove(old); }

  const type = group.userData.primType;
  const dist  = group.userData.distance ?? 10;
  const angle = group.userData.angle ?? 30;
  const col   = new THREE.Color(group.userData.lightColor || '#ffffff');
  const mat   = new THREE.LineBasicMaterial({ color: col, opacity: 0.55, transparent: true });

  const container = new THREE.Group();
  container.name = '__rangeWire__';
  container.userData.isEditorHelper = true;

  // Origin dot — always shown for every light type
  const dotMat = new THREE.MeshBasicMaterial({ color: col, toneMapped: false });
  const dot = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8), dotMat);
  dot.userData.isEditorHelper = true;
  container.add(dot);

  if (type === 'dir-light') {
    // Directional: small arrow pointing -Y to show direction
    const arrowPts = [new THREE.Vector3(0,0,0), new THREE.Vector3(0,-1.5,0)];
    container.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(arrowPts), mat));
    container.visible = !E.previewLighting;
    group.add(container);
    return;
  }

  function makeCircle(radius, axis) {
    const pts = [];
    const N = 64;
    for (let i = 0; i <= N; i++) {
      const a = (i / N) * Math.PI * 2;
      if      (axis === 'y') pts.push(new THREE.Vector3(Math.cos(a) * radius, 0, Math.sin(a) * radius));
      else if (axis === 'x') pts.push(new THREE.Vector3(0, Math.cos(a) * radius, Math.sin(a) * radius));
      else                   pts.push(new THREE.Vector3(Math.cos(a) * radius, Math.sin(a) * radius, 0));
    }
    return new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat);
  }

  if (type === 'point-light') {
    // Three orthogonal great circles showing the range sphere
    container.add(makeCircle(dist, 'y'));
    container.add(makeCircle(dist, 'x'));
    container.add(makeCircle(dist, 'z'));
  } else { // spot-light
    const rad = Math.tan(THREE.MathUtils.degToRad(Math.min(angle, 89))) * dist;
    // Base circle at -dist on Y (light points down by default)
    const baseCircle = makeCircle(rad, 'y');
    baseCircle.position.y = -dist;
    container.add(baseCircle);
    // 4 edge lines from apex (origin) to base rim
    [0, Math.PI / 2, Math.PI, 3 * Math.PI / 2].forEach(a => {
      const geo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(Math.cos(a) * rad, -dist, Math.sin(a) * rad),
      ]);
      container.add(new THREE.Line(geo, mat));
    });
  }

  container.visible = !E.previewLighting;
  group.add(container);
}

function makeLightGroup(type, params = {}) {
  const def = LIGHT_DEFAULTS[type] || {};
  const p   = { ...def, ...params };
  const col = new THREE.Color(p.lightColor || '#ffffff');

  let light;
  let helperMesh;

  if (type === 'point-light') {
    light = new THREE.PointLight(col, p.intensity ?? 1, p.distance ?? 10, p.decay ?? 2);
    helperMesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.08, 8, 6),
      new THREE.MeshBasicMaterial({ color: col, toneMapped: false })
    );
    helperMesh.name = '__lightHelper__';
    // Small rays cross
    const rayGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-0.25,0,0), new THREE.Vector3(0.25,0,0),
      new THREE.Vector3(0,-0.25,0), new THREE.Vector3(0,0.25,0),
      new THREE.Vector3(0,0,-0.25), new THREE.Vector3(0,0,0.25),
    ]);
    const rayLines = new THREE.LineSegments(rayGeo, new THREE.LineBasicMaterial({ color: col, toneMapped: false }));
    helperMesh.add(rayLines);

  } else if (type === 'spot-light') {
    light = new THREE.SpotLight(col, p.intensity ?? 1, p.distance ?? 20,
      THREE.MathUtils.degToRad(p.angle ?? 30), p.penumbra ?? 0.15, p.decay ?? 2);
    // Cone pointing in -Y (default down)
    helperMesh = new THREE.Mesh(
      new THREE.ConeGeometry(0.18, 0.35, 8, 1, true),
      new THREE.MeshBasicMaterial({ color: col, toneMapped: false, wireframe: true })
    );
    helperMesh.name = '__lightHelper__';
    helperMesh.rotation.x = Math.PI; // point cone downward along local -Y
    const dot = new THREE.Mesh(
      new THREE.SphereGeometry(0.06, 6, 5),
      new THREE.MeshBasicMaterial({ color: col, toneMapped: false })
    );
    helperMesh.add(dot);

  } else { // dir-light
    light = new THREE.DirectionalLight(col, p.intensity ?? 1);
    // Flat disc + arrow
    helperMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.22, 0.22, 0.04, 12),
      new THREE.MeshBasicMaterial({ color: col, toneMapped: false })
    );
    helperMesh.name = '__lightHelper__';
    const arrowGeo = new THREE.ConeGeometry(0.07, 0.28, 8);
    const arrow = new THREE.Mesh(arrowGeo, new THREE.MeshBasicMaterial({ color: col, toneMapped: false }));
    arrow.position.set(0, -0.2, 0);
    arrow.rotation.x = Math.PI;
    helperMesh.add(arrow);
  }

  light.name = '__light__';
  light.castShadow = p.castShadow !== false;

  const group = new THREE.Group();
  group.add(light);
  group.add(helperMesh);
  // SpotLight needs its target in the scene hierarchy; parent it to the group
  // at local (0,-1,0) so it always aims downward relative to the group's rotation.
  if (type === 'spot-light') {
    light.target.position.set(0, -1, 0);
    group.add(light.target);
  }

  group.userData.primType      = type;
  group.userData.lightColor    = p.lightColor || '#ffffff';
  group.userData.intensity     = p.intensity  ?? 1;
  group.userData.distance      = p.distance   ?? (type === 'dir-light' ? 0 : 10);
  group.userData.decay         = p.decay      ?? 2;
  group.userData.angle         = p.angle      ?? 30;       // spot only
  group.userData.penumbra      = p.penumbra   ?? 0.15;     // spot only
  group.userData.castShadow    = p.castShadow !== false;
  group.userData.isLightGroup  = true;
  group.userData.collidable    = false;

  updateLightRangeHelper(group);
  return group;
}

function makePrimMesh(type, color = 0xaaaacc) {
  const geo = PRIM_GEOS[type]?.();
  if (!geo) return null;
  const isTrigger = isTriggerType(type);
  const isSpawn   = isPlayerSpawnType(type);
  const isZombie  = isZombieType(type);
  const trigColor = type === 'custom-trigger' ? 0xffaa44 : 0x44ffcc;
  const mat = isTrigger
    ? new THREE.MeshBasicMaterial({ color: trigColor, wireframe: true, opacity: 0.6, transparent: true })
    : isSpawn
    ? new THREE.MeshBasicMaterial({ color: 0x00ff88, wireframe: true })
    : isZombie
    ? new THREE.MeshBasicMaterial({ color: zombieTypeColor(type), wireframe: true, opacity: 0.7, transparent: true })
    : new THREE.MeshStandardMaterial({ color });
  const mesh = new THREE.Mesh(geo, mat);
  if (!isTrigger && !isSpawn && !isZombie) { mesh.castShadow = mesh.receiveShadow = true; }
  return mesh;
}

// --- Per-face texture system ─────────────────────────────────────────────────
// Box geometry face indices: 0=+X(right), 1=-X(left), 2=+Y(top), 3=-Y(bottom), 4=+Z(front), 5=-Z(back)
const BOX_FACE_NAMES = ['Right (+X)', 'Left (-X)', 'Top (+Y)', 'Bottom (-Y)', 'Front (+Z)', 'Back (-Z)'];

// Compute coplanar connected face groups for arbitrary mesh geometry.
// Returns array of {tris:[triIdx,...], normal, centroid, area, key} sorted by area desc.
// Filters out groups that are too small (area < minArea) or too complex (tris > maxTris).
function computeFaceGroups(mesh, minArea = 0.002, maxTris = 60) {
  const geo = mesh.geometry;
  if (!geo?.attributes?.position) return [];
  const pos = geo.attributes.position;
  const idxArr = geo.index ? geo.index.array : null;
  const triCount = idxArr ? idxArr.length / 3 : pos.count / 3;
  if (triCount === 0) return [];

  const _v = (i) => new THREE.Vector3(pos.getX(i), pos.getY(i), pos.getZ(i));
  const vKey = (x, y, z) => `${x.toFixed(3)},${y.toFixed(3)},${z.toFixed(3)}`;
  const vi = (ti, corner) => idxArr ? idxArr[ti * 3 + corner] : ti * 3 + corner;

  // Per-triangle normals and areas
  const triNormals = new Array(triCount);
  const triAreas   = new Array(triCount);
  for (let t = 0; t < triCount; t++) {
    const a = _v(vi(t,0)), b = _v(vi(t,1)), c = _v(vi(t,2));
    const cross = b.clone().sub(a).cross(c.clone().sub(a));
    triAreas[t]   = cross.length() / 2;
    triNormals[t] = cross.normalize();
  }

  // Build edge-to-triangle adjacency (by vertex position key)
  const edgeMap = new Map();
  for (let t = 0; t < triCount; t++) {
    const verts = [vKey(pos.getX(vi(t,0)), pos.getY(vi(t,0)), pos.getZ(vi(t,0))),
                   vKey(pos.getX(vi(t,1)), pos.getY(vi(t,1)), pos.getZ(vi(t,1))),
                   vKey(pos.getX(vi(t,2)), pos.getY(vi(t,2)), pos.getZ(vi(t,2)))];
    for (let e = 0; e < 3; e++) {
      const ek = verts[e] < verts[(e+1)%3] ? `${verts[e]}|${verts[(e+1)%3]}` : `${verts[(e+1)%3]}|${verts[e]}`;
      if (!edgeMap.has(ek)) edgeMap.set(ek, []);
      edgeMap.get(ek).push(t);
    }
  }

  // BFS to find connected coplanar groups (dot product > 0.9998 ≈ < 1 degree difference)
  const visited = new Uint8Array(triCount);
  const groups  = [];
  for (let start = 0; start < triCount; start++) {
    if (visited[start]) continue;
    const N = triNormals[start];
    const group = [];
    const queue = [start];
    visited[start] = 1;
    while (queue.length) {
      const t = queue.shift();
      group.push(t);
      const verts = [vKey(pos.getX(vi(t,0)), pos.getY(vi(t,0)), pos.getZ(vi(t,0))),
                     vKey(pos.getX(vi(t,1)), pos.getY(vi(t,1)), pos.getZ(vi(t,1))),
                     vKey(pos.getX(vi(t,2)), pos.getY(vi(t,2)), pos.getZ(vi(t,2)))];
      for (let e = 0; e < 3; e++) {
        const ek = verts[e] < verts[(e+1)%3] ? `${verts[e]}|${verts[(e+1)%3]}` : `${verts[(e+1)%3]}|${verts[e]}`;
        for (const n of (edgeMap.get(ek) || [])) {
          if (!visited[n] && triNormals[n].dot(N) > 0.9998) { visited[n] = 1; queue.push(n); }
        }
      }
    }
    let area = 0;
    const centroid = new THREE.Vector3();
    for (const t of group) { area += triAreas[t]; centroid.addScaledVector(new THREE.Vector3((pos.getX(vi(t,0))+pos.getX(vi(t,1))+pos.getX(vi(t,2)))/3,(pos.getY(vi(t,0))+pos.getY(vi(t,1))+pos.getY(vi(t,2)))/3,(pos.getZ(vi(t,0))+pos.getZ(vi(t,1))+pos.getZ(vi(t,2)))/3), triAreas[t]); }
    if (area > 0) centroid.divideScalar(area);
    const key = `f_${N.x.toFixed(2)}_${N.y.toFixed(2)}_${N.z.toFixed(2)}_${centroid.x.toFixed(2)}_${centroid.y.toFixed(2)}_${centroid.z.toFixed(2)}`;
    groups.push({ tris: group, normal: N.clone(), centroid, area, key });
  }
  return groups.filter(g => g.area >= minArea && g.tris.length <= maxTris)
               .sort((a, b) => b.area - a.area);
}

// Build a THREE.Mesh overlay in scene-world space for the given triangle set of a mesh
function _buildFaceOverlayMesh(mesh, tris, color, opacity) {
  const geo    = mesh.geometry;
  const posAttr = geo.attributes.position;
  const idxArr  = geo.index ? geo.index.array : null;
  const vi = (ti, c) => idxArr ? idxArr[ti * 3 + c] : ti * 3 + c;

  const positions = [];
  for (const t of tris) {
    for (let c = 0; c < 3; c++) {
      const i = vi(t, c);
      positions.push(posAttr.getX(i), posAttr.getY(i), posAttr.getZ(i));
    }
  }
  const overlayGeo = new THREE.BufferGeometry();
  overlayGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  overlayGeo.computeVertexNormals();
  const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide });
  const overlayMesh = new THREE.Mesh(overlayGeo, mat);
  overlayMesh.renderOrder = 6;
  overlayMesh.userData.isEditorHelper = true;
  // Copy world transform from base mesh
  mesh.updateMatrixWorld(true);
  overlayMesh.applyMatrix4(mesh.matrixWorld);
  return overlayMesh;
}

// ─── Face Mode ────────────────────────────────────────────────────────────────
function enterFaceMode() {
  const obj = E.selected;
  if (!obj) { setStatus('Select an object first to enter face mode'); return; }
  // Find the first actual mesh child (or the object itself)
  let targetMesh = null;
  if (obj.isMesh) { targetMesh = obj; }
  else { obj.traverse(c => { if (c.isMesh && !c.userData.isEditorHelper && !targetMesh) targetMesh = c; }); }
  if (!targetMesh) { setStatus('Selected object has no geometry for face mode'); return; }

  E.faceModeActive  = true;
  E.faceModeGroups  = computeFaceGroups(targetMesh);
  E.faceModeHovered = -1;
  E.faceModeSelected = -1;
  if (E.faceModeGroups.length === 0) { exitFaceMode(); setStatus('No selectable faces found (faces may be too small or too complex)'); return; }

  document.getElementById('right-panel')?.classList.add('face-mode-active');
  document.getElementById('face-mode-badge').style.display = '';
  setStatus(`Face mode — ${E.faceModeGroups.length} faces found. Hover to highlight, click to select.`);
}

function exitFaceMode() {
  E.faceModeActive   = false;
  E.faceModeGroups   = [];
  E.faceModeHovered  = -1;
  E.faceModeSelected = -1;
  _clearFaceOverlay('hover');
  _clearFaceOverlay('select');
  document.getElementById('right-panel')?.classList.remove('face-mode-active');
  document.getElementById('face-mode-badge').style.display = 'none';
  setStatus('Face mode exited');
}

function _clearFaceOverlay(which) {
  const key = which === 'hover' ? 'faceHoverMesh' : 'faceSelectMesh';
  if (E[key]) { E.scene.remove(E[key]); E[key].geometry?.dispose(); E[key].material?.dispose(); E[key] = null; }
}

function _faceModeHover(e) {
  if (!E.faceModeActive || !E.selected) return;
  let targetMesh = null;
  if (E.selected.isMesh) { targetMesh = E.selected; }
  else { E.selected.traverse(c => { if (c.isMesh && !c.userData.isEditorHelper && !targetMesh) targetMesh = c; }); }
  if (!targetMesh) return;

  mouseToNDC(e);
  _ray.setFromCamera(_ndcM, E.camera);
  const hits = _ray.intersectObject(targetMesh, false);
  if (!hits.length) {
    if (E.faceModeHovered !== -1) { E.faceModeHovered = -1; _clearFaceOverlay('hover'); }
    return;
  }
  // Determine which group contains the hit triangle
  const hitFaceIdx = hits[0].faceIndex;
  const groupIdx = E.faceModeGroups.findIndex(g => g.tris.includes(hitFaceIdx));
  if (groupIdx === E.faceModeHovered) return;
  E.faceModeHovered = groupIdx;
  _clearFaceOverlay('hover');
  if (groupIdx >= 0) {
    E.faceHoverMesh = _buildFaceOverlayMesh(targetMesh, E.faceModeGroups[groupIdx].tris, 0xffaa44, 0.25);
    E.scene.add(E.faceHoverMesh);
  }
}

function _faceModeClick() {
  if (!E.faceModeActive) return;
  if (E.faceModeHovered < 0) return;
  const groupIdx = E.faceModeHovered;
  E.faceModeSelected = groupIdx;

  let targetMesh = null;
  if (E.selected.isMesh) { targetMesh = E.selected; }
  else { E.selected.traverse(c => { if (c.isMesh && !c.userData.isEditorHelper && !targetMesh) targetMesh = c; }); }

  _clearFaceOverlay('select');
  E.faceSelectMesh = _buildFaceOverlayMesh(targetMesh, E.faceModeGroups[groupIdx].tris, 0x44aaff, 0.35);
  E.scene.add(E.faceSelectMesh);

  const g = E.faceModeGroups[groupIdx];
  setStatus(`Face selected — area: ${g.area.toFixed(3)}, key: ${g.key}`);
  // Sync the texture panel to show this face's config
  E.selectedFace = null; // not a box face index
  refreshTexPanel(E.selected);
}

// Build a texture config object (stored in userData.faceTextures[key])
function makeFaceTexConfig(name, rx = 1, ry = 1, ox = 0, oy = 0, wrap = 'repeat', tilingMode = 'repeat', worldScale = 1, normalMap = null, roughnessMap = null, bumpMap = null, bumpScale = 1.0) {
  return { name, rx, ry, ox, oy, wrap, tilingMode, worldScale, normalMap, roughnessMap, bumpMap, bumpScale };
}

// Create a MeshStandardMaterial from a faceTexConfig and a base color
function makeFaceTexMat(hexColor, config) {
  const mat = new THREE.MeshStandardMaterial({ color: hexColor ?? 0xaaaacc, roughness: 0.8, metalness: 0.0 });
  if (!config) return mat;
  const loader = new THREE.TextureLoader();
  const wrapMap = { clamp: THREE.ClampToEdgeWrapping, mirror: THREE.MirroredRepeatWrapping };

  const applyUVSettings = tex => {
    tex.wrapS = tex.wrapT = wrapMap[config.wrap] ?? THREE.RepeatWrapping;
    tex.repeat.set(config.rx ?? 1, config.ry ?? 1);
    tex.offset.set(config.ox ?? 0, config.oy ?? 0);
    tex.needsUpdate = true;
  };

  if (config.name) {
    const applyTex = tex => {
      tex.colorSpace = THREE.SRGBColorSpace;
      applyUVSettings(tex);
      mat.map = tex;
      mat.color.set(0xffffff);
      mat.needsUpdate = true;
    };
    loader.load(`${ASSET_ROOT}textures/${config.name}.png`, applyTex, undefined,
      () => loader.load(`${ASSET_ROOT}textures/${config.name}.jpg`, applyTex)
    );
  }

  if (config.normalMap) {
    const applyNormal = tex => {
      applyUVSettings(tex);
      mat.normalMap = tex;
      mat.needsUpdate = true;
    };
    loader.load(`${ASSET_ROOT}textures/${config.normalMap}.png`, applyNormal, undefined,
      () => loader.load(`${ASSET_ROOT}textures/${config.normalMap}.jpg`, applyNormal)
    );
  }

  if (config.roughnessMap) {
    const applyRoughness = tex => {
      applyUVSettings(tex);
      mat.roughnessMap = tex;
      mat.roughness = 1.0;
      mat.needsUpdate = true;
    };
    loader.load(`${ASSET_ROOT}textures/${config.roughnessMap}.png`, applyRoughness, undefined,
      () => loader.load(`${ASSET_ROOT}textures/${config.roughnessMap}.jpg`, applyRoughness)
    );
  }

  if (config.bumpMap) {
    const applyBump = tex => {
      applyUVSettings(tex);
      mat.bumpMap = tex;
      mat.bumpScale = config.bumpScale ?? 1.0;
      mat.needsUpdate = true;
    };
    loader.load(`${ASSET_ROOT}textures/${config.bumpMap}.png`, applyBump, undefined,
      () => loader.load(`${ASSET_ROOT}textures/${config.bumpMap}.jpg`, applyBump)
    );
  }

  return mat;
}

// Get effective config for a face key ('all', '0'-'5', or 'f_...' face mode key)
// For face mode, also tries the selected face's key if in face mode.
function getFaceConfig(mesh, faceKey) {
  const ft = mesh.userData.faceTextures;
  if (!ft) return null;
  if (faceKey === null || faceKey === undefined) {
    // In face mode, use the selected group key
    if (E.faceModeActive && E.faceModeSelected >= 0) {
      const k = E.faceModeGroups[E.faceModeSelected]?.key;
      if (k) return ft[k] ?? ft['all'] ?? null;
    }
    return ft['all'] ?? null;
  }
  return ft[String(faceKey)] ?? ft['all'] ?? null;
}

// Set or clear the config for a face key, then rebuild materials
function setFaceConfig(mesh, faceKey, config) {
  if (!mesh.userData.faceTextures) mesh.userData.faceTextures = {};
  // Resolve the key: in face mode with no explicit key, use the selected group key
  let key = faceKey !== null && faceKey !== undefined ? String(faceKey) : 'all';
  if ((key === 'all' || key === 'null') && E.faceModeActive && E.faceModeSelected >= 0) {
    key = E.faceModeGroups[E.faceModeSelected]?.key ?? 'all';
  }

  // Mutual exclusivity between root ('all') texture and per-face ('f_...') textures
  if (config !== null && config !== undefined && config.name) {
    const ft = mesh.userData.faceTextures;
    const hasFaceModeKeys = Object.keys(ft).some(k => k.startsWith('f_'));
    const hasAll = ft['all'] && ft['all'].name;
    if (key === 'all' && hasFaceModeKeys) {
      setStatus('Cannot set a root texture: this object has per-face textures. Clear them first.');
      return;
    }
    if (key.startsWith('f_') && hasAll) {
      setStatus('Cannot set a per-face texture: this object has a root texture. Clear it first (set texture to none).');
      return;
    }
  }

  if (config === null || config === undefined) {
    delete mesh.userData.faceTextures[key];
  } else {
    mesh.userData.faceTextures[key] = config;
  }
  applyFaceTextures(mesh);
  markDirty();
}

function getMeshOpacity(obj) {
  if (obj.userData._opacity !== undefined) return obj.userData._opacity;
  if (!obj.material) return 1;
  const m = Array.isArray(obj.material) ? obj.material[0] : obj.material;
  return m?.opacity ?? 1;
}
function setMeshOpacity(obj, v) {
  if (!obj.material) return;
  obj.userData._opacity = v;
  if (isZombieType(obj.userData.primType) || isTriggerType(obj.userData.primType) || isPlayerSpawnType(obj.userData.primType)) return;
  const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
  mats.forEach(m => { m.transparent = v < 1; m.opacity = v; m.needsUpdate = true; });
}
function syncOpacityWireframe(obj) {
  const existing = obj.children?.find(c => c.userData.isOpacityWire);
  if (existing) { obj.remove(existing); existing.geometry?.dispose(); existing.material?.dispose(); }
  if (getMeshOpacity(obj) < 0.5 && obj.geometry) {
    const wire = new THREE.LineSegments(
      new THREE.WireframeGeometry(obj.geometry),
      new THREE.LineBasicMaterial({ color: 0xffffff, opacity: 0.6, transparent: true })
    );
    wire.userData.isOpacityWire = true;
    wire.userData.isEditorHelper = true;
    obj.add(wire);
  }
}

// Apply userData.faceTextures to mesh.material (multi-material for boxes with per-face overrides)
function applyFaceTextures(mesh) {
  const ft = mesh.userData.faceTextures;
  if (!ft) return;
  const baseColor = mesh.userData._baseColor ?? '#aaaacc';
  const isBox = mesh.userData.primType === 'box';
  const hasBoxPerFace = isBox && Object.keys(ft).some(k => k !== 'all' && /^\d$/.test(k));
  const hasFaceMode   = Object.keys(ft).some(k => k.startsWith('f_'));

  // Remove old face overlay children (from previous applyFaceTextures call)
  const oldOverlays = [];
  mesh.children?.forEach(c => { if (c.userData.isFaceOverlay) oldOverlays.push(c); });
  oldOverlays.forEach(c => {
    mesh.remove(c);
    c.geometry?.dispose();
    if (Array.isArray(c.material)) c.material.forEach(m => m.dispose());
    else c.material?.dispose();
  });

  // Dispose old base material(s)
  if (Array.isArray(mesh.material)) {
    mesh.material.forEach(m => m.dispose());
  } else if (mesh.material) {
    mesh.material.dispose();
  }

  if (hasBoxPerFace) {
    mesh.material = Array.from({ length: 6 }, (_, i) => {
      const cfg = ft[String(i)] ?? ft['all'] ?? null;
      return makeFaceTexMat(baseColor, cfg);
    });
  } else {
    mesh.material = makeFaceTexMat(baseColor, ft['all'] ?? null);
  }
  mesh.material.needsUpdate = true;

  // Build per-face overlay child meshes for f_... keys.
  // Each overlay is a child of this mesh so it inherits the transform automatically.
  // Tagged isEditorHelper so it's excluded from raycasting / level serialization.
  if (hasFaceMode && mesh.geometry) {
    const groups = computeFaceGroups(mesh);
    const geo     = mesh.geometry;
    const posAttr = geo.attributes.position;
    const uvAttr  = geo.attributes.uv;
    const normAttr = geo.attributes.normal;
    const idxArr  = geo.index ? geo.index.array : null;
    const vi = (ti, c) => idxArr ? idxArr[ti * 3 + c] : ti * 3 + c;

    for (const [key, cfg] of Object.entries(ft)) {
      if (!key.startsWith('f_') || !cfg?.name) continue;
      const group = groups.find(g => g.key === key);
      if (!group) continue;

      const positions = [], uvCoords = [], normals = [];
      for (const ti of group.tris) {
        for (let c = 0; c < 3; c++) {
          const i = vi(ti, c);
          positions.push(posAttr.getX(i), posAttr.getY(i), posAttr.getZ(i));
          if (uvAttr)   uvCoords.push(uvAttr.getX(i),   uvAttr.getY(i));
          if (normAttr) normals.push(normAttr.getX(i),  normAttr.getY(i),  normAttr.getZ(i));
        }
      }

      const overlayGeo = new THREE.BufferGeometry();
      overlayGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      if (uvCoords.length) overlayGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvCoords, 2));
      if (normals.length)  overlayGeo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
      else                 overlayGeo.computeVertexNormals();

      const mat = makeFaceTexMat(baseColor, cfg);
      mat.polygonOffset = true;
      mat.polygonOffsetFactor = -1;
      mat.polygonOffsetUnits  = -1;

      const overlayMesh = new THREE.Mesh(overlayGeo, mat);
      overlayMesh.renderOrder = 1;
      overlayMesh.userData.isFaceOverlay = true;
      overlayMesh.userData.isEditorHelper = true;
      mesh.add(overlayMesh);
    }
  }

  if (mesh.userData._opacity !== undefined && mesh.userData._opacity < 1) {
    const v = mesh.userData._opacity;
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    mats.forEach(m => { m.transparent = true; m.opacity = v; m.needsUpdate = true; });
  }
  syncOpacityWireframe(mesh);
}

function _attachWallBuyModel(mesh) {
  const existing = mesh.children.find(c => c.userData.isWbModelPreview);
  if (existing) { mesh.remove(existing); existing.traverse(c => { c.geometry?.dispose(); if (c.material) (Array.isArray(c.material) ? c.material : [c.material]).forEach(m => m.dispose()); }); }
  const path = mesh.userData.weaponModelPath;
  if (!path) return;
  const loader = new GLTFLoader();
  loader.load(ASSET_ROOT + path, gltf => {
    const mdl = gltf.scene;
    mdl.userData.isWbModelPreview = true;
    mdl.userData.isEditorHelper   = true;
    const opacity = mesh.userData.weaponModelOpacity ?? 1;
    const emissiveIntensity = mesh.userData.emissiveIntensity ?? 0;
    const emissiveColor = mesh.userData.emissiveColor ?? '#ffffff';
    mdl.traverse(c => {
      if (!c.isMesh || !c.material) return;
      const mats = Array.isArray(c.material) ? c.material : [c.material];
      mats.forEach(m => {
        if (opacity < 1) { m.transparent = true; m.opacity = opacity; }
        if (emissiveIntensity > 0 && 'emissive' in m) {
          m.emissive.set(emissiveColor);
          m.emissiveIntensity = emissiveIntensity;
        }
        m.needsUpdate = true;
      });
    });
    mesh.add(mdl);
    E.renderer.render(E.scene, E.camera);
  }, undefined, err => console.warn('[editor] wallbuy preview model failed:', err));
}

function _reapplyWorldTiling(mesh) {
  const ft = mesh.userData.faceTextures;
  if (!ft) return;
  let changed = false;
  for (const [key, cfg] of Object.entries(ft)) {
    if (cfg.tilingMode !== 'world' || !cfg.worldScale) continue;
    const [rx, ry] = computeWorldRepeat(mesh, key, cfg.worldScale);
    cfg.rx = rx; cfg.ry = ry;
    changed = true;
  }
  if (changed) applyFaceTextures(mesh);
}

// Compute repeat values for world-based tiling on a box face
function computeWorldRepeat(mesh, faceKey, unitsPerTile) {
  if (!unitsPerTile || unitsPerTile <= 0) return [1, 1];
  const s = mesh.scale;
  const fi = parseInt(faceKey);
  let w, h;
  if      (fi === 0 || fi === 1) { w = s.z; h = s.y; }
  else if (fi === 2 || fi === 3) { w = s.x; h = s.z; }
  else if (fi === 4 || fi === 5) { w = s.x; h = s.y; }
  else { w = s.x; h = s.z; } // 'all' — use X/Z as fallback
  return [Math.max(0.01, w / unitsPerTile), Math.max(0.01, h / unitsPerTile)];
}

// --- Face highlight ───────────────────────────────────────────────────────────
function updateFaceHighlight(mesh, faceIdx) {
  // remove old
  if (E.faceHighlightMesh) {
    if (E.faceHighlightMesh.parent) E.faceHighlightMesh.parent.remove(E.faceHighlightMesh);
    E.faceHighlightMesh = null;
  }
  if (faceIdx === null || faceIdx === undefined || !mesh) return;
  if (mesh.userData.primType !== 'box') return;

  // Local positions/rotations for each box face (unit box geometry spans -0.5 to 0.5)
  const faceParams = [
    { px: 0.501, py: 0, pz: 0, rx: 0, ry: Math.PI / 2, rz: 0 },   // 0: +X right
    { px: -0.501, py: 0, pz: 0, rx: 0, ry: -Math.PI / 2, rz: 0 },  // 1: -X left
    { px: 0, py: 0.501, pz: 0, rx: -Math.PI / 2, ry: 0, rz: 0 },   // 2: +Y top
    { px: 0, py: -0.501, pz: 0, rx: Math.PI / 2, ry: 0, rz: 0 },   // 3: -Y bottom
    { px: 0, py: 0, pz: 0.501, rx: 0, ry: 0, rz: 0 },               // 4: +Z front
    { px: 0, py: 0, pz: -0.501, rx: 0, ry: Math.PI, rz: 0 },        // 5: -Z back
  ];
  const fp = faceParams[faceIdx];
  if (!fp) return;

  const mat = new THREE.MeshBasicMaterial({
    color: 0x4499ff, transparent: true, opacity: 0.28, depthWrite: false, side: THREE.DoubleSide
  });
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), mat);
  plane.position.set(fp.px, fp.py, fp.pz);
  plane.rotation.set(fp.rx, fp.ry, fp.rz);
  plane.renderOrder = 5;
  plane.userData.isEditorHelper = true;
  mesh.add(plane);
  E.faceHighlightMesh = plane;
}

function spawnPrimFromEntry(entry) {
  if (entry.type === 'actor-spawn') {
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.3, 10, 6),
      new THREE.MeshStandardMaterial({ color: 0x44aaff, opacity: 0.7, transparent: true })
    );
    applyEntryTransform(mesh, entry);
    mesh.userData = {
      primType:           'actor-spawn',
      actorModel:         entry.actorModel || '',
      actorSourceId:      entry.actorSourceId || '',
      editorId:           entry.id,
      label:              entry.label || '',
      collidable:         false,
      spawnRadius:        entry.spawnRadius ?? 0,
      actorSpawnInterval: entry.actorSpawnInterval ?? null,
      actorSpawnMax:      entry.actorSpawnMax ?? null,
      actorHealth:        entry.actorHealth ?? null,
      actorSpeed:         entry.actorSpeed ?? null,
      actorDamage:        entry.actorDamage ?? null,
      actorCrit:          entry.actorCrit ?? null,
      persistent:         entry.persistent !== false,
      singleInstance:     entry.singleInstance === true,
      meshOverrides:      entry.meshOverrides ? { ...entry.meshOverrides } : {},
      animations:         entry.animations ? [...entry.animations] : [],
      actorRoles:         entry.actorRoles ? { ...entry.actorRoles } : {},
      actorVariants:      entry.actorVariants ? entry.actorVariants.map(v => ({ ...v })) : [],
    };
    mesh.name = entry.label || ('ActorSpawn_' + entry.id);
    if (entry.states?.length) { mesh.userData.states = entry.states; mesh.userData.currentState = 0; }
    if (entry.links?.length)  mesh.userData.links = _normalizeLinks(entry.links);
    if (entry.scripts?.length) mesh.userData.scripts = [...entry.scripts];
    E.placedGroup.add(mesh);
    return mesh;
  }
  if (isLightType(entry.type)) {
    const group = makeLightGroup(entry.type, {
      lightColor: entry.lightColor || '#ffffff',
      intensity:  entry.intensity  ?? 1,
      distance:   entry.distance   ?? 10,
      decay:      entry.decay      ?? 2,
      angle:      entry.angle      ?? 30,
      penumbra:   entry.penumbra   ?? 0.15,
      castShadow: entry.castShadow !== false,
    });
    applyEntryTransform(group, entry);
    group.userData.editorId = entry.id;
    group.userData.label    = entry.label || '';
    group.name = entry.label || (entry.type + '_' + entry.id);
    if (entry.states?.length) { group.userData.states = entry.states; group.userData.currentState = 0; }
    if (entry.links?.length)  group.userData.links        = _normalizeLinks(entry.links);
    if (entry.noSelfInteract) group.userData.noSelfInteract = true;
    if (entry.scripts?.length) group.userData.scripts = [...entry.scripts];
    E.placedGroup.add(group);
    return group;
  }

  if (isZombieType(entry.type)) {
    const mesh = makePrimMesh(entry.type, entry.color);
    if (!mesh) return null;
    applyEntryTransform(mesh, entry);
    mesh.userData.primType   = entry.type;
    mesh.userData.editorId   = entry.id;
    mesh.userData.label      = entry.label || '';
    mesh.userData.collidable = false;
    mesh.userData._baseColor = entry.color ?? '#aaaacc';
    if (entry.type === 'zombie-spawn') {
      mesh.userData.spawnRadius   = entry.spawnRadius   ?? 0;
      mesh.userData.actorModel    = entry.actorModel    ?? '';
      mesh.userData.actorVariants = entry.actorVariants ? entry.actorVariants.map(v => ({ ...v })) : [];
      mesh.userData.actorRoles    = entry.actorRoles    ? { ...entry.actorRoles }    : {};
      mesh.userData.meshOverrides = entry.meshOverrides ? { ...entry.meshOverrides } : {};
      mesh.userData.roundMin      = entry.roundMin ?? 1;
      mesh.userData.roundMax      = entry.roundMax ?? null;
    } else if (entry.type === 'zom-wallbuy') {
      mesh.userData.weaponSlug        = entry.weaponSlug        ?? '';
      mesh.userData.wallBuyCost       = entry.wallBuyCost       ?? 500;
      mesh.userData.wallBuyAmmoCost   = entry.wallBuyAmmoCost   ?? 250;
      mesh.userData.weaponDef         = entry.weaponDef         ? { ...entry.weaponDef } : null;
      mesh.userData.weaponModelPath   = entry.weaponModelPath   ?? '';
      mesh.userData.weaponModelOpacity = entry.weaponModelOpacity ?? 1;
      if (entry.weaponModelPath) _attachWallBuyModel(mesh);
    } else if (entry.type === 'zom-perk') {
      mesh.userData.perkId       = entry.perkId       ?? '';
      mesh.userData.perkCost     = entry.perkCost     ?? null;
      mesh.userData.requirePower = entry.requirePower !== false;
    } else if (entry.type === 'zom-mystery') {
      mesh.userData.mysteryBoxCost = entry.mysteryBoxCost ?? null;
      mesh.userData.weaponPool     = entry.weaponPool ? [...entry.weaponPool] : [];
    } else if (entry.type === 'zom-pap') {
      mesh.userData.tierCount    = entry.papTierCount ?? null;
      mesh.userData.requirePower = entry.requirePower !== false;
    } else if (entry.type === 'zom-ammo') {
      mesh.userData.ammoCost = entry.ammoCost ?? 500;
    } else if (entry.type === 'zom-door') {
      mesh.userData.doorCost = entry.doorCost ?? 750;
    }
    mesh.name = entry.label || (entry.type + '_' + entry.id);
    if (entry.states?.length) { mesh.userData.states = entry.states; mesh.userData.currentState = 0; }
    if (entry.links?.length)  mesh.userData.links = _normalizeLinks(entry.links);
    if (entry.scripts?.length) mesh.userData.scripts = [...entry.scripts];
    if (entry.opacity !== undefined) {
      mesh.userData._opacity = entry.opacity;
      setMeshOpacity(mesh, entry.opacity);
      syncOpacityWireframe(mesh);
    }
    if (entry.emissiveIntensity > 0 && mesh.material) {
      mesh.userData.emissiveIntensity = entry.emissiveIntensity;
      mesh.userData.emissiveColor     = entry.emissiveColor ?? '#ffffff';
      const col = new THREE.Color(entry.emissiveColor ?? '#ffffff');
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      mats.forEach(m => { if ('emissive' in m) { m.emissive.copy(col); m.emissiveIntensity = entry.emissiveIntensity; } });
    }
    E.placedGroup.add(mesh);
    return mesh;
  }

  const mesh = makePrimMesh(entry.type, entry.color);
  if (!mesh) return null;
  applyEntryTransform(mesh, entry);
  mesh.castShadow      = entry.castShadow !== false;
  mesh.userData.primType   = entry.type;
  mesh.userData.editorId   = entry.id;
  mesh.userData.label      = entry.label || '';
  mesh.userData.collidable = entry.collidable !== false;
  mesh.userData._baseColor = entry.color ?? '#aaaacc';
  if (entry.isMainFloor)   mesh.userData.isMainFloor   = true;
  if (entry.isAdjFloor)    mesh.userData.isAdjFloor    = true;
  if (entry.states?.length) { mesh.userData.states = entry.states; mesh.userData.currentState = 0; }
  if (entry.links?.length)  mesh.userData.links  = _normalizeLinks(entry.links);
  if (entry.pivotOffset)    mesh.userData.pivotOffset = entry.pivotOffset;
  if (entry.noSelfInteract) mesh.userData.noSelfInteract = true;
  if (entry.bones?.length) { mesh.userData.bones = entry.bones; mesh.userData.boneMode = entry.boneMode || 'rigid'; }
  if (entry.opacity !== undefined) {
    mesh.userData._opacity = entry.opacity;
  }
  if (entry.emissiveIntensity > 0 && mesh.material) {
    mesh.userData.emissiveIntensity = entry.emissiveIntensity;
    mesh.userData.emissiveColor     = entry.emissiveColor ?? '#ffffff';
    const col = new THREE.Color(entry.emissiveColor ?? '#ffffff');
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    mats.forEach(m => { if ('emissive' in m) { m.emissive.copy(col); m.emissiveIntensity = entry.emissiveIntensity; } });
  }
  // Geometry params (bevel, segments, etc.) — rebuild geometry if non-default
  if (entry.geomParams) {
    mesh.userData.geomParams = entry.geomParams;
    rebuildGeometry(mesh, true); // silent — don't mark dirty on load
  }
  // New per-face texture system
  if (entry.faceTextures) {
    mesh.userData.faceTextures = entry.faceTextures;
    applyFaceTextures(mesh);
  } else if (entry.texture) {
    // Backward compat: convert old single-texture format to new
    const [rx, ry] = entry.textureRepeat || [1, 1];
    mesh.userData.faceTextures = { all: makeFaceTexConfig(entry.texture, rx, ry) };
    applyFaceTextures(mesh);
  }
  if (mesh.userData._opacity !== undefined) {
    setMeshOpacity(mesh, mesh.userData._opacity);
    syncOpacityWireframe(mesh);
  }
  if (isTriggerType(entry.type)) {
    if (entry.type === 'custom-trigger') {
      mesh.userData.triggerVar      = entry.triggerVar      || '';
      mesh.userData.triggerVarOp    = entry.triggerVarOp    || 'set';
      mesh.userData.triggerVarValue = entry.triggerVarValue ?? 'true';
      mesh.userData.presenceVar     = entry.presenceVar     || '';
    } else {
      mesh.userData.saveSlot    = entry.saveSlot || 'autosave';
      mesh.userData.onceOnly    = entry.onceOnly !== false;
    }
    mesh.userData.collidable = false;
  }
  if (isPlayerSpawnType(entry.type)) {
    mesh.userData.collidable = false;
  }
  mesh.name = entry.label || (entry.type + '_' + entry.id);
  E.placedGroup.add(mesh);
  return mesh;
}

// â”€â”€â”€ Placement ghost â†’ commit â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function beginPlace(typeStr) {
  cancelPlace();
  E.placingType = typeStr;
  updatePlacingHint(true);

  const isModel   = typeStr.startsWith('model:');
  const isActor   = typeStr.startsWith('actor:');
  const isLight   = isLightType(typeStr);
  const isTrigger = isTriggerType(typeStr);
  let ghostGeo;
  if (isLight) {
    ghostGeo = new THREE.SphereGeometry(0.18, 8, 6);
  } else if (isActor) {
    ghostGeo = new THREE.SphereGeometry(0.3, 8, 6);
  } else {
    ghostGeo = isModel ? new THREE.BoxGeometry(1,1,1) : (PRIM_GEOS[typeStr]?.() ?? new THREE.BoxGeometry(1,1,1));
  }
  const trigGhostColor = E.placingType === 'custom-trigger' ? 0xffaa44 : 0x44ffcc;
  const ghostColor = isLight ? 0xffee44 : (isTrigger ? trigGhostColor : (isActor ? 0x44aaff : 0xe94560));
  E.ghostMesh = new THREE.Mesh(ghostGeo,
    new THREE.MeshStandardMaterial({ color: ghostColor, opacity: 0.45, transparent: true, depthWrite: false })
  );
  E.ghostMesh.name = '__ghost__';
  E.ghostMesh.userData.isEditorHelper = true;
  E.scene.add(E.ghostMesh);
}

function cancelPlace() {
  if (E.ghostMesh) { E.scene.remove(E.ghostMesh); E.ghostMesh = null; }
  E.placingType = null;
  updatePlacingHint(false);
  document.querySelectorAll('.prim-btn, .model-item, .actor-item').forEach(b => b.classList.remove('active'));
}

function commitPlace(worldPos) {
  if (!E.placingType || !E.levelName) return;
  const id = E.nextId++;

  if (E.placingType.startsWith('model:')) {
    const modelPath = E.placingType.slice(6);
    const ext = modelPath.split('.').pop().toLowerCase();

    if (ext === 'obj') {
      const objBase  = ASSET_ROOT + modelPath;
      const dir      = objBase.substring(0, objBase.lastIndexOf('/') + 1);
      const baseName = objBase.substring(objBase.lastIndexOf('/') + 1, objBase.lastIndexOf('.'));
      const _placeObjRoot = root => {
        root.traverse(c => { if (c.isMesh) { c.castShadow = c.receiveShadow = true; } });
        root.position.copy(worldPos);
        root.userData = { primType: 'model', modelPath, editorId: id, label: '', collidable: true };
        root.name = 'Model_' + id;
        pushUndo();
        E.placedGroup.add(root);
        selectObj(root); updateSceneList(); markDirty();
      };
      const loadObjWithMtl = materials => {
        const objLoader = new OBJLoader();
        if (materials) { materials.preload(); objLoader.setMaterials(materials); }
        objLoader.load(objBase, _placeObjRoot, undefined, err => { console.warn('OBJ load error:', err); });
      };
      const mtlLoader = new MTLLoader();
      mtlLoader.setPath(dir);
      mtlLoader.load(baseName + '.mtl', loadObjWithMtl, undefined, () => loadObjWithMtl(null));
    } else {
      const loader = ext === 'fbx' ? new FBXLoader() : new GLTFLoader();
      loader.load(ASSET_ROOT + modelPath, result => {
        const root = result.scene || result;
        root.traverse(c => {
          if (c.isMesh) {
            c.castShadow = c.receiveShadow = true;
            const mats = Array.isArray(c.material) ? c.material : (c.material ? [c.material] : []);
            mats.forEach(m => {
              m.side = THREE.DoubleSide;
              if (ext === 'fbx') {
                ['map','emissiveMap','normalMap','roughnessMap','metalnessMap','aoMap'].forEach(k => {
                  if (m[k]) m[k].colorSpace = THREE.SRGBColorSpace;
                });
              }
              m.needsUpdate = true;
            });
          }
        });
        root.position.copy(worldPos);
        root.userData = { primType: 'model', modelPath, editorId: id, label: '', collidable: true, doubleSide: true };
        root.name = 'Model_' + id;
        pushUndo();
        E.placedGroup.add(root);
        selectObj(root); updateSceneList(); markDirty();
      });
    }
  } else if (E.placingType.startsWith('image-model:')) {
    const imagePath = E.placingType.slice('image-model:'.length);
    _buildImageModelMesh(imagePath, (group, aspect) => {
      if (!group) { setStatus('Failed to load image'); return; }
      group.position.copy(worldPos);
      group.position.y += (aspect * 0.5);
      group.traverse(c => { if (c.isMesh) { c.castShadow = true; c.receiveShadow = true; } });
      group.userData = { primType: 'image-model', imagePath, editorId: id, label: '', collidable: true, _aspect: aspect, wallColor: group.userData._autoWallColor };
      group.name = 'Image_' + id;
      pushUndo();
      E.placedGroup.add(group);
      selectObj(group); updateSceneList(); markDirty();
    });
  } else if (isLightType(E.placingType)) {
    const group = makeLightGroup(E.placingType);
    group.position.copy(worldPos);
    group.position.y = 3; // place lights high by default
    group.userData.editorId = id;
    group.userData.label    = '';
    group.name = E.placingType + '_' + id;
    pushUndo();
    E.placedGroup.add(group);
    selectObj(group); updateSceneList(); markDirty();
  } else if (isTriggerType(E.placingType)) {
    const mesh = makePrimMesh(E.placingType);
    mesh.position.copy(worldPos);
    const isCustom = E.placingType === 'custom-trigger';
    mesh.userData = {
      primType:  E.placingType,
      editorId:  id,
      label:     '',
      collidable: false,
      ...(isCustom
        ? { triggerVar: '' }
        : { saveSlot: 'autosave', onceOnly: true }),
    };
    mesh.name = E.placingType + '_' + id;
    const trigVis = document.getElementById('toggle-triggers-visible');
    if (trigVis && !trigVis.checked) mesh.visible = false;
    pushUndo();
    E.placedGroup.add(mesh);
    selectObj(mesh); updateSceneList(); markDirty();
  } else if (E.placingType.startsWith('actor:')) {
    const actorPath = E.placingType.slice(6);
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.3, 10, 6),
      new THREE.MeshStandardMaterial({ color: 0x44aaff, opacity: 0.7, transparent: true })
    );
    mesh.position.copy(worldPos);
    mesh.userData = {
      primType:           'actor-spawn',
      actorModel:         actorPath,
      actorSourceId:      '',
      editorId:           id,
      label:              '',
      collidable:         false,
      spawnRadius:        0,
      actorSpawnInterval: null,
      actorSpawnMax:      null,
      actorHealth:        null,
      actorSpeed:         null,
      actorDamage:        null,
      actorCrit:          null,
      persistent:         true,
      singleInstance:     false,
      meshOverrides:      {},
      animations:         [],
      actorRoles:         {},
      actorVariants:      [],
    };
    mesh.name = 'ActorSpawn_' + id;
    pushUndo();
    E.placedGroup.add(mesh);
    selectObj(mesh); updateSceneList(); markDirty();
  } else if (E.placingType === 'rope') {
    const d = GEOM_DEFAULTS.rope;
    const mesh = makePrimMesh('rope', '#222222');
    mesh.position.copy(worldPos);
    mesh.userData = {
      primType:   'rope',
      editorId:   id,
      label:      '',
      collidable: false,
      _baseColor: '#222222',
      geomParams: { ...d, anchorBOffset: [...d.anchorBOffset] },
    };
    mesh.name = 'rope_' + id;
    rebuildGeometry(mesh, true);
    pushUndo();
    E.placedGroup.add(mesh);
    selectObj(mesh); updateSceneList(); markDirty();
  } else {
    const mesh = makePrimMesh(E.placingType);
    mesh.position.copy(worldPos);
    mesh.userData = { primType: E.placingType, editorId: id, label: '', collidable: true };
    mesh.name = E.placingType + '_' + id;
    pushUndo();
    E.placedGroup.add(mesh);
    selectObj(mesh); updateSceneList(); markDirty();
  }
  cancelPlace();
}

// â”€â”€â”€ Selection â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function selectObj(obj) {
  // If group transform is active, finalize it first so the object being
  // selected is back in E.placedGroup with correct world-space coordinates.
  // But only if the object we're selecting is NOT a member of the current group
  // (clicking a group member from the sidebar should select it individually).
  if (E.groupPivot) {
    const isMember = E.groupPivotMembers.includes(obj);
    if (!isMember) {
      E.activeGroupGid = null; // suppress re-entry from dragging-changed
      finalizeGroupTransform();
    }
  }
  if (E.selected === obj) return;
  E.selected = obj;
  E.transform.detach();
  if (obj) E.transform.attach(obj);
  updateProps(obj);
  highlightSceneList(obj);
  // Reset face selection when switching objects
  E.selectedFace = null;
  if (E.facePickMode) cancelFacePick();
  updateFaceHighlight(null, null);
  // Update pivot UI
  const hasPivot = obj?.userData.pivotOffset != null;
  document.getElementById('btn-reset-pivot').style.display = hasPivot ? '' : 'none';
  const dot = E.scene.getObjectByName('__pivotDot__');
  if (dot) dot.visible = hasPivot;
  if (obj && hasPivot) _refreshPivotHelper(obj);
}

function deselect() {
  E.selected = null;
  E.transform.detach();
  updateProps(null);
  highlightSceneList(null);
  // Hide pivot dot
  const dot = E.scene.getObjectByName('__pivotDot__');
  if (dot) dot.visible = false;
  document.getElementById('btn-reset-pivot').style.display = 'none';
  // Clear face selection
  E.selectedFace = null;
  if (E.facePickMode) cancelFacePick();
  updateFaceHighlight(null, null);
  if (E.faceModeActive) exitFaceMode();
}

// â”€â”€â”€ Properties panel â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function syncPropsFromSelected() {
  const obj = E.selected;
  if (!obj) return;
  setVec3Inputs('p', obj.position);
  setVec3Inputs('s', obj.scale);
  setRotInputs(obj.rotation);
}

function setVec3Inputs(prefix, v) {
  for (const a of ['x','y','z']) {
    const el = document.getElementById(prefix + a);
    if (el && document.activeElement !== el) el.value = v[a].toFixed(3);
  }
}

function setRotInputs(euler) {
  for (const a of ['x','y','z']) {
    const el = document.getElementById('r' + a);
    if (el && document.activeElement !== el) el.value = (euler[a] * DEG).toFixed(1);
  }
}

function _buildImageModelMesh(imagePath, onDone, wallColor) {
  const img = new Image();
  img.crossOrigin = 'anonymous';
  const exts = ['png', 'jpg', 'jpeg', 'webp'];
  const hasExt = /\.[^./\\]+$/.test(imagePath);
  let extIdx = 0;
  const tryNext = () => {
    if (hasExt) { img.src = ASSET_ROOT + imagePath; return; }
    if (extIdx >= exts.length) { onDone(null, 1); return; }
    img.src = ASSET_ROOT + imagePath + '.' + exts[extIdx++];
  };
  img.onerror = () => { if (hasExt) onDone(null, 1); else tryNext(); };
  img.onload = () => {
    const W = img.naturalWidth || 1;
    const H = img.naturalHeight || 1;
    const aspect = H / W;
    const COLS = Math.min(W, 256);
    const ROWS = Math.max(1, Math.round(COLS * aspect));
    const canvas = document.createElement('canvas');
    canvas.width = COLS; canvas.height = ROWS;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(img, 0, 0, COLS, ROWS);
    const d = ctx.getImageData(0, 0, COLS, ROWS).data;
    const getA = (c, r) => (c < 0 || c >= COLS || r < 0 || r >= ROWS) ? 0 : d[(r * COLS + c) * 4 + 3];
    const THR = 127;
    const D = 0.1;
    const verts = [], norms = [];
    const ecrss = (a1, x1, y1, a2, x2, y2) => {
      const t = (a1 === a2) ? 0.5 : Math.max(0, Math.min(1, (THR - a1) / (a2 - a1)));
      return [x1 + t * (x2 - x1), y1 + t * (y2 - y1)];
    };
    const p3 = (px, py) => [(px + 0.5) / COLS - 0.5, aspect * (0.5 - (py + 0.5) / ROWS)];
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const aTL = getA(c,r), aTR = getA(c+1,r), aBL = getA(c,r+1), aBR = getA(c+1,r+1);
        const abv = a => a >= THR;
        const idx = (abv(aTL)?8:0)|(abv(aTR)?4:0)|(abv(aBR)?2:0)|(abv(aBL)?1:0);
        if (idx === 0 || idx === 15) continue;
        const tp = () => ecrss(aTL,c,r,   aTR,c+1,r);
        const rt = () => ecrss(aTR,c+1,r, aBR,c+1,r+1);
        const bt = () => ecrss(aBL,c,r+1, aBR,c+1,r+1);
        const lt = () => ecrss(aTL,c,r,   aBL,c,r+1);
        let segs;
        switch (idx) {
          case 1:  segs = [[lt(),bt()]]; break;
          case 2:  segs = [[bt(),rt()]]; break;
          case 3:  segs = [[lt(),rt()]]; break;
          case 4:  segs = [[rt(),tp()]]; break;
          case 5:  segs = [[rt(),bt()],[lt(),tp()]]; break;
          case 6:  segs = [[bt(),tp()]]; break;
          case 7:  segs = [[lt(),tp()]]; break;
          case 8:  segs = [[tp(),lt()]]; break;
          case 9:  segs = [[tp(),bt()]]; break;
          case 10: segs = [[tp(),rt()],[bt(),lt()]]; break;
          case 11: segs = [[tp(),rt()]]; break;
          case 12: segs = [[rt(),lt()]]; break;
          case 13: segs = [[rt(),bt()]]; break;
          case 14: segs = [[bt(),lt()]]; break;
          default: segs = [];
        }
        for (const [[x1,y1],[x2,y2]] of segs) {
          const [ax,ay] = p3(x1,y1), [bx,by] = p3(x2,y2);
          const dx = bx-ax, dy = by-ay, len = Math.sqrt(dx*dx+dy*dy)||1;
          const nx = dy/len, ny = -dx/len;
          const OV = 0.005;
          verts.push(ax,ay,OV, bx,by,OV, bx,by,-D, ax,ay,OV, bx,by,-D, ax,ay,-D);
          for (let i = 0; i < 6; i++) norms.push(nx, ny, 0);
        }
      }
    }
    let sr = 0, sg = 0, sb = 0, sn = 0;
    for (let i = 0; i < d.length; i += 4) {
      if (d[i+3] > 10) { sr += d[i]; sg += d[i+1]; sb += d[i+2]; sn++; }
    }
    const sideColor = wallColor || (sn ? '#' + [sr,sg,sb].map(c => Math.round(c/sn).toString(16).padStart(2,'0')).join('') : '#888888');
    const tex = new THREE.Texture(img);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.needsUpdate = true;
    const faceMat = new THREE.MeshStandardMaterial({ map: tex, alphaTest: 0.5, roughness: 1, metalness: 0, side: THREE.FrontSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -4 });
    const sideMat  = new THREE.MeshStandardMaterial({ color: sideColor, roughness: 1, metalness: 0, side: THREE.DoubleSide });
    const frontMesh = new THREE.Mesh(new THREE.PlaneGeometry(1, aspect), faceMat);
    const backFaceMat = new THREE.MeshStandardMaterial({ map: tex, alphaTest: 0.1, roughness: 1, metalness: 0, side: THREE.BackSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -4 });
    const backMesh = new THREE.Mesh(new THREE.PlaneGeometry(1, aspect), backFaceMat);
    backMesh.position.z = -D;
    const sideGeo = new THREE.BufferGeometry();
    sideGeo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    sideGeo.setAttribute('normal',   new THREE.Float32BufferAttribute(norms, 3));
    const sideMesh = new THREE.Mesh(sideGeo, sideMat);
    const group = new THREE.Group();
    group.add(frontMesh, backMesh, sideMesh);
    group.userData._autoWallColor = '#' + [sr,sg,sb].map(c => Math.round(c/sn||0).toString(16).padStart(2,'0')).join('');
    onDone(group, aspect);
  };
  tryNext();
}

function _flipGeometryNormals(geo) {
  const normals = geo.getAttribute('normal');
  if (normals) {
    for (let i = 0; i < normals.count; i++) {
      normals.setXYZ(i, -normals.getX(i), -normals.getY(i), -normals.getZ(i));
    }
    normals.needsUpdate = true;
  }
  const index = geo.index;
  if (index) {
    for (let i = 0; i < index.count; i += 3) {
      const b = index.getX(i + 1);
      index.setX(i + 1, index.getX(i + 2));
      index.setX(i + 2, b);
    }
    index.needsUpdate = true;
  }
}

function _applyColor(obj, hex) {
  if (obj.userData.primType === 'image-model') {
    obj.userData.wallColor = hex;
    obj.traverse(c => {
      if (c.isMesh && c.material && !c.material.map) {
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { if (m.color) m.color.set(hex); });
      }
    });
    markDirty();
    return;
  }
  if (isLightType(obj.userData.primType)) {
    obj.userData.lightColor = hex;
    const col = new THREE.Color(hex);
    obj.traverse(c => {
      if (c.isLight) c.color.set(col);
      if (c.isMesh && c.material) { const mats = Array.isArray(c.material) ? c.material : [c.material]; mats.forEach(m => { if (m.color) m.color.set(col); }); }
      if ((c.isLine || c.isLineSegments) && c.material) c.material.color.set(col);
    });
  } else {
    obj.userData._baseColor = hex;
    if (obj.userData.faceTextures) {
      applyFaceTextures(obj);
    } else {
      const mats = Array.isArray(obj.material) ? obj.material : (obj.material ? [obj.material] : []);
      mats.forEach(m => { if (m.color) m.color.set(hex); });
      obj.traverse(c => {
        if (c !== obj && c.isMesh && c.material && !Array.isArray(c.material) && c.material.color) c.material.color.set(hex);
      });
    }
  }
  markDirty();
}

function updateProps(obj) {
  const selName   = document.getElementById('sel-name');
  const pathRow   = document.getElementById('model-path-row');
  const pathText  = document.getElementById('model-path-text');
  const colEl     = document.getElementById('obj-color');
  const opacityEl = document.getElementById('obj-opacity');
  const chkC      = document.getElementById('chk-collidable');
  const chkS      = document.getElementById('chk-shadow');
  const emissiveRow = document.getElementById('emissive-row');
  const emissiveColorEl = document.getElementById('obj-emissive-color');
  const emissiveIntEl   = document.getElementById('obj-emissive-intensity');
  const materialRow     = document.getElementById('material-row');
  const roughnessEl     = document.getElementById('obj-roughness');
  const metalnessEl     = document.getElementById('obj-metalness');
  const labelEl   = document.getElementById('obj-label');
  const lightProps  = document.getElementById('light-props');
  const geomProps   = document.getElementById('geom-props');
  const textureSection = document.getElementById('texture-section');
  const triggerProps = document.getElementById('trigger-props');
  const scriptsSection = document.getElementById('object-scripts-section');
  const scriptsEl      = document.getElementById('obj-scripts');

  if (!obj) {
    if (selName) selName.textContent = 'None';
    ['px','py','pz','sx','sy','sz','rx','ry','rz'].forEach(id => {
      const el = document.getElementById(id); if (el) { el.value = ''; el.disabled = true; }
    });
    if (colEl)    { colEl.disabled    = true; }
    if (opacityEl) { opacityEl.disabled = true; opacityEl.value = '1'; }
    if (chkC)    { chkC.disabled    = true; }
    if (chkS)    { chkS.disabled    = true; }
    if (labelEl) { labelEl.value = ''; labelEl.disabled = true; }
    if (pathRow) pathRow.style.display = 'none';
    if (lightProps)       lightProps.style.display       = 'none';
    if (geomProps)        geomProps.style.display        = 'none';
    if (textureSection)   textureSection.style.display   = 'none';
    if (triggerProps) triggerProps.style.display = 'none';
    if (scriptsSection) scriptsSection.style.display = 'none';
    if (scriptsEl) scriptsEl.value = '';
    ['zom-wallbuy-section','zombie-spawn-section','zom-perk-section','zom-mystery-section',
     'zom-pap-section','zom-ammo-section','zom-door-section'].forEach(id => {
      const s = document.getElementById(id); if (s) s.style.display = 'none';
    });
    const actorSpawnSection0 = document.getElementById('actor-spawn-section');
    if (actorSpawnSection0) actorSpawnSection0.style.display = 'none';
    setGroupDisplay(null);
    renderStatesPanel(null);
    renderLinksPanel(null);
    return;
  }

  const isLight     = isLightType(obj.userData.primType);
  const isTrigger   = isTriggerType(obj.userData.primType);
  const isCsgResult = obj.userData.primType === 'csg-result';
  const isMerged    = obj.userData.primType === 'merged-model';
  const isActorSpawn = obj.userData.primType === 'actor-spawn';
  const isImageModel = obj.userData.primType === 'image-model';
  const isZombie    = isZombieType(obj.userData.primType);
  const isWallBuy   = obj.userData.primType === 'zom-wallbuy';
  const isPrimitive = !isLight && !isTrigger && !isZombie && obj.userData.primType !== 'model' && !isCsgResult && !isMerged && !isActorSpawn && !isImageModel;
  const hasTexture  = isPrimitive || isCsgResult;
  const isModel     = obj.userData.primType === 'model' || isMerged;

  const meshEditSection = document.getElementById('mesh-edit-section');
  if (meshEditSection) meshEditSection.style.display = isModel ? '' : 'none';

  const modelMapsSection = document.getElementById('model-maps-section');
  if (modelMapsSection) {
    modelMapsSection.style.display = isModel ? '' : 'none';
    if (isModel) refreshModelMapsPanel(obj);
  }

  const actorSpawnSection = document.getElementById('actor-spawn-section');
  if (actorSpawnSection) {
    actorSpawnSection.style.display = isActorSpawn ? '' : 'none';
    if (isActorSpawn) {
      const modelNameEl = document.getElementById('actor-spawn-model-name');
      if (modelNameEl) modelNameEl.textContent = (obj.userData.actorModel || '').split('/').pop() || '-';
      const radiusEl = document.getElementById('actor-spawn-radius');
      if (radiusEl && document.activeElement !== radiusEl) radiusEl.value = obj.userData.spawnRadius ?? 0;
      const intervalEl = document.getElementById('actor-spawn-interval');
      if (intervalEl && document.activeElement !== intervalEl) intervalEl.value = obj.userData.actorSpawnInterval ?? '';
      const maxEl = document.getElementById('actor-spawn-max');
      if (maxEl && document.activeElement !== maxEl) maxEl.value = obj.userData.actorSpawnMax ?? '';
      const healthEl = document.getElementById('actor-health');
      if (healthEl && document.activeElement !== healthEl) healthEl.value = obj.userData.actorHealth ?? '';
      const speedEl = document.getElementById('actor-speed');
      if (speedEl && document.activeElement !== speedEl) speedEl.value = obj.userData.actorSpeed ?? '';
      const damageEl = document.getElementById('actor-damage');
      if (damageEl && document.activeElement !== damageEl) damageEl.value = obj.userData.actorDamage ?? '';
      const critEl = document.getElementById('actor-crit');
      if (critEl && document.activeElement !== critEl) critEl.value = obj.userData.actorCrit ?? '';
      const persistEl = document.getElementById('actor-persistent');
      if (persistEl) persistEl.checked = obj.userData.persistent !== false;
      const singleEl = document.getElementById('actor-single-instance');
      if (singleEl) singleEl.checked = obj.userData.singleInstance === true;
    }
  }
  if (scriptsSection) scriptsSection.style.display = '';
  if (scriptsEl && document.activeElement !== scriptsEl) {
    scriptsEl.value = _scriptListToText(obj.userData.scripts || []);
  }

  if (selName) selName.textContent = obj.name;
  ['px','py','pz','sx','sy','sz','rx','ry','rz'].forEach(id => {
    const el = document.getElementById(id); if (el) el.disabled = false;
  });
  setVec3Inputs('p', obj.position);
  setVec3Inputs('s', obj.scale);
  setRotInputs(obj.rotation);

  if (colEl) {
    const hexEl = document.getElementById('obj-color-hex');
    const matColor = Array.isArray(obj.material) ? obj.material[0]?.color : obj.material?.color;
    if (isLight) {
      colEl.disabled = false;
      colEl.value = obj.userData.lightColor || '#ffffff';
      if (hexEl && document.activeElement !== hexEl) hexEl.value = obj.userData.lightColor || '#ffffff';
    } else if (isTrigger) {
      colEl.disabled = true;
    } else if (isImageModel) {
      colEl.disabled = false;
      const wc = obj.userData.wallColor || '#888888';
      colEl.value = wc;
      if (hexEl && document.activeElement !== hexEl) hexEl.value = wc;
    } else {
      const displayColor = obj.userData._baseColor
        ?? (Array.isArray(obj.material) ? ('#' + (obj.material[0]?.color?.getHexString() ?? 'aaaacc')) : (obj.material?.color ? '#' + obj.material.color.getHexString() : null));
      colEl.disabled = !displayColor;
      if (displayColor) {
        colEl.value = displayColor;
        if (hexEl && document.activeElement !== hexEl) hexEl.value = displayColor;
      }
    }
  }
  if (opacityEl && document.activeElement !== opacityEl) {
    opacityEl.disabled = isLight;
    opacityEl.value = isLight ? '1' : +getMeshOpacity(obj).toFixed(2);
  }
  if (chkC) { chkC.disabled = isLight || isTrigger; chkC.checked = !isLight && !isTrigger && obj.userData.collidable !== false; }
  if (chkS) { chkS.disabled = isTrigger; chkS.checked = !isTrigger && (isLight ? obj.userData.castShadow !== false : obj.castShadow !== false); }
  if (labelEl) { labelEl.disabled = false; labelEl.value = obj.userData.label || ''; }

  if (pathRow && pathText) {
    const isModel = obj.userData.primType === 'model' && obj.userData.modelPath;
    pathRow.style.display = isModel ? 'block' : 'none';
    if (isModel) pathText.textContent = obj.userData.modelPath;
  }

  const colorSpaceRow = document.getElementById('model-colorspace-row');
  const colorSpaceEl  = document.getElementById('model-colorspace');
  if (colorSpaceRow && colorSpaceEl) {
    const isModelType = obj.userData.primType === 'model' && obj.userData.modelPath;
    colorSpaceRow.style.display = isModelType ? '' : 'none';
    if (isModelType) colorSpaceEl.value = obj.userData.colorSpace || 'srgb';
  }

  // Emissive row — shown for non-light, non-trigger objects
  if (emissiveRow) {
    const showEmissive = !isLight && !isTrigger;
    emissiveRow.style.display = showEmissive ? '' : 'none';
    if (showEmissive) {
      if (emissiveColorEl) emissiveColorEl.value = obj.userData.emissiveColor ?? '#ffffff';
      if (emissiveIntEl)   emissiveIntEl.value   = obj.userData.emissiveIntensity ?? 0;
    }
  }

  // Material row (roughness/metalness) — shown for non-light, non-trigger objects
  if (materialRow) {
    const showMat = !isLight && !isTrigger;
    materialRow.style.display = showMat ? '' : 'none';
    if (showMat && document.activeElement !== roughnessEl && document.activeElement !== metalnessEl) {
      if (roughnessEl) roughnessEl.value = +(obj.userData.roughness ?? 1).toFixed(2);
      if (metalnessEl) metalnessEl.value = +(obj.userData.metalness ?? 0).toFixed(2);
    }
    const doubleSideEl = document.getElementById('chk-double-side');
    const invertNormEl = document.getElementById('chk-invert-normals');
    if (doubleSideEl) doubleSideEl.checked = obj.userData.doubleSide === true;
    if (invertNormEl) invertNormEl.checked = obj.userData.invertNormals === true;
    const pbrRow   = document.getElementById('convert-pbr-row');
    const pbrLabel = document.getElementById('convert-pbr-label');
    if (pbrRow) {
      const isModelObj = obj.userData.primType === 'model' && obj.userData.modelPath;
      const alreadyPbr = obj.userData.pbrConverted === true;
      pbrRow.style.display = (isModelObj && !alreadyPbr) ? '' : 'none';
      if (pbrLabel) pbrLabel.textContent = alreadyPbr ? '' : 'Non-PBR material \u2014 roughness/metalness may be inactive';
    }
  }

  // Geometry params — only for editable primitives
  const hasGeomParams = isPrimitive && !!GEOM_DEFAULTS[obj.userData.primType];
  if (geomProps) {
    geomProps.style.display = hasGeomParams ? '' : 'none';
    if (hasGeomParams) refreshGeomPanel(obj);
  }

  // Texture section — for primitives and CSG results (not lights, triggers, or models)
  if (textureSection) {
    textureSection.style.display = hasTexture ? '' : 'none';
    if (hasTexture) {
      const faceSelectRow    = document.getElementById('face-select-row');
      const faceModeTexRow   = document.getElementById('face-mode-tex-row');
      const isBox = obj.userData.primType === 'box';
      if (E.faceModeActive) {
        if (faceSelectRow)  faceSelectRow.style.display  = 'none';
        if (faceModeTexRow) faceModeTexRow.style.display = '';
        const lbl = document.getElementById('face-mode-tex-label');
        if (lbl) {
          lbl.textContent = E.faceModeSelected >= 0
            ? `Editing face ${E.faceModeSelected + 1} of ${E.faceModeGroups.length} — texture applies to highlighted region`
            : 'No face selected — click a face in the viewport';
        }
      } else {
        if (faceSelectRow)  faceSelectRow.style.display  = isBox ? '' : 'none';
        if (faceModeTexRow) faceModeTexRow.style.display = 'none';
      }
      refreshTexPanel(obj);
    }
  }

  // Light properties
  if (lightProps) {
    lightProps.style.display = isLight ? '' : 'none';
    if (isLight) {
      const setLightInput = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
      setLightInput('light-intensity', obj.userData.intensity ?? 1);
      setLightInput('light-distance',  obj.userData.distance  ?? 10);
      setLightInput('light-angle',     obj.userData.angle     ?? 30);
      setLightInput('light-penumbra',  obj.userData.penumbra  ?? 0.15);
      setLightInput('light-decay',     obj.userData.decay     ?? 2);
      // Show/hide spot-only rows
      const isSpot = obj.userData.primType === 'spot-light';
      const angleRow    = document.getElementById('light-angle-row');
      const penumbraRow = document.getElementById('light-penumbra-row');
      const distRow     = document.getElementById('light-distance-row');
      const decayRow    = document.getElementById('light-decay-row');
      if (angleRow)    angleRow.style.display    = isSpot ? '' : 'none';
      if (penumbraRow) penumbraRow.style.display  = isSpot ? '' : 'none';
      if (distRow)     distRow.style.display      = obj.userData.primType === 'dir-light' ? 'none' : '';
      if (decayRow)    decayRow.style.display     = obj.userData.primType === 'dir-light' ? 'none' : '';
    }
  }

  // Trigger properties
  if (triggerProps) {
    triggerProps.style.display = isTrigger ? '' : 'none';
    if (isTrigger) {
      const isCustom = obj.userData.primType === 'custom-trigger';
      const labelEl  = triggerProps.querySelector('.trigger-type-label');
      if (labelEl) labelEl.textContent = isCustom ? 'Custom Trigger' : 'Save Trigger';

      // Show save-trigger rows only for save-trigger
      const saveRows = triggerProps.querySelectorAll('.save-trigger-row');
      saveRows.forEach(r => { r.style.display = isCustom ? 'none' : ''; });
      const customRows = triggerProps.querySelectorAll('.custom-trigger-row');
      customRows.forEach(r => { r.style.display = isCustom ? '' : 'none'; });

      const slotEl    = document.getElementById('trigger-slot');
      const onceEl    = document.getElementById('trigger-once');
      const varNameEl = document.getElementById('trigger-var-name');
      if (!isCustom) {
        if (slotEl    && document.activeElement !== slotEl)    slotEl.value  = obj.userData.saveSlot || 'autosave';
        if (onceEl)                                             onceEl.checked = obj.userData.onceOnly !== false;
      } else {
        const presenceSel = document.getElementById('trigger-presence-var');
        _populateVarSelect(presenceSel, obj.userData.presenceVar || '');
        const varSel = document.getElementById('trigger-var-name');
        _populateVarSelect(varSel, obj.userData.triggerVar || '');
        const opEl  = document.getElementById('trigger-var-op');
        const valEl = document.getElementById('trigger-var-value');
        if (opEl  && document.activeElement !== opEl)  opEl.value  = obj.userData.triggerVarOp    || 'set';
        if (valEl && document.activeElement !== valEl) valEl.value = String(obj.userData.triggerVarValue ?? 'true');
      }
    }
  }

  // Zombie type sections — hide all first, then show the matching one below
  ['zom-wallbuy-section','zombie-spawn-section','zom-perk-section','zom-mystery-section',
   'zom-pap-section','zom-ammo-section','zom-door-section'].forEach(id => {
    const s = document.getElementById(id); if (s) s.style.display = 'none';
  });

  // Wall buy weapon definition section
  const wbSection = document.getElementById('zom-wallbuy-section');
  if (wbSection) {
    wbSection.style.display = isWallBuy ? '' : 'none';
    if (isWallBuy) {
      const ud  = obj.userData;
      const def = ud.weaponDef ?? {};
      const setV = (id, val) => { const el = document.getElementById(id); if (el && document.activeElement !== el) el.value = val ?? ''; };
      const setC = (id, val) => { const el = document.getElementById(id); if (el) el.checked = !!val; };
      setV('wb-slug',         ud.weaponSlug           ?? '');
      setV('wb-label',        def.label               ?? '');
      setV('wb-cost',         ud.wallBuyCost          ?? 500);
      setV('wb-ammo-cost',    ud.wallBuyAmmoCost      ?? 250);
      setV('wb-damage',       def.damage              ?? '');
      setV('wb-clip',         def.clipSize            ?? '');
      setV('wb-reserve',      def.reserveAmmo         ?? '');
      setV('wb-reload',       def.reloadTime          ?? '');
      setV('wb-firerate',     def.fireRate            ?? '');
      setV('wb-spread',       def.spreadAngle         ?? '');
      setV('wb-pellets',      def.pelletsPerShot      ?? '');
      setV('wb-model-opacity',ud.weaponModelOpacity   ?? 1);
      setC('wb-auto',         def.isAuto);
      const modelEl = document.getElementById('wb-model-name');
      if (modelEl) modelEl.textContent = ud.weaponModelPath ? (ud.weaponModelPath.split('/').pop() || ud.weaponModelPath) : '-';
    }
  }

  // Zombie spawn section
  const zsSection = document.getElementById('zombie-spawn-section');
  if (zsSection) {
    const isZS = obj.userData.primType === 'zombie-spawn';
    zsSection.style.display = isZS ? '' : 'none';
    if (isZS) {
      const setV = (id, val) => { const el = document.getElementById(id); if (el && document.activeElement !== el) el.value = val ?? ''; };
      setV('zs-radius',    obj.userData.spawnRadius ?? 0);
      setV('zs-round-min', obj.userData.roundMin ?? 1);
      setV('zs-round-max', obj.userData.roundMax ?? '');
      const modelEl = document.getElementById('zs-model-name');
      if (modelEl) modelEl.textContent = obj.userData.actorModel ? (obj.userData.actorModel.split('/').pop() || obj.userData.actorModel) : '-';
    }
  }

  // Perk section
  const perkSection = document.getElementById('zom-perk-section');
  if (perkSection) {
    const isPerk = obj.userData.primType === 'zom-perk';
    perkSection.style.display = isPerk ? '' : 'none';
    if (isPerk) {
      const setV = (id, val) => { const el = document.getElementById(id); if (el && document.activeElement !== el) el.value = val ?? ''; };
      setV('perk-id',   obj.userData.perkId   ?? '');
      setV('perk-cost', obj.userData.perkCost ?? '');
      const el = document.getElementById('perk-require-power');
      if (el) el.checked = obj.userData.requirePower !== false;
    }
  }

  // Mystery box section
  const mystSection = document.getElementById('zom-mystery-section');
  if (mystSection) {
    const isMyst = obj.userData.primType === 'zom-mystery';
    mystSection.style.display = isMyst ? '' : 'none';
    if (isMyst) {
      const el = document.getElementById('mystery-cost');
      if (el && document.activeElement !== el) el.value = obj.userData.mysteryBoxCost ?? '';
      const poolEl = document.getElementById('mystery-pool');
      if (poolEl && document.activeElement !== poolEl) poolEl.value = (obj.userData.weaponPool ?? []).join('\n');
    }
  }

  // Pack-a-Punch section
  const papSection = document.getElementById('zom-pap-section');
  if (papSection) {
    const isPAP = obj.userData.primType === 'zom-pap';
    papSection.style.display = isPAP ? '' : 'none';
    if (isPAP) {
      const setV = (id, val) => { const el = document.getElementById(id); if (el && document.activeElement !== el) el.value = val ?? ''; };
      setV('pap-tiers',      obj.userData.tierCount ?? '');
      const el = document.getElementById('pap-require-power');
      if (el) el.checked = obj.userData.requirePower !== false;
    }
  }

  // Ammo section
  const ammoSection = document.getElementById('zom-ammo-section');
  if (ammoSection) {
    const isAmmo = obj.userData.primType === 'zom-ammo';
    ammoSection.style.display = isAmmo ? '' : 'none';
    if (isAmmo) {
      const el = document.getElementById('ammo-cost');
      if (el && document.activeElement !== el) el.value = obj.userData.ammoCost ?? 500;
    }
  }

  // Door section
  const doorSection = document.getElementById('zom-door-section');
  if (doorSection) {
    const isDoor = obj.userData.primType === 'zom-door';
    doorSection.style.display = isDoor ? '' : 'none';
    if (isDoor) {
      const el = document.getElementById('door-cost');
      if (el && document.activeElement !== el) el.value = obj.userData.doorCost ?? 750;
    }
  }

  setGroupDisplay(findGroupOfObj(obj));
  renderStatesPanel(obj);
  renderLinksPanel(obj);
}

function findGroupOfObj(obj) {
  if (!obj) return null;
  const id = obj.userData.editorId;
  for (const [gid, g] of Object.entries(E.groups)) {
    if (g.ids.has(id)) return gid;
  }
  return null;
}

function setGroupDisplay(gid) {
  const nameLbl = document.getElementById('sel-group-name');
  const movBtn  = document.getElementById('btn-move-group');
  const panel   = document.getElementById('right-panel');
  const g = gid && E.groups[gid];
  if (nameLbl) nameLbl.textContent = g ? g.name : '-';
  if (movBtn) movBtn.style.display = g ? '' : 'none';
}

// â”€â”€â”€ Scene list â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function updateSceneList() {
  const list  = document.getElementById('scene-list');
  const count = document.getElementById('obj-count');
  if (!list) return;
  list.innerHTML = '';
  let n = 0;
  E.placedGroup.children.forEach(obj => {
    if (obj.userData.isEditorHelper) return;
    n++;
    const div = document.createElement('div');
    div.className = 'scene-list-item' + (obj === E.selected ? ' selected' : '');
    div.textContent = obj.name;
    div.title = obj.name;
    div.addEventListener('click', () => {
      selectObj(obj);
      E.orbit.target.copy(obj.position);
    });
    list.appendChild(div);
  });
  if (count) count.textContent = n;
}

function highlightSceneList(obj) {
  const placed = E.placedGroup.children.filter(o => !o.userData.isEditorHelper);
  document.querySelectorAll('#scene-list .scene-list-item').forEach((el, i) => {
    el.classList.toggle('selected', placed[i] === obj);
  });
}

// â”€â”€â”€ Groups panel â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function updateGroupsPanel() {
  const panel = document.getElementById('groups-panel');
  const count = document.getElementById('group-count');
  if (!panel) return;
  panel.innerHTML = '';
  const gids = Object.keys(E.groups);
  if (count) count.textContent = gids.length;

  gids.forEach(gid => {
    const g = E.groups[gid];
    if (!(gid in E.groupCollapsed)) E.groupCollapsed[gid] = true;
    const collapsed = E.groupCollapsed[gid];

    const header = document.createElement('div');
    header.className = 'group-header';
    header.innerHTML = `<span class="collapse-arrow">${collapsed ? '>' : 'v'}</span>
      <span class="group-name-lbl">${escHtml(g.name)}</span>`;
    header.addEventListener('click', () => {
      E.groupCollapsed[gid] = !E.groupCollapsed[gid];
      updateGroupsPanel();
    });
    panel.appendChild(header);

    if (!collapsed) {
      [...g.ids].forEach(mid => {
        const obj = E.placedGroup.children.find(o => o.userData.editorId === mid);
        const row = document.createElement('div');
        row.className = 'group-entry' + (obj === E.selected ? ' selected' : '');
        row.innerHTML = `<span class="ge-name">${escHtml(obj ? obj.name : `(#${mid})`)}</span>
          <button class="ge-rm" title="Remove from group">X</button>`;
        row.addEventListener('click', e => {
          if (e.target.classList.contains('ge-rm')) return;
          if (obj) { selectObj(obj); E.orbit.target.copy(obj.position); }
        });
        row.querySelector('.ge-rm').addEventListener('click', () => {
          pushUndo();
          g.ids.delete(mid);
          if (g.ids.size === 0) delete E.groups[gid];
          updateGroupsPanel();
          if (E.selected) setGroupDisplay(findGroupOfObj(E.selected));
          markDirty();
        });
        panel.appendChild(row);
      });
    }
  });
}

// â”€â”€â”€ Group transform â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function beginGroupTransform(gid) {
  if (!gid || !E.groups[gid]) return;
  const members = [...E.groups[gid].ids]
    .map(id => E.placedGroup.children.find(o => o.userData.editorId === id))
    .filter(Boolean);
  if (!members.length) return;
  pushUndo();
  E.activeGroupGid = gid;

  const center = new THREE.Vector3();
  members.forEach(m => center.add(m.position));
  center.divideScalar(members.length);

  const pivot = new THREE.Group();
  pivot.position.copy(center);
  pivot.name = '__groupPivot__';
  pivot.userData.isEditorHelper = true;
  E.scene.add(pivot);

  members.forEach(m => {
    E.placedGroup.remove(m);
    m.position.sub(center);
    pivot.add(m);
  });

  E.groupPivot = pivot;
  E.groupPivotMembers = members;
  E.transform.attach(pivot);
  // Show group-mode indicator
  const panel = document.getElementById('right-panel');
  if (panel) panel.classList.add('grp-mode-active');
  const badge = document.getElementById('grp-mode-badge');
  if (badge) badge.style.display = 'inline-block';
  document.getElementById('btn-move-group')?.classList.add('active');
  setStatus(`Group mode: ${E.groups[gid]?.name || gid} — drag gizmo to move group, G or Esc to exit`);
}

function finalizeGroupTransform() {
  if (!E.groupPivot) return;
  E.activeGroupGid = null;
  // Clear group-mode indicator
  const panel = document.getElementById('right-panel');
  if (panel) panel.classList.remove('grp-mode-active');
  const badge = document.getElementById('grp-mode-badge');
  if (badge) badge.style.display = 'none';
  document.getElementById('btn-move-group')?.classList.remove('active');
  setStatus('Group mode exited');
  E.groupPivotMembers.forEach(m => {
    const wp = new THREE.Vector3();
    const wq = new THREE.Quaternion();
    const ws = new THREE.Vector3();
    m.getWorldPosition(wp);
    m.getWorldQuaternion(wq);
    m.getWorldScale(ws);
    E.groupPivot.remove(m);
    m.position.copy(wp);
    m.quaternion.copy(wq);
    m.scale.copy(ws);
    E.placedGroup.add(m);
  });
  E.scene.remove(E.groupPivot);
  E.groupPivot = null;
  E.groupPivotMembers = [];
  E.transform.detach();
  if (E.selected) E.transform.attach(E.selected);
  markDirty(); updateSceneList();
}

// â”€â”€â”€ Clone / Delete â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function cloneSelected() {
  if (!E.selected || E.selected.userData.isRef) return;
  pushUndo();
  const src = E.selected;
  const clone = src.clone();
  const srcUD = src.userData;
  clone.userData = {
    ...srcUD,
    editorId: E.nextId++,
    label: (srcUD.label || '') + '_copy',
    states: srcUD.states ? JSON.parse(JSON.stringify(srcUD.states)) : undefined,
  };
  clone.position.x += 1;
  clone.name = src.name + '_copy';
  E.placedGroup.add(clone);
  selectObj(clone);
  updateSceneList(); markDirty();
}

function cloneGroup(gid) {
  if (!gid || !E.groups[gid]) return;
  pushUndo();
  const g = E.groups[gid];
  const memberIds = [...g.ids];
  const idMap = {};

  const clones = memberIds.map(mid => {
    const src = E.placedGroup.children.find(o => o.userData.editorId === mid);
    if (!src) return null;
    const c = src.clone();
    const newId = E.nextId++;
    idMap[mid] = newId;
    const srcUD = src.userData;
    c.userData = {
      ...srcUD,
      editorId: newId,
      states: srcUD.states ? JSON.parse(JSON.stringify(srcUD.states)) : undefined,
      links: srcUD.links ? [...srcUD.links] : undefined,
    };
    c.position.x += 1;
    c.name = src.name + '_copy';
    return c;
  }).filter(Boolean);

  clones.forEach(c => {
    if (c.userData.links) {
      c.userData.links = c.userData.links.map(l => {
        const newId = idMap[l.id] ?? l.id;
        return newId === l.id ? l : { ...l, id: newId };
      });
    }
    E.placedGroup.add(c);
  });

  const newGid = 'g' + Date.now();
  E.groups[newGid] = { name: g.name + '_copy', ids: new Set(clones.map(c => c.userData.editorId)) };
  E.groupCollapsed[newGid] = true;

  updateSceneList(); updateGroupsPanel(); markDirty();
}

function deleteSelected() {
  if (!E.selected || E.selected.userData.isRef) return;
  pushUndo();
  const id = E.selected.userData.editorId;
  for (const g of Object.values(E.groups)) g.ids.delete(id);
  for (const gid of Object.keys(E.groups)) { if (E.groups[gid].ids.size === 0) delete E.groups[gid]; }
  E.placedGroup.remove(E.selected);
  deselect();
  updateSceneList(); updateGroupsPanel(); markDirty();
}

// ─── Texture panel refresh ────────────────────────────────────────────────────
function refreshTexPanel(obj) {
  if (!obj) return;
  let faceKey;
  if (E.faceModeActive && E.faceModeSelected >= 0) {
    faceKey = E.faceModeGroups[E.faceModeSelected]?.key ?? 'all';
  } else {
    faceKey = E.selectedFace !== null ? String(E.selectedFace) : 'all';
  }
  const cfg      = getFaceConfig(obj, faceKey) ?? { rx: 1, ry: 1, ox: 0, oy: 0, wrap: 'repeat', tilingMode: 'repeat', worldScale: 1 };

  const set = (id, val) => { const el = document.getElementById(id); if (el && document.activeElement !== el) el.value = val; };
  set('tex-name',        cfg.name   || '');
  set('tex-repeat-x',   cfg.rx     ?? 1);
  set('tex-repeat-y',   cfg.ry     ?? 1);
  set('tex-offset-x',   cfg.ox     ?? 0);
  set('tex-offset-y',   cfg.oy     ?? 0);
  set('tex-world-scale', cfg.worldScale ?? 1);
  set('tex-normal-map',    cfg.normalMap    || '');
  set('tex-roughness-map', cfg.roughnessMap || '');
  set('tex-bump-map',      cfg.bumpMap      || '');
  set('tex-bump-scale',    cfg.bumpScale    ?? 1.0);

  const tilingEl = document.getElementById('tex-tiling-mode');
  if (tilingEl) tilingEl.value = cfg.tilingMode || 'repeat';
  _syncTilingModeUI(cfg.tilingMode || 'repeat');

  const wrapEl = document.getElementById('tex-wrap');
  if (wrapEl) wrapEl.value = cfg.wrap || 'repeat';

  const faceEl = document.getElementById('tex-face');
  if (faceEl) {
    if (E.faceModeActive && E.faceModeSelected >= 0) {
      faceEl.value = 'all';
    } else {
      faceEl.value = E.selectedFace !== null ? String(E.selectedFace) : 'all';
    }
  }
  // Update face mode indicator label if visible
  const lbl = document.getElementById('face-mode-tex-label');
  if (lbl && E.faceModeActive) {
    if (E.faceModeSelected >= 0) {
      const gKey = E.faceModeGroups[E.faceModeSelected]?.key ?? '?';
      lbl.textContent = `Face ${E.faceModeSelected + 1}/${E.faceModeGroups.length}  key: ${gKey}`;
    } else {
      lbl.textContent = 'No face selected — click a face in the viewport';
    }
  }
}

function _syncTilingModeUI(mode) {
  const repeatRow = document.getElementById('tex-repeat-row');
  const worldRow  = document.getElementById('tex-world-row');
  if (repeatRow) repeatRow.style.display = mode === 'world' ? 'none' : 'flex';
  if (worldRow)  { worldRow.style.display = mode === 'world' ? 'flex' : 'none'; }
}

// Build a config from current panel inputs
function _panelToFaceConfig() {
  const g = id => { const el = document.getElementById(id); return el ? el.value : ''; };
  const gf = id => parseFloat(g(id)) || 0;
  const tilingMode = g('tex-tiling-mode') || 'repeat';
  return makeFaceTexConfig(
    g('tex-name').trim() || null,
    Math.max(0.01, parseFloat(g('tex-repeat-x')) || 1),
    Math.max(0.01, parseFloat(g('tex-repeat-y')) || 1),
    gf('tex-offset-x'), gf('tex-offset-y'),
    g('tex-wrap') || 'repeat', tilingMode,
    Math.max(0.01, parseFloat(g('tex-world-scale')) || 1),
    g('tex-normal-map').trim() || null,
    g('tex-roughness-map').trim() || null,
    g('tex-bump-map').trim() || null,
    Math.max(0, parseFloat(g('tex-bump-scale')) || 1.0)
  );
}

function applyCurrentFaceConfig() {
  const obj = E.selected;
  if (!obj) return;
  pushUndo();
  let faceKey;
  if (E.faceModeActive && E.faceModeSelected >= 0) {
    faceKey = E.faceModeGroups[E.faceModeSelected]?.key ?? 'all';
  } else {
    faceKey = E.selectedFace !== null ? String(E.selectedFace) : 'all';
  }
  const cfg = _panelToFaceConfig();
  // World mode: recompute repeat from object scale
  if (cfg.tilingMode === 'world') {
    const [rx, ry] = computeWorldRepeat(obj, faceKey, cfg.worldScale);
    cfg.rx = rx; cfg.ry = ry;
    document.getElementById('tex-repeat-x').value = rx.toFixed(2);
    document.getElementById('tex-repeat-y').value = ry.toFixed(2);
  }
  // Stretch mode: force 1×1
  if (cfg.tilingMode === 'stretch') { cfg.rx = 1; cfg.ry = 1; cfg.ox = 0; cfg.oy = 0; }
  setFaceConfig(obj, faceKey, cfg.name ? cfg : null);
}

// ─── Face pick mode ────────────────────────────────────────────────────────────
function beginFacePick() {
  if (!E.selected || E.selected.userData.primType !== 'box') {
    setStatus('Select a box object to pick a face'); return;
  }
  E.facePickMode = true;
  document.getElementById('face-pick-hint').style.display = '';
  document.getElementById('btn-pick-face').textContent = 'Cancel';
  setStatus('Click a face on the selected object - Esc cancels');
}

function cancelFacePick() {
  E.facePickMode = false;
  document.getElementById('face-pick-hint').style.display = 'none';
  document.getElementById('btn-pick-face').textContent = 'Pick';
  setStatus('Face pick cancelled');
}

function applyFacePick(faceIdx) {
  E.selectedFace = faceIdx;
  E.facePickMode = false;
  document.getElementById('face-pick-hint').style.display = 'none';
  document.getElementById('btn-pick-face').textContent = 'Pick';
  const faceEl = document.getElementById('tex-face');
  if (faceEl) faceEl.value = String(faceIdx);
  updateFaceHighlight(E.selected, faceIdx);
  refreshTexPanel(E.selected);
  setStatus(`Face selected: ${BOX_FACE_NAMES[faceIdx]}`);
}

// ─── UV Editor ────────────────────────────────────────────────────────────────
function openUVEditor() {
  const obj = E.selected;
  if (!obj) return;
  const faceKey = E.selectedFace !== null ? String(E.selectedFace) : 'all';
  const cfg = getFaceConfig(obj, faceKey) ?? {};

  // Sync modal inputs
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
  set('uv-ox', cfg.ox ?? 0);
  set('uv-oy', cfg.oy ?? 0);
  set('uv-rx', cfg.rx ?? 1);
  set('uv-ry', cfg.ry ?? 1);

  const label = document.getElementById('uv-face-label');
  if (label) label.textContent = E.selectedFace !== null ? BOX_FACE_NAMES[E.selectedFace] : 'All Faces';

  const modal = document.getElementById('uv-modal');
  modal.style.display = 'block';

  _loadUVEditorImage(cfg.name);
}

function closeUVEditor() {
  document.getElementById('uv-modal').style.display = 'none';
}

function makeDraggable(modalId, handleId) {
  const modal = document.getElementById(modalId);
  const handle = document.getElementById(handleId);
  if (!modal || !handle) return;
  let ox = 0, oy = 0, startX = 0, startY = 0, dragging = false;
  handle.addEventListener('mousedown', e => {
    if (e.target.tagName === 'BUTTON') return;
    dragging = true;
    const r = modal.getBoundingClientRect();
    startX = e.clientX; startY = e.clientY;
    ox = r.left; oy = r.top;
    modal.style.transform = 'none';
    modal.style.left = ox + 'px';
    modal.style.top  = oy + 'px';
    handle.style.cursor = 'grabbing';
    e.preventDefault();
  });
  document.addEventListener('mousemove', e => {
    if (!dragging) return;
    const dx = e.clientX - startX, dy = e.clientY - startY;
    const vw = window.innerWidth, vh = window.innerHeight;
    const mw = modal.offsetWidth,  mh = modal.offsetHeight;
    const nx = Math.max(0, Math.min(vw - mw, ox + dx));
    const ny = Math.max(0, Math.min(vh - mh, oy + dy));
    modal.style.left = nx + 'px';
    modal.style.top  = ny + 'px';
  });
  document.addEventListener('mouseup', () => {
    if (!dragging) return;
    dragging = false;
    handle.style.cursor = 'grab';
  });
}

// Compute planar projection of a face group into 2D canvas coordinates.
// Returns { triUVs: [[[x,y],[x,y],[x,y]],...], W, H } where x/y are already in canvas pixels.
// The projection uses world-space tangent frame of the face, preserves physical aspect ratio,
// and always produces a consistently-oriented (non-mirrored) result.
function _computeFacePlanarProj(mesh, faceGroup) {
  const N   = faceGroup.normal.clone().normalize();
  const ref = Math.abs(N.y) < 0.9 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
  const T   = ref.clone().sub(N.clone().multiplyScalar(N.dot(ref))).normalize();
  const B   = new THREE.Vector3().crossVectors(N, T).normalize();

  const geo    = mesh.geometry;
  const posAttr = geo.attributes.position;
  const idxArr  = geo.index ? geo.index.array : null;
  const vi = (ti, c) => idxArr ? idxArr[ti * 3 + c] : ti * 3 + c;

  mesh.updateMatrixWorld(true);
  const mw = mesh.matrixWorld;

  let minU = Infinity, maxU = -Infinity, minV = Infinity, maxV = -Infinity;
  const rawProj = faceGroup.tris.map(ti => {
    const pts = [];
    for (let c = 0; c < 3; c++) {
      const i = vi(ti, c);
      const wp = new THREE.Vector3(posAttr.getX(i), posAttr.getY(i), posAttr.getZ(i)).applyMatrix4(mw);
      const u = T.dot(wp), v = B.dot(wp);
      pts.push([u, v]);
      if (u < minU) minU = u; if (u > maxU) maxU = u;
      if (v < minV) minV = v; if (v > maxV) maxV = v;
    }
    return pts;
  });

  const rangeU = maxU - minU || 1;
  const rangeV = maxV - minV || 1;
  const aspect  = rangeU / rangeV;
  const MAX = 2048;
  const W = aspect >= 1 ? MAX : Math.round(MAX * aspect);
  const H = aspect >= 1 ? Math.round(MAX / aspect) : MAX;

  const triUVs = rawProj.map(pts => pts.map(([u, v]) => [
    ((u - minU) / rangeU) * W,
    ((v - minV) / rangeV) * H,
  ]));

  return { triUVs, W, H };
}

// ─────────────────────── Model / Bone Editor ───────────────────────

function _genBoneId(obj) {
  const existing = (obj.userData.bones || []).map(b => b.id);
  let n = 0;
  while (existing.includes(`bone_${n}`)) n++;
  return `bone_${n}`;
}

function _makeBoneMarkerMesh(selected) {
  const geo = new THREE.SphereGeometry(0.07, 8, 6);
  const mat = new THREE.MeshBasicMaterial({ color: selected ? 0xffaa00 : 0x5588ff, depthTest: false });
  const m = new THREE.Mesh(geo, mat);
  m.renderOrder = 999;
  return m;
}

function _rebuildBoneMarkers(obj) {
  if (!E._boneMarkerGroup) {
    E._boneMarkerGroup = new THREE.Group();
    E._boneMarkerGroup.name = '__boneMarkers__';
    E.scene.add(E._boneMarkerGroup);
  }
  const ownerId = obj.userData.editorId;
  const toRemove = [];
  E._boneMarkerGroup.children.forEach(m => {
    if (m.userData.ownerEditorId == ownerId) toRemove.push(m);
  });
  toRemove.forEach(m => { E._boneMarkerGroup.remove(m); E._boneMarkers.delete(m.userData.boneId); });
  const bones = obj.userData.bones || [];
  bones.forEach(bone => {
    const marker = _makeBoneMarkerMesh(bone.id === E._modelEditorBone);
    marker.userData.boneId = bone.id;
    marker.userData.ownerEditorId = ownerId;
    marker.userData.isEditorHelper = true;
    E._boneMarkerGroup.add(marker);
    E._boneMarkers.set(bone.id, marker);
  });
  _syncBoneMarkersToWorld();
}

function _syncBoneMarkersToWorld() {
  const obj = E._modelEditorObj;
  if (!obj) return;
  obj.updateMatrixWorld(true);
  const bones = obj.userData.bones || [];
  bones.forEach(bone => {
    const marker = E._boneMarkers.get(bone.id);
    if (!marker) return;
    const lp = new THREE.Vector3(...(bone.localPos || [0, 0, 0]));
    obj.localToWorld(lp);
    marker.position.copy(lp);
  });
}

function _onBoneMarkerMoved() {
  const obj    = E._modelEditorObj;
  const boneId = E._modelEditorBone;
  if (!obj || !boneId) return;
  const marker = E._boneMarkers.get(boneId);
  if (!marker) return;
  obj.updateMatrixWorld(true);
  const local = obj.worldToLocal(marker.position.clone());
  const bone  = (obj.userData.bones || []).find(b => b.id === boneId);
  if (bone) bone.localPos = [local.x, local.y, local.z];
  markDirty();
}

function openModelEditor(obj) {
  if (!obj || !obj.userData.primType) { setStatus('Select a primitive object first'); return; }
  E._modelEditorObj  = obj;
  E._modelEditorBone = null;
  if (!obj.userData.bones)    obj.userData.bones    = [];
  if (!obj.userData.boneMode) obj.userData.boneMode = 'rigid';
  _rebuildBoneMarkers(obj);
  renderModelEditorOverlay();
  document.getElementById('model-editor-overlay').classList.add('me-open');
}

function closeModelEditor() {
  E._modelEditorObj  = null;
  E._modelEditorBone = null;
  if (E.selected) E.transform.attach(E.selected); else E.transform.detach();
  if (E._boneMarkerGroup) {
    E._boneMarkerGroup.clear();
    E._boneMarkers.clear();
  }
  const ov = document.getElementById('model-editor-overlay');
  if (ov) ov.classList.remove('me-open');
}

function _updateSpawnCoords() {
  const el = document.getElementById('spawn-coords');
  if (!el) return;
  const obj = E.placedGroup?.children.find(o => o.userData.primType === 'player-spawn');
  if (!obj) { el.textContent = 'Not set'; return; }
  const p = obj.position;
  el.textContent = `X ${p.x.toFixed(2)}  Y ${p.y.toFixed(2)}  Z ${p.z.toFixed(2)}`;
}

function _updateFogInput() {
  const el = document.getElementById('fog-density');
  if (!el) return;
  el.value = E.fogDensity != null ? E.fogDensity : '';
}

function selectBone(boneId) {
  const obj = E._modelEditorObj;
  if (!obj) return;
  E._modelEditorBone = boneId;
  E._boneMarkers.forEach((m, id) => { m.material.color.setHex(id === boneId ? 0xffaa00 : 0x5588ff); });
  const marker = E._boneMarkers.get(boneId);
  if (marker) {
    E.transform.setMode('translate');
    E.transform.attach(marker);
  }
  renderModelEditorOverlay();
}

function renderModelEditorOverlay() {
  const ov = document.getElementById('model-editor-overlay');
  if (!ov) return;
  const obj = E._modelEditorObj;
  if (!obj) { ov.innerHTML = ''; return; }
  const bones    = obj.userData.bones  || [];
  const boneMode = obj.userData.boneMode || 'rigid';
  const selBone  = bones.find(b => b.id === E._modelEditorBone);
  const subMeshes = [];
  if (obj.isGroup) obj.traverse(c => { if (c.isMesh) subMeshes.push(c); });
  else if (obj.isMesh) subMeshes.push(obj);

  ov.innerHTML = `
    <div id="me-header">
      <span style="flex:1;font-size:11px;color:#9999cc;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escHtml(obj.userData.label || '')}">${escHtml(obj.userData.label || 'Object')}</span>
      <button class="btn" id="me-close-btn" style="font-size:10px;padding:2px 6px">&times; Close</button>
    </div>
    <div id="me-body">
      <div style="margin-bottom:8px">
        <div class="vec3-label" style="margin-bottom:3px">Skinning Mode</div>
        <select class="prop-input" id="me-bone-mode" style="width:100%">
          <option value="none"    ${boneMode === 'none'    ? 'selected' : ''}>None (no bones)</option>
          <option value="rigid"   ${boneMode === 'rigid'   ? 'selected' : ''}>Rigid (assign meshes to bones)</option>
          <option value="skinned" ${boneMode === 'skinned' ? 'selected' : ''}>Skinned (auto vertex weights)</option>
        </select>
      </div>
      <div style="display:flex;align-items:center;gap:4px;margin-bottom:4px">
        <div class="vec3-label" style="flex:1">Bones</div>
        <button class="btn" id="me-add-bone" style="font-size:10px;padding:2px 6px">+ Add</button>
      </div>
      <div id="me-bone-list">
        ${bones.map(bone => `
          <div class="me-bone-item${bone.id === E._modelEditorBone ? ' me-bone-selected' : ''}" data-boneid="${escHtml(bone.id)}">
            <span class="me-bone-dot" style="background:${bone.id === E._modelEditorBone ? '#ffaa00' : '#5588ff'}"></span>
            <span class="me-bone-name">${escHtml(bone.name || bone.id)}</span>
            ${bone.tag ? `<span class="me-bone-tag">${escHtml(bone.tag)}</span>` : ''}
            <button class="btn btn-del me-del-bone" data-boneid="${escHtml(bone.id)}" style="font-size:9px;padding:1px 4px">&times;</button>
          </div>
        `).join('')}
        ${bones.length === 0 ? '<div style="font-size:10px;color:#555577;padding:2px">No bones yet</div>' : ''}
      </div>
      ${selBone ? `
        <div style="border-top:1px solid #252545;padding-top:8px;margin-top:8px">
          <div class="vec3-label" style="margin-bottom:6px">Bone Properties</div>
          <div class="state-item-row"><label>Name</label><input class="prop-input" id="me-b-name" value="${escHtml(selBone.name || '')}" style="flex:1"></div>
          <div class="state-item-row"><label>Tag</label><input class="prop-input" id="me-b-tag" value="${escHtml(selBone.tag || '')}" style="flex:1"></div>
          <div class="state-item-row">
            <label>Parent</label>
            <select class="prop-input" id="me-b-parent" style="flex:1">
              <option value="">(root)</option>
              ${bones.filter(b => b.id !== selBone.id).map(b => `<option value="${escHtml(b.id)}" ${selBone.parentId === b.id ? 'selected' : ''}>${escHtml(b.name || b.id)}</option>`).join('')}
            </select>
          </div>
          <div class="state-item-row">
            <label style="cursor:pointer"><input type="checkbox" id="me-b-visible" ${selBone.visible !== false ? 'checked' : ''}> Visible</label>
          </div>
          ${boneMode === 'rigid' ? `
          <div class="state-item-row">
            <label>Mesh</label>
            <select class="prop-input" id="me-b-mesh" style="flex:1">
              <option value="">(none)</option>
              ${subMeshes.map((m, i) => `<option value="${escHtml(m.uuid)}" ${selBone.rigidMeshId === m.uuid ? 'selected' : ''}>${escHtml(m.name || ('mesh_' + i))}</option>`).join('')}
            </select>
          </div>` : ''}
          <div class="vec3-label" style="margin:6px 0 3px">Rotation Limits (deg)</div>
          ${['x', 'y', 'z'].map(ax => `
          <div class="state-item-row">
            <label style="width:18px;flex-shrink:0">${ax}</label>
            <input class="prop-input" id="me-b-rl-${ax}-min" type="number" step="1" value="${selBone.rotLimits?.[ax]?.[0] ?? -180}" style="width:44px" title="min deg">
            <span style="color:#556677;font-size:9px"> to </span>
            <input class="prop-input" id="me-b-rl-${ax}-max" type="number" step="1" value="${selBone.rotLimits?.[ax]?.[1] ?? 180}" style="width:44px" title="max deg">
          </div>`).join('')}
          <div class="vec3-label" style="margin:6px 0 3px">Spring</div>
          <div class="state-item-row"><label>Elasticity</label><input class="prop-input" id="me-b-el" type="number" step="0.01" min="0" max="1" value="${selBone.elasticity ?? 0}" style="flex:1"></div>
          <div class="state-item-row"><label>Stiffness</label><input class="prop-input" id="me-b-st" type="number" step="0.01" min="0" max="1" value="${selBone.stiffness ?? 1}" style="flex:1"></div>
          <div class="state-item-row"><label>Damping</label><input class="prop-input" id="me-b-da" type="number" step="0.01" min="0" max="1" value="${selBone.damping ?? 0.5}" style="flex:1"></div>
        </div>
      ` : ''}
    </div>
  `;

  document.getElementById('me-close-btn').addEventListener('click', closeModelEditor);
  document.getElementById('me-add-bone').addEventListener('click', () => addBone(obj));
  document.getElementById('me-bone-mode').addEventListener('change', e => {
    pushUndo();
    obj.userData.boneMode = e.target.value;
    markDirty();
    renderModelEditorOverlay();
  });
  document.querySelectorAll('.me-bone-item').forEach(el => {
    el.addEventListener('click', e => {
      if (e.target.classList.contains('me-del-bone')) return;
      selectBone(el.dataset.boneid);
    });
  });
  document.querySelectorAll('.me-del-bone').forEach(el => {
    el.addEventListener('click', e => { e.stopPropagation(); deleteBone(obj, el.dataset.boneid); });
  });
  if (selBone) _wireBonePropsEvents(obj, selBone);
}

function _wireBonePropsEvents(obj, selBone) {
  const bind = (id, fn) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('focus', () => pushUndo());
    el.addEventListener('input', fn);
  };
  bind('me-b-name', e => { selBone.name = e.target.value; markDirty(); renderModelEditorOverlay(); });
  bind('me-b-tag',  e => { selBone.tag  = e.target.value; markDirty(); });
  const parentEl = document.getElementById('me-b-parent');
  if (parentEl) parentEl.addEventListener('change', e => { pushUndo(); selBone.parentId = e.target.value || null; markDirty(); });
  const visEl = document.getElementById('me-b-visible');
  if (visEl) visEl.addEventListener('change', e => { pushUndo(); selBone.visible = e.target.checked; markDirty(); });
  const meshEl = document.getElementById('me-b-mesh');
  if (meshEl) meshEl.addEventListener('change', e => { pushUndo(); selBone.rigidMeshId = e.target.value || null; markDirty(); });
  for (const ax of ['x', 'y', 'z']) {
    bind(`me-b-rl-${ax}-min`, e => {
      if (!selBone.rotLimits) selBone.rotLimits = {};
      if (!selBone.rotLimits[ax]) selBone.rotLimits[ax] = [-180, 180];
      selBone.rotLimits[ax][0] = parseFloat(e.target.value) || -180;
      markDirty();
    });
    bind(`me-b-rl-${ax}-max`, e => {
      if (!selBone.rotLimits) selBone.rotLimits = {};
      if (!selBone.rotLimits[ax]) selBone.rotLimits[ax] = [-180, 180];
      selBone.rotLimits[ax][1] = parseFloat(e.target.value) || 180;
      markDirty();
    });
  }
  bind('me-b-el', e => { selBone.elasticity = parseFloat(e.target.value) ?? 0;   markDirty(); });
  bind('me-b-st', e => { selBone.stiffness  = parseFloat(e.target.value) ?? 1;   markDirty(); });
  bind('me-b-da', e => { selBone.damping    = parseFloat(e.target.value) ?? 0.5; markDirty(); });
}

function addBone(obj) {
  pushUndo();
  if (!obj.userData.bones) obj.userData.bones = [];
  const id   = _genBoneId(obj);
  const bone = {
    id, name: 'Bone', tag: '', parentId: null, localPos: [0, 1, 0],
    visible: true, rigidMeshId: null,
    rotLimits: { x: [-180, 180], y: [-180, 180], z: [-180, 180] },
    elasticity: 0, stiffness: 1, damping: 0.5,
  };
  obj.userData.bones.push(bone);
  _rebuildBoneMarkers(obj);
  selectBone(id);
  markDirty();
}

function deleteBone(obj, boneId) {
  pushUndo();
  obj.userData.bones = (obj.userData.bones || []).filter(b => b.id !== boneId);
  obj.userData.bones.forEach(b => { if (b.parentId === boneId) b.parentId = null; });
  (obj.userData.states || []).forEach(st => {
    if (st.boneOverrides) st.boneOverrides = st.boneOverrides.filter(o => o.boneId !== boneId);
  });
  E._boneMarkers.delete(boneId);
  if (E._modelEditorBone === boneId) {
    E._modelEditorBone = null;
    if (E._modelEditorObj) E.transform.attach(E._modelEditorObj); else E.transform.detach();
  }
  _rebuildBoneMarkers(obj);
  renderModelEditorOverlay();
  markDirty();
}

function _appendBoneOverridesToStateItem(item, obj, idx) {
  const bones = obj.userData.bones || [];
  if (!bones.length) return;
  const state = obj.userData.states[idx];
  if (!state) return;
  if (!state.boneOverrides) state.boneOverrides = [];
  const stateBody = item.querySelector('.state-body') || item;

  const sec = document.createElement('div');
  sec.style.cssText = 'margin-top:6px;border-top:1px solid #252545;padding-top:5px';

  const hdr = document.createElement('div');
  hdr.style.cssText = 'display:flex;align-items:center;gap:4px;cursor:pointer;margin-bottom:3px';
  hdr.innerHTML = `<span style="font-size:10px;color:#6688aa;flex:1">Bone Overrides</span><button class="state-collapse-btn" style="font-size:9px;padding:0 3px">&#9654;</button>`;
  const boneBody  = document.createElement('div');
  boneBody.classList.add('state-body-hidden');
  const toggleBtn = hdr.querySelector('button');
  hdr.addEventListener('click', () => {
    const hidden = boneBody.classList.toggle('state-body-hidden');
    toggleBtn.innerHTML = hidden ? '&#9654;' : '&#9660;';
  });

  bones.forEach(bone => {
    let ov = state.boneOverrides.find(b => b.boneId === bone.id);
    if (!ov) { ov = { boneId: bone.id }; state.boneOverrides.push(ov); }

    const boneRow  = document.createElement('div');
    boneRow.style.cssText = 'margin-bottom:5px';
    const boneHdr  = document.createElement('div');
    boneHdr.style.cssText = 'display:flex;align-items:center;gap:4px;cursor:pointer;margin-bottom:2px';
    boneHdr.innerHTML = `<span class="me-bone-dot" style="width:6px;height:6px;border-radius:50%;background:#5588ff;flex-shrink:0"></span><span style="font-size:10px;color:#8899bb;flex:1">${escHtml(bone.name || bone.id)}</span><button class="state-collapse-btn" style="font-size:8px;padding:0 3px">&#9654;</button>`;
    const boneDetail = document.createElement('div');
    boneDetail.classList.add('state-body-hidden');
    const boneToggle = boneHdr.querySelector('button');
    boneHdr.addEventListener('click', () => {
      const hidden = boneDetail.classList.toggle('state-body-hidden');
      boneToggle.innerHTML = hidden ? '&#9654;' : '&#9660;';
    });

    const mkXyz = (label, key, enableKey, def) => {
      const en = ov[enableKey] !== false ? '' : ' sf-disabled';
      const v  = ov[key] || def;
      const row = document.createElement('div');
      row.className = `state-field-row${en}`;
      row.dataset.field = key;
      row.innerHTML = `
        <div class="state-field-head">
          <label><input type="checkbox" ${ov[enableKey] !== false ? 'checked' : ''} data-enkey="${enableKey}"> ${label}</label>
        </div>
        <div class="state-field-xyz">
          <span class="xyz-lbl">x</span><input class="prop-input" data-key="${key}" data-axis="0" type="number" step="0.01" value="${v[0]}">
          <span class="xyz-lbl">y</span><input class="prop-input" data-key="${key}" data-axis="1" type="number" step="0.01" value="${v[1]}">
          <span class="xyz-lbl">z</span><input class="prop-input" data-key="${key}" data-axis="2" type="number" step="0.01" value="${v[2]}">
        </div>`;
      row.querySelector('[data-enkey]').addEventListener('change', ev => {
        pushUndo();
        ov[enableKey] = ev.target.checked;
        row.classList.toggle('sf-disabled', !ev.target.checked);
        markDirty();
      });
      row.querySelectorAll('[data-key]').forEach(inp => {
        inp.addEventListener('focus', () => pushUndo());
        inp.addEventListener('input', ev => {
          if (!ov[key]) ov[key] = [...def];
          ov[key][parseInt(inp.dataset.axis)] = parseFloat(ev.target.value) || 0;
          markDirty();
        });
      });
      return row;
    };

    boneDetail.appendChild(mkXyz('Pos',   'pos',   'posEnabled',   [0, 0, 0]));
    boneDetail.appendChild(mkXyz('Rot',   'rot',   'rotEnabled',   [0, 0, 0]));
    boneDetail.appendChild(mkXyz('Scale', 'scale', 'scaleEnabled', [1, 1, 1]));
    boneRow.appendChild(boneHdr);
    boneRow.appendChild(boneDetail);
    boneBody.appendChild(boneRow);
  });

  sec.appendChild(hdr);
  sec.appendChild(boneBody);
  stateBody.appendChild(sec);
}

// ───────────────────────────────────────────────────────────────────

function exportGroupGLB() {
  if (!E.selected) { setStatus('Select an object in a group first'); return; }
  const gid = findGroupOfObj(E.selected);
  if (!gid || !E.groups[gid]) { setStatus('Selected object is not in a group'); return; }
  const g = E.groups[gid];
  const findById = id => {
    const match = o => o.userData.editorId == id;
    let found = E.placedGroup.children.find(match);
    if (!found && E.groupPivot) found = E.groupPivot.children.find(match);
    return found;
  };
  const members = [...g.ids].map(findById).filter(Boolean);
  if (!members.length) { setStatus('Group has no members'); return; }

  const includeBones = document.getElementById('chk-export-bones')?.checked;
  const exportGroup = new THREE.Group();
  exportGroup.name = g.name;

  members.forEach(obj => {
    const bonesData = obj.userData.bones || [];
    const boneMode  = obj.userData.boneMode || 'none';

    if (!includeBones || !bonesData.length || boneMode === 'none') {
      const clone = obj.clone();
      clone.name = obj.userData.label || obj.userData.editorId || obj.name;
      exportGroup.add(clone);
      return;
    }

    const skinRoot = new THREE.Group();
    skinRoot.name  = obj.userData.label || String(obj.userData.editorId) || obj.name;

    const boneObjMap = new Map();
    bonesData.forEach(bd => {
      const b = new THREE.Bone();
      b.name = bd.name || bd.id;
      boneObjMap.set(bd.id, b);
    });

    const rootBones = [];
    bonesData.forEach(bd => {
      const b = boneObjMap.get(bd.id);
      if (bd.parentId && boneObjMap.has(bd.parentId)) {
        const parentBone = boneObjMap.get(bd.parentId);
        const parentBD   = bonesData.find(x => x.id === bd.parentId);
        const pPos = new THREE.Vector3(...(parentBD.localPos || [0, 0, 0]));
        const cPos = new THREE.Vector3(...(bd.localPos  || [0, 0, 0]));
        b.position.copy(cPos.sub(pPos));
        parentBone.add(b);
      } else {
        b.position.set(...(bd.localPos || [0, 0, 0]));
        rootBones.push(b);
      }
    });
    rootBones.forEach(rb => skinRoot.add(rb));

    const allBones = [...boneObjMap.values()];
    exportGroup.add(skinRoot);
    exportGroup.updateMatrixWorld(true);
    const skeleton = new THREE.Skeleton(allBones);

    const meshes = [];
    if (obj.isMesh) meshes.push(obj);
    else obj.traverse(c => { if (c.isMesh && !c.userData.isEditorHelper) meshes.push(c); });

    meshes.forEach(mesh => {
      const assignedBD  = boneMode === 'rigid'
        ? bonesData.find(bd => bd.rigidMeshId === mesh.uuid) : null;
      const boneIdx = assignedBD ? allBones.indexOf(boneObjMap.get(assignedBD.id)) : 0;
      const safeIdx = Math.max(0, boneIdx);

      const geo   = mesh.geometry.clone();
      const count = geo.attributes.position.count;
      const si    = new Uint16Array(count * 4);
      const sw    = new Float32Array(count * 4);
      for (let i = 0; i < count; i++) { si[i*4] = safeIdx; sw[i*4] = 1; }
      geo.setAttribute('skinIndex',  new THREE.BufferAttribute(si, 4));
      geo.setAttribute('skinWeight', new THREE.BufferAttribute(sw, 4));

      const sm  = new THREE.SkinnedMesh(geo, Array.isArray(mesh.material) ? mesh.material.map(m => m.clone()) : mesh.material.clone());
      sm.name   = mesh.name || mesh.uuid;
      sm.position.copy(mesh.getWorldPosition(new THREE.Vector3()));
      sm.quaternion.copy(mesh.getWorldQuaternion(new THREE.Quaternion()));
      sm.scale.copy(mesh.getWorldScale(new THREE.Vector3()));
      sm.bind(skeleton);
      skinRoot.add(sm);
    });
  });

  const defaultName = (g.name.replace(/[^a-z0-9_-]/gi, '_') || 'group') + '.glb';
  const exporter = new GLTFExporter();
  exporter.parse(exportGroup, async result => {
    if (!window.electron?.saveGlb) { setStatus('GLB export not available outside Electron'); return; }
    const res = await window.electron.saveGlb(defaultName, result);
    if (res?.ok) setStatus(`Exported group "${g.name}" as GLB`);
  }, err => { setStatus('GLB export failed: ' + err); }, { binary: true });
}

function exportRawMap(mapKey) {
  const obj = E.selected;
  if (!obj) { setStatus('No object selected'); return; }
  const label = (obj.userData.label || ('obj_' + obj.userData.editorId)).replace(/[^a-z0-9_\-]/gi, '_');

  const scalarFallbackKeys = { roughnessMap: 'roughness', metalnessMap: 'metalness' };

  let tex = null;
  let scalarValue = null;
  obj.traverse(c => {
    if (!c.isMesh) return;
    const mats = Array.isArray(c.material) ? c.material : (c.material ? [c.material] : []);
    for (const m of mats) {
      if (m?.[mapKey]?.image) { tex = m[mapKey]; break; }
      if (!tex && scalarFallbackKeys[mapKey] !== undefined && m) {
        const v = m[scalarFallbackKeys[mapKey]];
        if (typeof v === 'number' && scalarValue === null) scalarValue = v;
        else if (mapKey === 'roughnessMap' && m.shininess !== undefined && scalarValue === null) {
          scalarValue = 1.0 - Math.min(m.shininess, 100) / 100;
        }
      }
    }
  });

  const canvas = document.createElement('canvas');
  canvas.width = 64; canvas.height = 64;
  const ctx = canvas.getContext('2d');

  if (tex?.image) {
    const img = tex.image;
    canvas.width  = img.naturalWidth  || img.width  || 1024;
    canvas.height = img.naturalHeight || img.height || 1024;
    if (tex.flipY !== false) { ctx.translate(0, canvas.height); ctx.scale(1, -1); }
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  } else if (scalarValue !== null) {
    const grey = Math.round(scalarValue * 255);
    ctx.fillStyle = `rgb(${grey},${grey},${grey})`;
    ctx.fillRect(0, 0, 64, 64);
  } else {
    setStatus(`No ${mapKey} found on selected object`);
    return;
  }

  canvas.toBlob(blob => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = `${label}_${mapKey}.png`; a.click();
    URL.revokeObjectURL(url);
  }, 'image/png');
  setStatus(`Exported ${mapKey} for "${obj.userData.label || obj.userData.editorId}"`);
}

function exportUVMap(clean = false) {
  const obj = E.selected;
  if (!obj) { setStatus('No object selected'); return; }

  const canvas = document.createElement('canvas');
  const ctx    = canvas.getContext('2d');
  const label  = (obj.userData.label || ('obj_' + obj.userData.editorId)).replace(/[^a-z0-9_\-]/gi, '_');

  // ── Face mode: export planar projection (correct orientation + physical aspect ratio) ──
  if (E.faceModeActive && E.faceModeSelected >= 0) {
    let targetMesh = null;
    if (obj.isMesh) targetMesh = obj;
    else obj.traverse(c => { if (c.isMesh && !c.userData.isEditorHelper && !targetMesh) targetMesh = c; });
    if (!targetMesh) { setStatus('No mesh geometry found on selected object'); return; }

    const faceGroup = E.faceModeGroups[E.faceModeSelected];
    const { triUVs, W, H } = _computeFacePlanarProj(targetMesh, faceGroup);

    canvas.width = W; canvas.height = H;

    const bgColor = obj.userData._baseColor ?? '#1a1a1a';
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, W, H);

    const edgeCounts = new Map();
    const ekFmt = (x1, y1, x2, y2) => {
      const a = `${x1.toFixed(2)},${y1.toFixed(2)}`, b = `${x2.toFixed(2)},${y2.toFixed(2)}`;
      return a < b ? `${a}|${b}` : `${b}|${a}`;
    };
    for (const [[x1,y1],[x2,y2],[x3,y3]] of triUVs) {
      for (const [xa,ya,xb,yb] of [[x1,y1,x2,y2],[x2,y2,x3,y3],[x3,y3,x1,y1]]) {
        const k = ekFmt(xa, ya, xb, yb);
        edgeCounts.set(k, (edgeCounts.get(k) || 0) + 1);
      }
    }

    ctx.fillStyle = 'rgba(255,255,255,0.07)';
    for (const [[x1,y1],[x2,y2],[x3,y3]] of triUVs) {
      ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.lineTo(x3,y3);
      ctx.closePath(); ctx.fill();
    }

    if (!clean) {
      ctx.strokeStyle = 'rgba(0,255,100,0.95)'; ctx.lineWidth = 1.5; ctx.beginPath();
      for (const [[x1,y1],[x2,y2],[x3,y3]] of triUVs) {
        for (const [xa,ya,xb,yb] of [[x1,y1,x2,y2],[x2,y2,x3,y3],[x3,y3,x1,y1]]) {
          if (edgeCounts.get(ekFmt(xa,ya,xb,yb)) === 1) { ctx.moveTo(xa,ya); ctx.lineTo(xb,yb); }
        }
      }
      ctx.stroke();
    }

    canvas.toBlob(blob => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url;
      a.download = label + `_face${E.faceModeSelected + 1}_template.png`; a.click();
      URL.revokeObjectURL(url);
    }, 'image/png');
    setStatus(`Face template exported (${W}×${H}) — paint on this and import as the face texture`);
    return;
  }

  // ── Standard mode: full UV map ──
  const SIZE = 2048;
  canvas.width = canvas.height = SIZE;

  const meshes = [];
  if (obj.isMesh) meshes.push(obj);
  else obj.traverse(c => { if (c.isMesh) meshes.push(c); });
  if (meshes.length === 0) { setStatus('No mesh geometry found on selected object'); return; }

  let bgDrawn = false;
  for (const mesh of meshes) {
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    for (const mat of mats) {
      if (mat?.map?.image) {
        try {
          ctx.save();
          if (mat.map.flipY !== false) { ctx.translate(0, SIZE); ctx.scale(1, -1); }
          ctx.drawImage(mat.map.image, 0, 0, SIZE, SIZE);
          ctx.restore();
          bgDrawn = true;
        } catch (_) {}
        if (bgDrawn) break;
      }
    }
    if (bgDrawn) break;
  }
  if (!bgDrawn) {
    let bgColor = '#1a1a1a';
    if (obj.userData._baseColor) bgColor = obj.userData._baseColor;
    else if (!Array.isArray(obj.material) && obj.material?.color) bgColor = '#' + obj.material.color.getHexString();
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, SIZE, SIZE);
  }

  const edgeCounts = new Map();
  const allTriUVs  = [];
  const uvKey  = (u, v) => `${u.toFixed(5)},${v.toFixed(5)}`;
  const edgeKey = (u1, v1, u2, v2) => {
    const a = uvKey(u1, v1), b = uvKey(u2, v2);
    return a < b ? `${a}|${b}` : `${b}|${a}`;
  };

  for (const mesh of meshes) {
    const geo = mesh.geometry;
    if (!geo?.attributes?.uv) continue;
    const uvAttr = geo.attributes.uv;
    const processTri = (ai, bi, ci) => {
      const tri = [
        [uvAttr.getX(ai), uvAttr.getY(ai)],
        [uvAttr.getX(bi), uvAttr.getY(bi)],
        [uvAttr.getX(ci), uvAttr.getY(ci)],
      ];
      allTriUVs.push(tri);
      for (let e = 0; e < 3; e++) {
        const [u1, v1] = tri[e], [u2, v2] = tri[(e + 1) % 3];
        const k = edgeKey(u1, v1, u2, v2);
        edgeCounts.set(k, (edgeCounts.get(k) || 0) + 1);
      }
    };
    if (geo.index) {
      const idx = geo.index.array;
      for (let i = 0; i < idx.length; i += 3) processTri(idx[i], idx[i + 1], idx[i + 2]);
    } else {
      for (let i = 0; i < uvAttr.count; i += 3) processTri(i, i + 1, i + 2);
    }
  }

  ctx.fillStyle = 'rgba(255,255,255,0.06)';
  for (const [[u1, v1], [u2, v2], [u3, v3]] of allTriUVs) {
    ctx.beginPath();
    ctx.moveTo(u1 * SIZE, (1 - v1) * SIZE);
    ctx.lineTo(u2 * SIZE, (1 - v2) * SIZE);
    ctx.lineTo(u3 * SIZE, (1 - v3) * SIZE);
    ctx.closePath(); ctx.fill();
  }

  if (!clean) {
    ctx.strokeStyle = 'rgba(0,255,100,0.95)'; ctx.lineWidth = 1.5; ctx.beginPath();
    for (const [[u1, v1], [u2, v2], [u3, v3]] of allTriUVs) {
      const edges = [[u1, v1, u2, v2], [u2, v2, u3, v3], [u3, v3, u1, v1]];
      for (const [eu1, ev1, eu2, ev2] of edges) {
        if (edgeCounts.get(edgeKey(eu1, ev1, eu2, ev2)) === 1) {
          ctx.moveTo(eu1 * SIZE, (1 - ev1) * SIZE);
          ctx.lineTo(eu2 * SIZE, (1 - ev2) * SIZE);
        }
      }
    }
    ctx.stroke();
  }

  canvas.toBlob(blob => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = label + '_uvmap.png';
    a.click();
    URL.revokeObjectURL(url);
  }, 'image/png');
  setStatus(`UV map exported for "${obj.userData.label || obj.userData.editorId}"`);
}

function openMergeDialog() {
  const gid = E.selected ? findGroupOfObj(E.selected) : null;
  const groupIds = gid ? E.groups[gid].ids : null;

  const candidates = [];
  const _mergePool = [...E.placedGroup.children];
  if (E.groupPivot) E.groupPivot.children.forEach(c => _mergePool.push(c));
  _mergePool.forEach(obj => {
    if (obj.userData.isEditorHelper) return;
    const t = obj.userData.primType;
    if (isLightType(t) || isTriggerType(t)) return;
    if (groupIds && !groupIds.has(obj.userData.editorId)) return;
    candidates.push(obj);
  });
  if (!candidates.length) { setStatus('No mergeable objects in scene'); return; }

  const preSelected = new Set();
  if (gid) {
    candidates.forEach(obj => preSelected.add(obj.userData.editorId));
  } else if (E.selected) {
    preSelected.add(E.selected.userData.editorId);
  } else {
    candidates.forEach(obj => preSelected.add(obj.userData.editorId));
  }

  const list = document.getElementById('merge-object-list');
  list.innerHTML = '';
  candidates.forEach(obj => {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:6px;align-items:center;padding:3px 4px;background:#0d0d20;border-radius:3px';
    const chk = document.createElement('input');
    chk.type = 'checkbox';
    chk.checked = preSelected.has(obj.userData.editorId);
    chk.style.cssText = 'width:20px;flex-shrink:0;cursor:pointer';
    chk.dataset.eid = obj.userData.editorId;
    const lbl = document.createElement('span');
    lbl.textContent = obj.name || (obj.userData.primType + '_' + obj.userData.editorId);
    lbl.style.cssText = 'font-size:11px;color:#aaaacc;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
    const numInput = document.createElement('input');
    numInput.type = 'number';
    numInput.min = '1';
    numInput.value = '1';
    numInput.className = 'prop-input';
    numInput.style.cssText = 'width:52px;font-size:11px;text-align:center';
    numInput.dataset.eid = obj.userData.editorId;
    row.appendChild(chk);
    row.appendChild(lbl);
    row.appendChild(numInput);
    list.appendChild(row);
  });

  const nameInput = document.getElementById('merge-result-name');
  nameInput.value = gid ? (E.groups[gid]?.name || 'merged') : (E.selected?.userData.label || 'merged');
  document.getElementById('merge-modal').style.display = 'flex';
}

function closeMergeDialog() {
  document.getElementById('merge-modal').style.display = 'none';
}

function executeMerge() {
  const list = document.getElementById('merge-object-list');
  const resultName = document.getElementById('merge-result-name').value.trim() || 'merged';

  const plan = [];
  list.querySelectorAll('div').forEach(row => {
    const chk = row.querySelector('input[type=checkbox]');
    const num = row.querySelector('input[type=number]');
    if (!chk || !num || !chk.checked) return;
    const eid = parseInt(chk.dataset.eid);
    const _pool = [...E.placedGroup.children, ...(E.groupPivot ? E.groupPivot.children : [])];
    const obj = _pool.find(o => o.userData.editorId === eid);
    if (!obj) return;
    plan.push({ obj, meshGroup: parseInt(num.value) || 1 });
  });

  if (!plan.length) { setStatus('Select at least one object to merge'); return; }

  pushUndo();
  if (E.groupPivot) finalizeGroupTransform();
  closeMergeDialog();

  const groups = {};
  plan.forEach(({ obj, meshGroup }) => {
    if (!groups[meshGroup]) groups[meshGroup] = [];
    groups[meshGroup].push(obj);
  });

  const centroid = new THREE.Vector3();
  plan.forEach(({ obj }) => { const wp = new THREE.Vector3(); obj.getWorldPosition(wp); centroid.add(wp); });
  centroid.divideScalar(plan.length);

  const root = new THREE.Group();
  const meshOverrides = {};
  const sortedNums = Object.keys(groups).map(Number).sort((a, b) => a - b);

  sortedNums.forEach(gNum => {
    const srcObjs = groups[gNum];
    const allMeshes = [];
    srcObjs.forEach(o => {
      if (o.isMesh) allMeshes.push(o);
      else o.traverse(c => { if (c.isMesh) allMeshes.push(c); });
    });
    if (!allMeshes.length) return;
    const geo = mergeGeometriesWorldSpace(allMeshes);
    if (!geo) return;
    geo.translate(-centroid.x, -centroid.y, -centroid.z);
    const srcMat = allMeshes[0].material;
    const mat = (srcMat && !Array.isArray(srcMat))
      ? srcMat.clone()
      : new THREE.MeshStandardMaterial({ color: '#aaaacc', roughness: 1, metalness: 0 });
    mat.side = THREE.DoubleSide;
    const meshName = 'mesh_' + gNum;
    const childMesh = new THREE.Mesh(geo, mat);
    childMesh.name = meshName;
    childMesh.castShadow = true;
    childMesh.receiveShadow = true;
    root.add(childMesh);
    meshOverrides[meshName] = {};
  });

  if (!root.children.length) { setStatus('Merge failed: no geometry found'); return; }

  const id = E.nextId++;
  root.position.copy(centroid);
  root.castShadow = true;
  root.receiveShadow = true;
  root.userData = {
    primType:      'merged-model',
    editorId:      id,
    label:         resultName,
    collidable:    true,
    meshOverrides: meshOverrides,
  };
  root.name = resultName;

  plan.forEach(({ obj }) => {
    const srcId = obj.userData.editorId;
    for (const g of Object.values(E.groups)) g.ids.delete(srcId);
    E.placedGroup.remove(obj);
  });
  for (const gid of Object.keys(E.groups)) { if (E.groups[gid].ids.size === 0) delete E.groups[gid]; }

  E.placedGroup.add(root);
  selectObj(root);
  updateSceneList();
  updateGroupsPanel();
  markDirty();
  setStatus(`Merged ${plan.length} objects into "${resultName}"`);
}

function _serializeMergedMeshes(obj) {
  const meshes = [];
  obj.children.forEach(child => {
    if (!child.isMesh) return;
    const geo = child.geometry;
    const pos = geo.attributes.position?.array;
    const nor = geo.attributes.normal?.array;
    const uv  = geo.attributes.uv?.array;
    const idx = geo.index?.array;
    meshes.push({
      name:      child.name,
      positions: pos ? Array.from(pos) : [],
      normals:   nor ? Array.from(nor) : null,
      uvs:       uv  ? Array.from(uv)  : null,
      indices:   idx ? Array.from(idx) : null,
    });
  });
  return meshes;
}

function spawnMergedModel(entry) {
  const root = new THREE.Group();
  (entry.mergedMeshes || []).forEach(md => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(md.positions, 3));
    if (md.normals) geo.setAttribute('normal', new THREE.Float32BufferAttribute(md.normals, 3));
    if (md.uvs)     geo.setAttribute('uv',     new THREE.Float32BufferAttribute(md.uvs, 2));
    if (md.indices) geo.setIndex(new THREE.BufferAttribute(new Uint32Array(md.indices), 1));
    const mat = new THREE.MeshStandardMaterial({ color: entry.color ?? '#aaaacc', roughness: 1, metalness: 0, side: THREE.DoubleSide });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = md.name;
    mesh.castShadow = entry.castShadow !== false;
    mesh.receiveShadow = true;
    root.add(mesh);
  });
  applyEntryTransform(root, entry);
  root.castShadow = entry.castShadow !== false;
  root.receiveShadow = true;
  root.userData = {
    primType:   'merged-model',
    editorId:   entry.id,
    label:      entry.label || '',
    collidable: entry.collidable !== false,
    _baseColor: entry.color ?? '#aaaacc',
  };
  root.name = entry.label || ('Merged_' + entry.id);
  if (entry.states?.length)  { root.userData.states = entry.states; root.userData.currentState = 0; }
  if (entry.links?.length)     root.userData.links  = _normalizeLinks(entry.links);
  if (entry.noSelfInteract)    root.userData.noSelfInteract = true;
  if (entry.scripts?.length)   root.userData.scripts = [...entry.scripts];
  if (entry.meshOverrides) {
    root.userData.meshOverrides = entry.meshOverrides;
    root.traverse(c => {
      if (!c.isMesh) return;
      const ovr = entry.meshOverrides[c.name];
      if (!ovr) return;
      if (ovr.visible === false) c.visible = false;
      if (ovr.texture) _applyMeshEditorTexture(c, ovr.texture);
    });
  }
  if (entry.doubleSide) {
    root.userData.doubleSide = true;
    root.traverse(c => {
      if (c.isMesh && c.material) {
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { m.side = THREE.DoubleSide; m.needsUpdate = true; });
      }
    });
  }
  if (entry.invertNormals) {
    root.userData.invertNormals = true;
    root.traverse(c => { if (c.isMesh && c.geometry) _flipGeometryNormals(c.geometry); });
  }
  E.placedGroup.add(root);
  return root;
}

function spawnImageModel(entry) {
  return new Promise(resolve => {
    _buildImageModelMesh(entry.imagePath, (group, aspect) => {
      if (!group) { resolve(); return; }
      const castShadow = entry.castShadow !== false;
      group.traverse(c => { if (c.isMesh) { c.castShadow = castShadow; c.receiveShadow = true; } });
      applyEntryTransform(group, entry);
      group.userData = {
        primType:   'image-model',
        imagePath:  entry.imagePath,
        editorId:   entry.id,
        label:      entry.label || '',
        collidable: entry.collidable !== false,
        wallColor:  entry.wallColor || group.userData._autoWallColor,
        _aspect:    aspect,
      };
      group.name = entry.label || ('Image_' + entry.id);
      if (entry.states?.length) { group.userData.states = entry.states; group.userData.currentState = 0; }
      if (entry.links?.length)  group.userData.links = _normalizeLinks(entry.links);
      if (entry.scripts?.length) group.userData.scripts = [...entry.scripts];
      E.placedGroup.add(group);
      resolve(group);
    }, entry.wallColor);
  });
}

function openMeshEditor() {
  const obj = E.selected;
  if (!obj || (obj.userData.primType !== 'model' && obj.userData.primType !== 'merged-model')) return;
  document.getElementById('mesh-model-name').textContent = obj.name || obj.userData.modelPath || 'Model';

  const masterIn = document.getElementById('mesh-master-tex');
  masterIn.value = obj.userData.masterTexture || '';
  masterIn.onchange = () => {
    pushUndo();
    const texName = masterIn.value.trim() || null;
    obj.userData.masterTexture = texName || undefined;
    _applyMasterTexture(obj, texName);
    markDirty();
  };
  document.getElementById('btn-mesh-master-import').onclick = async () => {
    if (!window.electron?.importTexture) return;
    const name = await window.electron.importTexture();
    if (!name) return;
    await refreshTextureList();
    pushUndo();
    masterIn.value = name;
    obj.userData.masterTexture = name;
    _applyMasterTexture(obj, name);
    markDirty();
  };
  document.getElementById('btn-mesh-master-clear').onclick = () => {
    pushUndo();
    masterIn.value = '';
    delete obj.userData.masterTexture;
    _applyMasterTexture(obj, null);
    markDirty();
  };

  const list = document.getElementById('mesh-list');
  list.innerHTML = '';

  const meshes = [];
  obj.traverse(c => { if (c.isMesh) meshes.push(c); });

  if (!obj.userData.meshOverrides) obj.userData.meshOverrides = {};
  const overrides = obj.userData.meshOverrides;

  meshes.forEach(mesh => {
    const key = mesh.name || mesh.uuid;
    const ovr = overrides[key] || {};

    const row = document.createElement('div');
    row.style.cssText = 'display:grid;grid-template-columns:20px 1fr 130px 22px;gap:4px;align-items:center;padding:3px 6px;background:#0d0d20;border-radius:3px';

    const chk = document.createElement('input');
    chk.type = 'checkbox';
    chk.checked = ovr.visible !== false;
    chk.style.cursor = 'pointer';
    chk.addEventListener('change', () => {
      pushUndo();
      if (!overrides[key]) overrides[key] = {};
      overrides[key].visible = chk.checked;
      if (chk.checked) {
        if (Array.isArray(mesh.material)) {
          mesh.material = mesh.material.map(m => { const n = m.clone(); n.visible = true; return n; });
        } else if (mesh.material) {
          mesh.material = mesh.material.clone();
          mesh.material.visible = true;
        }
      } else {
        if (Array.isArray(mesh.material)) {
          mesh.material = mesh.material.map(m => { const n = m.clone(); n.visible = false; return n; });
        } else if (mesh.material) {
          mesh.material = mesh.material.clone();
          mesh.material.visible = false;
        }
      }
      markDirty();
    });

    const label = document.createElement('span');
    label.textContent = mesh.name || '(unnamed)';
    label.style.cssText = 'font-size:11px;color:#aaaacc;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer';
    label.addEventListener('click', () => {
      if (_highlightedMesh === mesh) { _setMeshHighlight(null, null); }
      else { _setMeshHighlight(mesh, row); }
    });

    const texIn = document.createElement('input');
    texIn.type = 'text';
    texIn.className = 'prop-input';
    texIn.value = ovr.texture || '';
    texIn.placeholder = 'texture name';
    texIn.style.cssText = 'font-size:11px;width:100%';
    texIn.setAttribute('list', 'tex-datalist');
    texIn.addEventListener('change', () => {
      pushUndo();
      const texName = texIn.value.trim() || null;
      if (!overrides[key]) overrides[key] = {};
      overrides[key].texture = texName;
      _applyMeshEditorTexture(mesh, texName);
      markDirty();
    });

    row.appendChild(chk);
    row.appendChild(label);
    row.appendChild(texIn);

    const impBtn = document.createElement('button');
    impBtn.className = 'btn';
    impBtn.textContent = '+';
    impBtn.title = 'Import texture';
    impBtn.style.cssText = 'padding:2px 4px;font-size:11px';
    impBtn.addEventListener('click', async () => {
      if (!window.electron?.importTexture) return;
      const name = await window.electron.importTexture();
      if (!name) return;
      await refreshTextureList();
      pushUndo();
      texIn.value = name;
      if (!overrides[key]) overrides[key] = {};
      overrides[key].texture = name;
      _applyMeshEditorTexture(mesh, name);
      markDirty();
    });
    row.appendChild(impBtn);

    list.appendChild(row);
  });

  document.getElementById('mesh-modal').style.display = 'flex';
}

function closeMeshEditor() {
  _setMeshHighlight(null, null);
  document.getElementById('mesh-modal').style.display = 'none';
}

function openActorMeshEditor() {
  const obj = E.selected;
  if (!obj || obj.userData.primType !== 'actor-spawn') return;

  const actorPath = obj.userData.actorModel;
  document.getElementById('actor-mesh-model-name').textContent = actorPath.split('/').pop() || 'Actor';

  if (!obj.userData.meshOverrides) obj.userData.meshOverrides = {};
  const overrides = obj.userData.meshOverrides;

  const masterIn = document.getElementById('actor-mesh-master-tex');
  masterIn.value = obj.userData.masterTexture || '';
  masterIn.onchange = () => {
    pushUndo();
    const texName = masterIn.value.trim() || null;
    obj.userData.masterTexture = texName || undefined;
    markDirty();
  };
  document.getElementById('btn-actor-mesh-master-import').onclick = async () => {
    if (!window.electron?.importTexture) return;
    const name = await window.electron.importTexture();
    if (!name) return;
    await refreshTextureList();
    pushUndo();
    masterIn.value = name;
    obj.userData.masterTexture = name;
    markDirty();
  };
  document.getElementById('btn-actor-mesh-master-clear').onclick = () => {
    pushUndo();
    masterIn.value = '';
    delete obj.userData.masterTexture;
    markDirty();
  };

  const listEl = document.getElementById('actor-mesh-list');
  listEl.innerHTML = '<div style="color:#666688;font-size:11px;padding:8px">Loading model meshes...</div>';
  document.getElementById('actor-mesh-modal').style.display = 'flex';

  const ext = actorPath.split('.').pop().toLowerCase();
  const loader = ext === 'fbx' ? new FBXLoader() : new GLTFLoader();
  loader.load(ASSET_ROOT + actorPath, result => {
    const root = result.scene || result;
    const meshes = [];
    root.traverse(c => { if (c.isMesh) meshes.push(c); });
    listEl.innerHTML = '';
    meshes.forEach(mesh => {
      const key = mesh.name || mesh.uuid;
      const ovr = overrides[key] || {};

      const row = document.createElement('div');
      row.style.cssText = 'display:grid;grid-template-columns:20px 1fr 130px 22px;gap:4px;align-items:center;padding:3px 6px;background:#0d0d20;border-radius:3px';

      const chk = document.createElement('input');
      chk.type = 'checkbox';
      chk.checked = ovr.visible !== false;
      chk.style.cursor = 'pointer';
      chk.addEventListener('change', () => {
        pushUndo();
        if (!overrides[key]) overrides[key] = {};
        overrides[key].visible = chk.checked;
        markDirty();
      });

      const label = document.createElement('span');
      label.textContent = mesh.name || '(unnamed)';
      label.style.cssText = 'font-size:11px;color:#aaaacc;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';

      const texIn = document.createElement('input');
      texIn.type = 'text';
      texIn.className = 'prop-input';
      texIn.value = ovr.texture || '';
      texIn.placeholder = 'texture name';
      texIn.style.cssText = 'font-size:11px;width:100%';
      texIn.setAttribute('list', 'tex-datalist');
      texIn.addEventListener('change', () => {
        pushUndo();
        const texName = texIn.value.trim() || null;
        if (!overrides[key]) overrides[key] = {};
        overrides[key].texture = texName;
        markDirty();
      });

      const impBtn = document.createElement('button');
      impBtn.className = 'btn';
      impBtn.textContent = '+';
      impBtn.title = 'Import texture';
      impBtn.style.cssText = 'padding:2px 4px;font-size:11px';
      impBtn.addEventListener('click', async () => {
        if (!window.electron?.importTexture) return;
        const name = await window.electron.importTexture();
        if (!name) return;
        await refreshTextureList();
        pushUndo();
        texIn.value = name;
        if (!overrides[key]) overrides[key] = {};
        overrides[key].texture = name;
        markDirty();
      });

      row.appendChild(chk);
      row.appendChild(label);
      row.appendChild(texIn);
      row.appendChild(impBtn);
      listEl.appendChild(row);
    });
    if (!meshes.length) {
      listEl.innerHTML = '<div style="color:#666688;font-size:11px;padding:8px">No meshes found in model.</div>';
    }
  }, undefined, () => {
    listEl.innerHTML = '<div style="color:#e94560;font-size:11px;padding:8px">Failed to load model.</div>';
  });
}

function closeActorMeshEditor() {
  document.getElementById('actor-mesh-modal').style.display = 'none';
}

const ACTOR_ANIM_ROLES = ['idle', 'walk', 'run', 'jump', 'vault', 'attack', 'hurt', 'death'];

async function openActorAnimsModal() {
  const obj = E.selected;
  if (!obj || obj.userData.primType !== 'actor-spawn') return;
  document.getElementById('actor-anims-model-name').textContent = (obj.userData.actorModel || '').split('/').pop() || 'Actor';
  if (!obj.userData.animations) obj.userData.animations = [];
  if (!obj.userData.actorRoles) obj.userData.actorRoles = {};
  _refreshActorRolesList(obj);
  _refreshActorAnimsList(obj);
  document.getElementById('actor-anims-modal').style.display = 'flex';
}

function _refreshActorRolesList(obj) {
  const container = document.getElementById('actor-anim-roles');
  if (!container) return;
  container.innerHTML = '';
  const roles = obj.userData.actorRoles || {};
  ACTOR_ANIM_ROLES.forEach(role => {
    const row = document.createElement('div');
    row.style.cssText = 'display:grid;grid-template-columns:52px 1fr 26px 22px;gap:3px;align-items:center';

    const lbl = document.createElement('span');
    lbl.textContent = role;
    lbl.style.cssText = 'font-size:11px;color:#8888aa;text-transform:capitalize';

    const inp = document.createElement('input');
    inp.type = 'text';
    inp.className = 'prop-input';
    inp.readOnly = true;
    inp.value = (roles[role] || '').split('/').pop() || '';
    inp.title = roles[role] || '';
    inp.placeholder = 'none';
    inp.style.cssText = 'font-size:11px;width:100%';

    const impBtn = document.createElement('button');
    impBtn.className = 'btn';
    impBtn.textContent = '+';
    impBtn.title = 'Import animation FBX for this role';
    impBtn.style.cssText = 'padding:2px 4px;font-size:11px';
    impBtn.addEventListener('click', async () => {
      if (!window.electron?.importActorAnim) return;
      const filePath = await window.electron.importActorAnim(obj.userData.actorModel);
      if (!filePath) return;
      pushUndo();
      if (!obj.userData.actorRoles) obj.userData.actorRoles = {};
      obj.userData.actorRoles[role] = filePath;
      inp.value = filePath.split('/').pop() || filePath;
      inp.title = filePath;
      markDirty();
    });

    const clearBtn = document.createElement('button');
    clearBtn.className = 'btn';
    clearBtn.textContent = '\u00d7';
    clearBtn.title = 'Clear';
    clearBtn.style.cssText = 'padding:2px 4px;font-size:12px';
    clearBtn.addEventListener('click', () => {
      pushUndo();
      if (obj.userData.actorRoles) delete obj.userData.actorRoles[role];
      inp.value = '';
      inp.title = '';
      markDirty();
    });

    row.appendChild(lbl);
    row.appendChild(inp);
    row.appendChild(impBtn);
    row.appendChild(clearBtn);
    container.appendChild(row);
  });
}

function _refreshActorAnimsList(obj) {
  const listEl = document.getElementById('actor-anims-list');
  if (!listEl) return;
  listEl.innerHTML = '';
  const anims = obj.userData.animations || [];
  if (!anims.length) {
    listEl.innerHTML = '<div style="color:#666688;font-size:11px;padding:8px">No custom clips imported yet.</div>';
    return;
  }
  anims.forEach((anim, i) => {
    const row = document.createElement('div');
    row.style.cssText = 'display:grid;grid-template-columns:1fr 120px 22px;gap:4px;align-items:center;padding:3px 6px;background:#0d0d20;border-radius:3px';

    const nameIn = document.createElement('input');
    nameIn.type = 'text';
    nameIn.className = 'prop-input';
    nameIn.value = anim.name || '';
    nameIn.placeholder = 'clip name (key in code)';
    nameIn.style.cssText = 'font-size:11px;width:100%';
    nameIn.addEventListener('change', () => { pushUndo(); anims[i].name = nameIn.value.trim(); markDirty(); });

    const fileSpan = document.createElement('span');
    fileSpan.textContent = (anim.file || '').split('/').pop() || '-';
    fileSpan.style.cssText = 'font-size:10px;color:#666688;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
    fileSpan.title = anim.file || '';

    const delBtn = document.createElement('button');
    delBtn.className = 'btn';
    delBtn.textContent = '\u00d7';
    delBtn.style.cssText = 'padding:2px 4px;font-size:12px';
    delBtn.addEventListener('click', () => {
      pushUndo();
      anims.splice(i, 1);
      _refreshActorAnimsList(obj);
      markDirty();
    });

    row.appendChild(nameIn);
    row.appendChild(fileSpan);
    row.appendChild(delBtn);
    listEl.appendChild(row);
  });
}

function closeActorAnimsModal() {
  document.getElementById('actor-anims-modal').style.display = 'none';
}

function openActorVariantsModal() {
  const obj = E.selected;
  if (!obj || obj.userData.primType !== 'actor-spawn') return;
  document.getElementById('actor-variants-model-name').textContent = (obj.userData.actorModel || '').split('/').pop() || 'Actor';
  if (!Array.isArray(obj.userData.actorVariants)) obj.userData.actorVariants = [];
  _refreshActorVariantsList(obj);
  document.getElementById('actor-variants-modal').style.display = 'flex';
}

function _refreshActorVariantsList(obj) {
  const listEl = document.getElementById('actor-variants-list');
  if (!listEl) return;
  listEl.innerHTML = '';
  const variants = obj.userData.actorVariants || [];
  if (!variants.length) {
    listEl.innerHTML = '<div style="color:#666688;font-size:11px;padding:8px">No variants. Base model used for all spawns.</div>';
    return;
  }
  variants.forEach((v, i) => {
    const row = document.createElement('div');
    row.style.cssText = 'display:grid;grid-template-columns:48px 1fr 46px 46px 46px 46px 22px;gap:3px;align-items:center;padding:3px 4px;background:#0d0d20;border-radius:3px';

    const makeNum = (val, ph, onChange) => {
      const inp = document.createElement('input');
      inp.type = 'number'; inp.className = 'prop-input';
      inp.value = val ?? ''; inp.placeholder = ph;
      inp.style.cssText = 'font-size:10px;width:100%;min-width:0';
      inp.min = '0';
      inp.addEventListener('change', () => { pushUndo(); onChange(inp.value === '' ? null : parseFloat(inp.value)); markDirty(); });
      return inp;
    };

    row.appendChild(makeNum(v.weight, '1', val => { v.weight = val; }));

    const modelWrap = document.createElement('div');
    modelWrap.style.cssText = 'display:flex;gap:2px;align-items:center;overflow:hidden';
    const modelSpan = document.createElement('span');
    modelSpan.textContent = (v.model || '-').split('/').pop();
    modelSpan.title = v.model || '';
    modelSpan.style.cssText = 'font-size:10px;color:#8888aa;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
    const pickBtn = document.createElement('button');
    pickBtn.className = 'btn'; pickBtn.textContent = '...';
    pickBtn.style.cssText = 'padding:1px 4px;font-size:10px;flex-shrink:0';
    pickBtn.addEventListener('click', () => {
      openActorModelPicker(result => {
        pushUndo();
        v.model = result.model;
        modelSpan.textContent = result.model.split('/').pop();
        modelSpan.title = result.model;
        markDirty();
      });
    });
    modelWrap.appendChild(modelSpan); modelWrap.appendChild(pickBtn);
    row.appendChild(modelWrap);

    row.appendChild(makeNum(v.health, 'def', val => { v.health = val; }));
    row.appendChild(makeNum(v.speed,  'def', val => { v.speed  = val; }));
    row.appendChild(makeNum(v.damage, 'def', val => { v.damage = val; }));
    row.appendChild(makeNum(v.crit,   'def', val => { v.crit   = val; }));

    const delBtn = document.createElement('button');
    delBtn.className = 'btn'; delBtn.textContent = '\u00d7';
    delBtn.style.cssText = 'padding:2px 4px;font-size:12px';
    delBtn.addEventListener('click', () => { pushUndo(); variants.splice(i, 1); _refreshActorVariantsList(obj); markDirty(); });
    row.appendChild(delBtn);

    listEl.appendChild(row);
  });
}

function closeActorVariantsModal() {
  document.getElementById('actor-variants-modal').style.display = 'none';
}

function openActorModelPicker(onPick) {
  E._actorModelPickerCallback = onPick;
  const listEl = document.getElementById('actor-model-picker-list');
  listEl.innerHTML = '';

  const makeHeader = text => {
    const h = document.createElement('div');
    h.style.cssText = 'font-size:9px;color:#444466;text-transform:uppercase;letter-spacing:1px;padding:8px 4px 3px 4px';
    h.textContent = text;
    return h;
  };
  const makeItem = (label, subLabel, model, sourceId) => {
    const div = document.createElement('div');
    div.className = 'picker-item';
    div.style.cssText = 'padding:5px 8px;border-radius:3px;cursor:pointer;background:#0d0d20';
    div.onmouseenter = () => { div.style.background = '#16163a'; };
    div.onmouseleave = () => { div.style.background = '#0d0d20'; };
    const nameSpan = document.createElement('span');
    nameSpan.style.cssText = 'font-size:11px;color:#ccccee;display:block';
    nameSpan.textContent = label;
    div.appendChild(nameSpan);
    if (subLabel) {
      const sub = document.createElement('span');
      sub.style.cssText = 'font-size:10px;color:#445566;display:block';
      sub.textContent = subLabel;
      div.appendChild(sub);
    }
    div.addEventListener('click', () => {
      document.getElementById('actor-model-picker').style.display = 'none';
      if (E._actorModelPickerCallback) { E._actorModelPickerCallback({ model, sourceId: sourceId || '' }); E._actorModelPickerCallback = null; }
    });
    return div;
  };

  if (E.importedActors?.length) {
    listEl.appendChild(makeHeader('Actors'));
    E.importedActors.forEach(a => listEl.appendChild(makeItem(a.name, a.path, a.path, '')));
  }
  if (E.importedModels?.length) {
    listEl.appendChild(makeHeader('Models'));
    E.importedModels.forEach(m => listEl.appendChild(makeItem(m.name, m.path, m.path, '')));
  }
  const sceneModels = E.placedGroup?.children.filter(o => o.userData.primType === 'model' && o.userData.modelPath) || [];
  if (sceneModels.length) {
    listEl.appendChild(makeHeader('From Scene'));
    sceneModels.forEach(o => listEl.appendChild(makeItem(
      o.userData.label || o.name,
      o.userData.modelPath.split('/').pop(),
      o.userData.modelPath,
      o.userData.editorId || ''
    )));
  }
  if (!listEl.children.length) {
    listEl.innerHTML = '<div style="color:#555577;font-size:11px;padding:10px">No models imported yet.</div>';
  }

  const searchIn = document.getElementById('actor-model-picker-search');
  if (searchIn) {
    searchIn.value = '';
    searchIn.oninput = () => {
      const term = searchIn.value.toLowerCase();
      listEl.querySelectorAll('.picker-item').forEach(el => {
        el.style.display = !term || el.textContent.toLowerCase().includes(term) ? '' : 'none';
      });
    };
  }
  document.getElementById('actor-model-picker').style.display = 'flex';
}

function _renderSoundSection(container, soundDef, onUpdate) {
  container.innerHTML = '';
  const isRandom = soundDef.mode === 'random';

  const modeRow = document.createElement('div');
  modeRow.style.cssText = 'display:flex;align-items:center;gap:6px;margin-bottom:8px';
  const modeLbl = document.createElement('span');
  modeLbl.textContent = 'Mode:';
  modeLbl.style.cssText = 'font-size:10px;color:#666688;flex-shrink:0';
  const modeSel = document.createElement('select');
  modeSel.className = 'prop-input';
  modeSel.style.cssText = 'font-size:11px;padding:2px 4px';
  [['sequential','Sequential'],['random','Random (weighted)']].forEach(([v, l]) => {
    const o = document.createElement('option');
    o.value = v; o.textContent = l;
    if (soundDef.mode === v) o.selected = true;
    modeSel.appendChild(o);
  });
  modeSel.addEventListener('change', e => {
    pushUndo();
    soundDef.mode = e.target.value;
    _renderSoundSection(container, soundDef, onUpdate);
    onUpdate();
  });
  modeRow.appendChild(modeLbl);
  modeRow.appendChild(modeSel);
  container.appendChild(modeRow);

  const listDiv = document.createElement('div');
  listDiv.style.cssText = 'display:flex;flex-direction:column;gap:3px;margin-bottom:6px';
  soundDef.sounds.forEach((s, i) => {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:4px;align-items:center';

    const nameIn = document.createElement('input');
    nameIn.className = 'prop-input';
    nameIn.type = 'text';
    nameIn.value = s.name || '';
    nameIn.placeholder = 'sound name';
    nameIn.setAttribute('list', 'sound-datalist');
    nameIn.style.cssText = 'flex:1;font-size:11px';
    nameIn.addEventListener('change', e => { pushUndo(); s.name = e.target.value.trim(); onUpdate(); });

    row.appendChild(nameIn);

    if (isRandom) {
      const wtLbl = document.createElement('span');
      wtLbl.textContent = 'w:';
      wtLbl.style.cssText = 'font-size:10px;color:#666688;flex-shrink:0';
      const wtIn = document.createElement('input');
      wtIn.className = 'prop-input';
      wtIn.type = 'number'; wtIn.min = '0'; wtIn.step = '0.1';
      wtIn.value = s.weight ?? 1;
      wtIn.style.width = '44px';
      wtIn.addEventListener('change', e => { pushUndo(); s.weight = parseFloat(e.target.value) || 1; onUpdate(); });
      row.appendChild(wtLbl);
      row.appendChild(wtIn);
    }

    const del = document.createElement('button');
    del.className = 'btn btn-del';
    del.style.cssText = 'padding:2px 6px;font-size:11px;flex-shrink:0';
    del.textContent = '×';
    del.addEventListener('click', () => {
      pushUndo();
      soundDef.sounds.splice(i, 1);
      _renderSoundSection(container, soundDef, onUpdate);
      onUpdate();
    });
    row.appendChild(del);
    listDiv.appendChild(row);
  });
  container.appendChild(listDiv);

  const btnRow = document.createElement('div');
  btnRow.style.cssText = 'display:flex;gap:4px';
  const addBtn = document.createElement('button');
  addBtn.className = 'btn';
  addBtn.style.cssText = 'font-size:11px;padding:2px 10px';
  addBtn.textContent = '+ Add';
  addBtn.addEventListener('click', () => {
    pushUndo();
    soundDef.sounds.push({ name: '', weight: 1 });
    _renderSoundSection(container, soundDef, onUpdate);
    onUpdate();
  });
  const impBtn = document.createElement('button');
  impBtn.className = 'btn';
  impBtn.style.cssText = 'font-size:11px;padding:2px 10px';
  impBtn.textContent = '+ Import';
  impBtn.addEventListener('click', async () => {
    if (!window.electron?.importSound) return;
    const name = await window.electron.importSound();
    if (!name) return;
    await refreshSoundList();
    pushUndo();
    soundDef.sounds.push({ name, weight: 1 });
    _renderSoundSection(container, soundDef, onUpdate);
    onUpdate();
  });
  btnRow.appendChild(addBtn);
  btnRow.appendChild(impBtn);
  container.appendChild(btnRow);
}

function openSoundListModal(obj, stateIdx) {
  const state = obj.userData.states[stateIdx];
  document.getElementById('sound-list-modal-title').textContent = state.name || ('State ' + stateIdx);
  if (!state.enterSounds) state.enterSounds = { mode: 'sequential', sounds: [] };
  if (!state.exitSounds)  state.exitSounds  = { mode: 'sequential', sounds: [] };
  const dirty = () => markDirty();
  _renderSoundSection(document.getElementById('snd-enter-list'), state.enterSounds, dirty);
  _renderSoundSection(document.getElementById('snd-exit-list'),  state.exitSounds,  dirty);
  document.getElementById('sound-list-modal').style.display = 'flex';
}

function closeSoundListModal() {
  document.getElementById('sound-list-modal').style.display = 'none';
}

function _applyMeshEditorTexture(mesh, texName) {
  if (!texName) return;
  const loader = new THREE.TextureLoader();
  const tryLoad = url => new Promise(resolve => loader.load(url, resolve, undefined, () => resolve(null)));
  (async () => {
    let tex = await tryLoad(`${ASSET_ROOT}textures/${texName}.png`);
    if (!tex) tex = await tryLoad(`${ASSET_ROOT}textures/${texName}.jpg`);
    if (!tex) return;
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    mats.forEach(m => { if (m) { m.map = tex; m.needsUpdate = true; } });
  })();
}

const MODEL_MAP_SLOTS = { diffuse: 'map', normal: 'normalMap', roughness: 'roughnessMap', metalness: 'metalnessMap' };

function _ensureModelPbr(obj) {
  let converted = false;
  const roughness = obj.userData.roughness ?? 1;
  const metalness = obj.userData.metalness ?? 0;
  obj.traverse(c => {
    if (!c.isMesh) return;
    const mats = Array.isArray(c.material) ? c.material : [c.material];
    const newMats = mats.map(m => {
      if (!m || 'roughness' in m) return m;
      converted = true;
      return new THREE.MeshStandardMaterial({
        color: m.color?.clone() ?? new THREE.Color(0xffffff),
        map: m.map ?? null, normalMap: m.normalMap ?? null,
        emissiveMap: m.emissiveMap ?? null, aoMap: m.aoMap ?? null,
        emissive: m.emissive?.clone() ?? new THREE.Color(0x000000),
        emissiveIntensity: m.emissiveIntensity ?? 1,
        roughness, metalness, side: m.side,
        transparent: m.transparent, opacity: m.opacity,
      });
    });
    c.material = Array.isArray(c.material) ? newMats : newMats[0];
  });
  if (converted) {
    obj.userData.pbrConverted = true;
    setStatus('Auto-converted to PBR material to support map assignment', 3000);
    markDirty();
    updateProps(obj);
  }
}

let _ibLoader = null;
function _getIBLoader() {
  if (!_ibLoader) { _ibLoader = new THREE.ImageBitmapLoader(); _ibLoader.setOptions({ imageOrientation: 'flipY' }); }
  return _ibLoader;
}
function _loadTexIB(url) {
  return new Promise(r => _getIBLoader().load(url, bmp => { const t = new THREE.Texture(bmp); t.flipY = false; t.needsUpdate = true; r(t); }, undefined, () => r(null)));
}
const _texInitQueue = [];
let _texInitRunning = false;
function _scheduleTexInit(tex) {
  _texInitQueue.push(tex);
  if (!_texInitRunning) { _texInitRunning = true; requestAnimationFrame(_drainTexInit); }
}
function _drainTexInit() {
  const tex = _texInitQueue.shift();
  if (tex && E.renderer) E.renderer.initTexture(tex);
  if (_texInitQueue.length) requestAnimationFrame(_drainTexInit);
  else _texInitRunning = false;
}
async function _applyModelMapsToObj(obj, maps) {
  if (!maps) return;
  const res = obj.userData.modelMapRes || {};
  const entries = Object.entries(maps).filter(([, v]) => v);
  await Promise.all(entries.map(async ([slot, texName]) => {
    const matKey = MODEL_MAP_SLOTS[slot]; if (!matKey) return;
    const colorSpace = slot === 'diffuse' ? THREE.SRGBColorSpace : THREE.LinearSRGBColorSpace;
    const resCap = res[slot] || null;
    let blob = null;
    for (const ext of ['png', 'jpg']) {
      try { const r = await fetch(`${ASSET_ROOT}textures/${texName}.${ext}`); if (r.ok) { blob = await r.blob(); break; } } catch {}
    }
    if (!blob) return;
    const applyTex = tex => {
      tex.colorSpace = colorSpace;
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      obj.traverse(c => {
        if (!c.isMesh) return;
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { if (m) { m[matKey] = tex; m.needsUpdate = true; } });
      });
    };
    const smallBmp = await createImageBitmap(blob, { resizeWidth: 64, resizeHeight: 64, resizeQuality: 'low', imageOrientation: 'flipY' });
    const smallTex = new THREE.Texture(smallBmp); smallTex.flipY = false; smallTex.needsUpdate = true;
    applyTex(smallTex);
    const fullOpts = resCap ? { resizeWidth: resCap, resizeHeight: resCap, resizeQuality: 'high', imageOrientation: 'flipY' } : { imageOrientation: 'flipY' };
    const fullBmp = await createImageBitmap(blob, fullOpts);
    const fullTex = new THREE.Texture(fullBmp); fullTex.flipY = false; fullTex.needsUpdate = true;
    _scheduleTexInit(fullTex);
    applyTex(fullTex);
  }));
}

async function applyModelMapSlot(obj, slot, texName) {
  if (!texName) {
    const matKey = MODEL_MAP_SLOTS[slot]; if (!matKey) return;
    obj.traverse(c => {
      if (!c.isMesh) return;
      const mats = Array.isArray(c.material) ? c.material : [c.material];
      mats.forEach(m => { if (m) { m[matKey] = null; m.needsUpdate = true; } });
    });
    if (obj.userData.modelMaps) { delete obj.userData.modelMaps[slot]; if (!Object.keys(obj.userData.modelMaps).length) delete obj.userData.modelMaps; }
    markDirty(); return;
  }
  if (slot !== 'diffuse') _ensureModelPbr(obj);
  const matKey = MODEL_MAP_SLOTS[slot]; if (!matKey) return;
  const resCap = obj.userData.modelMapRes?.[slot] || null;
  let blob = null;
  for (const ext of ['png', 'jpg']) {
    try { const r = await fetch(`${ASSET_ROOT}textures/${texName}.${ext}`); if (r.ok) { blob = await r.blob(); break; } } catch {}
  }
  if (!blob) { setStatus(`Texture "${texName}" not found`); return; }
  const bmpOpts = resCap ? { resizeWidth: resCap, resizeHeight: resCap, resizeQuality: 'high', imageOrientation: 'flipY' } : { imageOrientation: 'flipY' };
  const bmp = await createImageBitmap(blob, bmpOpts);
  const tex = new THREE.Texture(bmp); tex.flipY = false; tex.needsUpdate = true;
  tex.colorSpace = slot === 'diffuse' ? THREE.SRGBColorSpace : THREE.LinearSRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  _scheduleTexInit(tex);
  obj.traverse(c => {
    if (!c.isMesh) return;
    const mats = Array.isArray(c.material) ? c.material : [c.material];
    mats.forEach(m => { if (m) { m[matKey] = tex; m.needsUpdate = true; } });
  });
  if (!obj.userData.modelMaps) obj.userData.modelMaps = {};
  obj.userData.modelMaps[slot] = texName;
  markDirty();
}

function refreshModelMapsPanel(obj) {
  const maps = obj?.userData?.modelMaps || {};
  const dl = document.getElementById('model-maps-datalist');
  if (dl && E.availableTextures) {
    dl.innerHTML = E.availableTextures.map(t => `<option value="${t}">`).join('');
  }
  const res = obj?.userData?.modelMapRes || {};
  ['diffuse','normal','roughness','metalness'].forEach(slot => {
    const el = document.getElementById(`mmap-${slot}`);
    if (el) el.value = maps[slot] || '';
    const rel = document.getElementById(`mmap-res-${slot}`);
    if (rel) rel.value = res[slot] ? String(res[slot]) : '';
  });
}

function _applyMasterTexture(obj, texName) {  if (texName) {
    const loader = new THREE.TextureLoader();
    const tryLoad = url => new Promise(resolve => loader.load(url, resolve, undefined, () => resolve(null)));
    (async () => {
      let tex = await tryLoad(`${ASSET_ROOT}textures/${texName}.png`);
      if (!tex) tex = await tryLoad(`${ASSET_ROOT}textures/${texName}.jpg`);
      if (!tex) return;
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      obj.traverse(c => {
        if (!c.isMesh) return;
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { if (m) { m.map = tex; m.needsUpdate = true; } });
      });
    })();
  } else {
    obj.traverse(c => {
      if (!c.isMesh) return;
      const key = c.name || c.uuid;
      const ovr = obj.userData.meshOverrides?.[key];
      if (ovr?.texture) {
        _applyMeshEditorTexture(c, ovr.texture);
      }
    });
  }
}

function _loadUVEditorImage(texName) {
  if (!texName) { E.uvEditorImage = null; _drawUVCanvas(); return; }
  const img = new Image();
  img.onload = () => { E.uvEditorImage = img; _drawUVCanvas(); };
  img.onerror = () => {
    const jpg = new Image();
    jpg.onload = () => { E.uvEditorImage = jpg; _drawUVCanvas(); };
    jpg.onerror = () => { E.uvEditorImage = null; _drawUVCanvas(); };
    jpg.src = `textures/${texName}.jpg`;
  };
  img.src = `textures/${texName}.png`;
}

function _drawUVCanvas() {
  const canvas = document.getElementById('uv-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;

  // Checkerboard background
  const ts = 20;
  for (let ty = 0; ty < H; ty += ts) {
    for (let tx = 0; tx < W; tx += ts) {
      ctx.fillStyle = ((tx / ts + ty / ts) % 2 === 0) ? '#12122a' : '#1e1e38';
      ctx.fillRect(tx, ty, ts, ts);
    }
  }

  // Draw texture image as 2×2 tiles
  const img = E.uvEditorImage;
  if (img && img.complete && img.naturalWidth > 0) {
    ctx.save();
    ctx.globalAlpha = 0.65;
    for (let tx = 0; tx < 2; tx++) for (let ty = 0; ty < 2; ty++)
      ctx.drawImage(img, tx * W / 2, ty * H / 2, W / 2, H / 2);
    ctx.restore();
  }

  // Grid lines at UV = 1.0 boundary
  ctx.strokeStyle = '#444466';
  ctx.lineWidth = 1;
  ctx.setLineDash([]);
  ctx.beginPath();
  ctx.moveTo(W / 2, 0); ctx.lineTo(W / 2, H);
  ctx.moveTo(0, H / 2); ctx.lineTo(W, H / 2);
  ctx.stroke();

  // Parse current UV values
  const ox = parseFloat(document.getElementById('uv-ox')?.value) || 0;
  const oy = parseFloat(document.getElementById('uv-oy')?.value) || 0;
  const rx = Math.max(0.01, parseFloat(document.getElementById('uv-rx')?.value) || 1);
  const ry = Math.max(0.01, parseFloat(document.getElementById('uv-ry')?.value) || 1);

  // UV window in pixel space (canvas spans 2×2 UV tiles)
  const uvW = 1 / rx, uvH = 1 / ry;
  const pxX = (ox / 2) * W;
  const pxY = (oy / 2) * H;
  const pxW = (uvW / 2) * W;
  const pxH = (uvH / 2) * H;

  // Fill
  ctx.fillStyle = 'rgba(68,153,255,0.12)';
  ctx.fillRect(pxX, pxY, pxW, pxH);

  // Dashed border
  ctx.strokeStyle = '#4499ff';
  ctx.lineWidth = 2;
  ctx.setLineDash([6, 3]);
  ctx.strokeRect(pxX, pxY, pxW, pxH);
  ctx.setLineDash([]);

  // Corner handles
  const corners = [
    [pxX, pxY], [pxX + pxW, pxY],
    [pxX, pxY + pxH], [pxX + pxW, pxY + pxH]
  ];
  ctx.fillStyle = '#4499ff';
  corners.forEach(([cx, cy]) => ctx.fillRect(cx - 5, cy - 5, 10, 10));

  // Center dot
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(pxX + pxW / 2 - 3, pxY + pxH / 2 - 3, 6, 6);
}

// UV canvas drag state
let _uvDrag = null;

function _setupUVCanvasDrag() {
  const canvas = document.getElementById('uv-canvas');
  if (!canvas) return;

  const getUV = () => ({
    ox: parseFloat(document.getElementById('uv-ox').value) || 0,
    oy: parseFloat(document.getElementById('uv-oy').value) || 0,
    rx: Math.max(0.01, parseFloat(document.getElementById('uv-rx').value) || 1),
    ry: Math.max(0.01, parseFloat(document.getElementById('uv-ry').value) || 1),
  });
  const setUV = (ox, oy, rx, ry) => {
    document.getElementById('uv-ox').value = ox.toFixed(3);
    document.getElementById('uv-oy').value = oy.toFixed(3);
    document.getElementById('uv-rx').value = Math.max(0.01, rx).toFixed(2);
    document.getElementById('uv-ry').value = Math.max(0.01, ry).toFixed(2);
    _drawUVCanvas();
  };

  canvas.addEventListener('mousedown', e => {
    const r  = canvas.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    const W  = canvas.width, H = canvas.height;
    const uv = getUV();
    const uvW = 1 / uv.rx, uvH = 1 / uv.ry;
    const pxX = (uv.ox / 2) * W, pxY = (uv.oy / 2) * H;
    const pxW = (uvW / 2) * W,  pxH = (uvH / 2) * H;

    const corners = [
      { x: pxX, y: pxY, ci: 0 }, { x: pxX + pxW, y: pxY, ci: 1 },
      { x: pxX, y: pxY + pxH, ci: 2 }, { x: pxX + pxW, y: pxY + pxH, ci: 3 }
    ];
    const hit = corners.find(c => Math.abs(mx - c.x) < 9 && Math.abs(my - c.y) < 9);
    if (hit) {
      _uvDrag = { type: 'corner', mx, my, ci: hit.ci, ...uv };
    } else if (mx >= pxX && mx <= pxX + pxW && my >= pxY && my <= pxY + pxH) {
      _uvDrag = { type: 'move', mx, my, ...uv };
    }
    if (_uvDrag) e.preventDefault();
  });

  canvas.addEventListener('mousemove', e => {
    if (!_uvDrag) return;
    const r  = canvas.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    const W  = canvas.width, H = canvas.height;
    const dx = (mx - _uvDrag.mx) / W * 2;   // delta in UV space (0→2 canvas)
    const dy = (my - _uvDrag.my) / H * 2;

    let { ox, oy, rx, ry } = _uvDrag;
    const uvW = 1 / rx, uvH = 1 / ry;

    if (_uvDrag.type === 'move') {
      setUV(ox + dx, oy + dy, rx, ry);
    } else {
      const ci = _uvDrag.ci;
      // Horizontal: right corners expand width, left corners shift ox + shrink width
      if (ci === 1 || ci === 3) {
        const newUvW = Math.max(0.02, uvW + dx);
        setUV(ox, oy, 1 / newUvW, 1 / (ci === 2 || ci === 3 ? Math.max(0.02, uvH + dy) : Math.max(0.02, uvH - dy)));
      } else {
        const newUvW = Math.max(0.02, uvW - dx);
        const newUvH = ci === 2 || ci === 3 ? Math.max(0.02, uvH + dy) : Math.max(0.02, uvH - dy);
        setUV(ox + dx, ci < 2 ? oy + dy : oy, 1 / newUvW, 1 / newUvH);
      }
    }
  });

  canvas.addEventListener('mouseup',    () => { _uvDrag = null; });
  canvas.addEventListener('mouseleave', () => { _uvDrag = null; });

  // Redraw when inputs change
  ['uv-ox','uv-oy','uv-rx','uv-ry'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', _drawUVCanvas);
  });
}

// ─── CSG Cut ──────────────────────────────────────────────────────────────────
// ─── Pivot pick ──────────────────────────────────────────────────────────────
function beginPivot() {
  if (!E.selected || E.selected.userData.isRef) {
    setStatus('Select a placed object first to set its pivot');
    return;
  }
  E.pivotMode   = true;
  E.pivotSource = E.selected;
  document.getElementById('pivot-hint').style.display = '';
  document.getElementById('btn-set-pivot').classList.add('active');
  setStatus('Pivot mode — click any surface to set the pivot point (Esc cancels)');
}

function cancelPivot() {
  if (!E.pivotMode) return;
  E.pivotMode   = false;
  E.pivotSource = null;
  document.getElementById('pivot-hint').style.display = 'none';
  document.getElementById('btn-set-pivot').classList.remove('active');
  setStatus('Pivot cancelled');
}

function applyPivot(worldPoint) {
  const obj = E.pivotSource;
  cancelPivot();
  if (!obj) return;

  pushUndo();
  // Convert the clicked world point into object-local space
  const localHit = obj.worldToLocal(worldPoint.clone());
  obj.userData.pivotOffset = localHit.toArray();

  // Re-attach TransformControls to a helper that sits at the pivot
  _refreshPivotHelper(obj);
  document.getElementById('btn-reset-pivot').style.display = '';
  markDirty();
  setStatus(`Pivot set to (${localHit.x.toFixed(2)}, ${localHit.y.toFixed(2)}, ${localHit.z.toFixed(2)}) in local space`);
}

// ─── Rope anchor attach ───────────────────────────────────────────────────────
function beginRopeAnchor(end) {
  const obj = E.selected;
  if (!obj || obj.userData.primType !== 'rope') {
    setStatus('Select a rope first');
    return;
  }
  E.ropeAnchorMode   = end;
  E.ropeAnchorSource = obj;
  document.getElementById('rope-anchor-hint').style.display = '';
  document.getElementById('btn-rope-attach-a').classList.toggle('active', end === 'A');
  document.getElementById('btn-rope-attach-b').classList.toggle('active', end === 'B');
  setStatus(`Rope End ${end} — click any surface to attach (Esc cancels)`);
}

function cancelRopeAnchor() {
  if (!E.ropeAnchorMode) return;
  E.ropeAnchorMode   = null;
  E.ropeAnchorSource = null;
  document.getElementById('rope-anchor-hint').style.display = 'none';
  document.getElementById('btn-rope-attach-a').classList.remove('active');
  document.getElementById('btn-rope-attach-b').classList.remove('active');
  setStatus('Rope attach cancelled');
}

function applyRopeAnchor(worldPoint, hitObj) {
  const end  = E.ropeAnchorMode;
  const rope = E.ropeAnchorSource;
  cancelRopeAnchor();
  if (!rope || !end) return;
  pushUndo();
  const p = rope.userData.geomParams ??= {};
  if (end === 'A') {
    const prevPos = rope.position.clone();
    const delta   = worldPoint.clone().sub(prevPos);
    rope.position.copy(worldPoint);
    if (rope.userData._restPos) rope.userData._restPos.copy(worldPoint);
    const bOff = p.anchorBOffset ? [...p.anchorBOffset] : [0, -0.5, 0];
    bOff[0] -= delta.x; bOff[1] -= delta.y; bOff[2] -= delta.z;
    p.anchorBOffset = bOff;
    if (hitObj && hitObj.userData.editorId !== undefined) {
      const objWPos = new THREE.Vector3();
      hitObj.getWorldPosition(objWPos);
      p.anchorAId     = hitObj.userData.editorId;
      p.anchorAOffset = worldPoint.clone().sub(objWPos).toArray();
    } else {
      delete p.anchorAId;
      delete p.anchorAOffset;
    }
  } else {
    const rWPos = rope.position.clone();
    p.anchorBOffset = [worldPoint.x - rWPos.x, worldPoint.y - rWPos.y, worldPoint.z - rWPos.z];
    if (hitObj && hitObj.userData.editorId !== undefined) {
      const objWPos = new THREE.Vector3();
      hitObj.getWorldPosition(objWPos);
      p.anchorBId          = hitObj.userData.editorId;
      p.anchorBWorldOffset = worldPoint.clone().sub(objWPos).toArray();
    } else {
      delete p.anchorBId;
      delete p.anchorBWorldOffset;
    }
  }
  rebuildGeometry(rope);
  updateProps(rope);
  markDirty();
  const objLabel = hitObj?.name || (hitObj ? '#' + hitObj.userData.editorId : 'free');
  setStatus(`Rope End ${end} attached to ${objLabel} at (${worldPoint.x.toFixed(2)}, ${worldPoint.y.toFixed(2)}, ${worldPoint.z.toFixed(2)})`);
}

function resetPivot() {
  const obj = E.selected;
  if (!obj) return;
  delete obj.userData.pivotOffset;
  // Remove any pivot helper and re-attach TransformControls directly to obj
  const helper = E.scene.getObjectByName('__pivotHelper__');
  if (helper) {
    // If obj was parented under helper, un-parent
    if (obj.parent === helper) {
      const wPos = new THREE.Vector3(), wRot = new THREE.Quaternion(), wScl = new THREE.Vector3();
      obj.getWorldPosition(wPos); obj.getWorldQuaternion(wRot); obj.getWorldScale(wScl);
      E.placedGroup.add(obj);
      obj.position.copy(wPos); obj.quaternion.copy(wRot); obj.scale.copy(wScl);
    }
    E.scene.remove(helper);
  }
  E.transform.detach();
  E.transform.attach(obj);
  document.getElementById('btn-reset-pivot').style.display = 'none';
  markDirty();
  setStatus('Pivot reset to object centre');
}

function _refreshPivotHelper(obj) {
  // Remove previous helper
  const old = E.scene.getObjectByName('__pivotHelper__');
  if (old) E.scene.remove(old);

  if (!obj.userData.pivotOffset) {
    E.transform.detach();
    E.transform.attach(obj);
    return;
  }

  const localOffset = new THREE.Vector3().fromArray(obj.userData.pivotOffset);
  const worldOffset = localOffset.clone().applyMatrix4(obj.matrixWorld);
  // Just attach controls at the object itself — the visual pivot dot shows the offset
  // We show a small dot at the pivot world position and let the user intuitively understand
  E.transform.detach();
  E.transform.attach(obj);

  // Show a visible pivot dot in the scene
  let dot = E.scene.getObjectByName('__pivotDot__');
  if (!dot) {
    dot = new THREE.Mesh(
      new THREE.SphereGeometry(0.1, 8, 6),
      new THREE.MeshBasicMaterial({ color: 0x44aaff, depthTest: false, toneMapped: false })
    );
    dot.name = '__pivotDot__';
    dot.renderOrder = 998;
    E.scene.add(dot);
  }
  dot.position.copy(worldOffset);
  dot.visible = true;
}

function _updatePivotDot() {
  const dot = E.scene.getObjectByName('__pivotDot__');
  if (!dot) return;
  const obj = E.selected;
  if (!obj || !obj.userData.pivotOffset) { dot.visible = false; return; }
  const localOffset = new THREE.Vector3().fromArray(obj.userData.pivotOffset);
  dot.position.copy(localOffset.clone().applyMatrix4(obj.matrixWorld));
  dot.visible = true;
}

function beginCut() {
  if (!E.selected || E.selected.userData.isRef) {
    setStatus('Select a placed object first to use as the cutter');
    return;
  }
  if (isLightType(E.selected.userData.primType)) {
    setStatus('Lights cannot be used as CSG cutters');
    return;
  }
  if (!E.levelName) { setStatus('Open a level first'); return; }
  E.cutMode   = true;
  E.cutSource = E.selected;
  // Highlight the cutter in orange so it's clearly distinguishable
  _tintCutter(E.cutSource, true);
  document.getElementById('cut-hint').style.display = '';
  document.getElementById('btn-cut').classList.add('active');
  setStatus('Cut mode — click the object you want to cut into (Esc cancels)');
}

function cancelCut() {
  if (!E.cutMode) return;
  _tintCutter(E.cutSource, false);
  E.cutMode   = false;
  E.cutSource = null;
  document.getElementById('cut-hint').style.display = 'none';
  document.getElementById('btn-cut').classList.remove('active');
  setStatus('Cut cancelled');
}

// Temporarily tint the cutter mesh orange / restore original material
function _tintCutter(obj, on) {
  if (!obj) return;
  obj.traverse(c => {
    if (!c.isMesh) return;
    if (on) {
      c.userData._savedMaterial = c.material;
      const tinted = c.material.clone();
      if (tinted.color) tinted.color.setHex(0xff6600);
      c.material = tinted;
    } else {
      if (c.userData._savedMaterial) {
        c.material = c.userData._savedMaterial;
        delete c.userData._savedMaterial;
      }
    }
  });
}

async function performCut(targetObj) {
  const cutter = E.cutSource;
  cancelCut(); // clear state / tint

  // Both must be placed (not isRef)
  if (!cutter || !targetObj || cutter === targetObj) {
    setStatus('Invalid cut targets');
    return;
  }
  if (targetObj.userData.isRef) {
    setStatus('Cannot cut into reference scene objects — place a box wall instead');
    return;
  }
  if (isLightType(targetObj.userData.primType)) {
    setStatus('Cannot cut into a light object');
    return;
  }
  if (!cutter.isMesh && !cutter.isGroup) {
    setStatus('Cutter must be a simple primitive or model for CSG');
    return;
  }

  setStatus('Running CSG subtraction…');

  // Lazy-create evaluator
  if (!E.csgEvaluator) E.csgEvaluator = new Evaluator();

  try {
    // Build Brush objects. Brush is a Mesh, so for groups we need a merged geometry.
    const brushA = _meshToBrush(targetObj);
    const brushB = _meshToBrush(cutter);

    if (!brushA || !brushB) {
      setStatus('CSG failed: object has no mesh geometry');
      return;
    }

    brushA.updateMatrixWorld(true);
    brushB.updateMatrixWorld(true);

    // Perform subtraction: A minus B
    const result = E.csgEvaluator.evaluate(brushA, brushB, SUBTRACTION);

    // Center the geometry at its bounding box midpoint so the gizmo and
    // orbit target land on the wall, not at world origin.
    result.geometry.computeBoundingBox();
    const _csgCenter = new THREE.Vector3();
    result.geometry.boundingBox.getCenter(_csgCenter);
    result.geometry.translate(-_csgCenter.x, -_csgCenter.y, -_csgCenter.z);
    result.position.copy(_csgCenter);
    result.rotation.set(0, 0, 0);
    result.scale.setScalar(1);
    result.castShadow    = targetObj.castShadow;
    result.receiveShadow = true;
    result.userData = {
      ...targetObj.userData,
      primType:  'csg-result',
      csgRecipe: {
        base:    _entryFromObj(targetObj),
        cutters: [ _entryFromObj(cutter) ],
      },
    };
    // Carry forward any existing cutters only if base is a plain prim (not itself a csg-result).
    // If targetObj is already a csg-result its full recipe is embedded in base via _entryFromObj.
    if (targetObj.userData.csgRecipe && targetObj.userData.primType !== 'csg-result') {
      result.userData.csgRecipe.cutters.push(...targetObj.userData.csgRecipe.cutters);
    }
    result.name = targetObj.name;

    E.placedGroup.remove(targetObj);
    E.placedGroup.add(result);

    // Remove the cutter from the scene
    const cutterId = cutter.userData.editorId;
    for (const g of Object.values(E.groups)) g.ids.delete(cutterId);
    for (const gid of Object.keys(E.groups)) { if (E.groups[gid].ids.size === 0) delete E.groups[gid]; }
    E.placedGroup.remove(cutter);

    selectObj(result);
    pushUndo(); updateSceneList(); updateGroupsPanel(); markDirty();
    setStatus(`Cut complete — "${result.name}" geometry updated`);

  } catch (err) {
    setStatus('CSG error: ' + err.message);
    console.error(err);
  }
}

// Build a Brush (Mesh with world transform baked) from a possibly-grouped object.
// We use a simple merged-geometry approach for groups/models.
function _meshToBrush(obj) {
  obj.updateMatrixWorld(true);

  // Collect all descendant meshes (or self if it's a single mesh)
  const meshes = [];
  if (obj.isMesh) {
    meshes.push(obj);
  } else {
    obj.traverse(c => { if (c.isMesh) meshes.push(c); });
  }
  if (!meshes.length) return null;

  // Merge all into one BufferGeometry in world space
  const merged = mergeGeometriesWorldSpace(meshes);
  if (!merged) return null;

  const material = meshes[0].material ?? new THREE.MeshStandardMaterial();
  const brush = new Brush(merged, Array.isArray(material) ? material[0] : material);
  // Brush is already in world space, so identity transform
  brush.updateMatrixWorld(true);
  return brush;
}

// Merge multiple meshes into a single BufferGeometry, transforming each into world space.
function mergeGeometriesWorldSpace(meshes) {
  const posArrays  = [], normArrays = [], uvArrays = [], idxArrays = [];
  let vertOffset = 0;

  meshes.forEach(mesh => {
    mesh.updateMatrixWorld(true);
    const geo = mesh.geometry.clone();
    geo.applyMatrix4(mesh.matrixWorld);

    // If the world matrix has a negative determinant (odd number of negative scales),
    // winding order is flipped which breaks CSG inside/outside detection — flip it back.
    if (mesh.matrixWorld.determinant() < 0) {
      const idx = geo.index;
      if (idx) {
        for (let i = 0; i < idx.array.length; i += 3) {
          const tmp = idx.array[i + 1]; idx.array[i + 1] = idx.array[i + 2]; idx.array[i + 2] = tmp;
        }
      } else {
        const pos = geo.attributes.position;
        for (let i = 0; i < pos.count; i += 3) {
          for (let c = 0; c < 3; c++) {
            const tmp = pos.getComponent(i + 1, c);
            pos.setComponent(i + 1, c, pos.getComponent(i + 2, c));
            pos.setComponent(i + 2, c, tmp);
          }
        }
      }
      geo.computeVertexNormals();
    }

    const pos  = geo.attributes.position;
    const norm = geo.attributes.normal;
    const uv   = geo.attributes.uv;
    const idx  = geo.index;

    posArrays.push(pos.array);
    if (norm) normArrays.push(norm.array);
    if (uv)   uvArrays.push(uv.array);

    if (idx) {
      const shifted = new Uint32Array(idx.array.length);
      for (let i = 0; i < idx.array.length; i++) shifted[i] = idx.array[i] + vertOffset;
      idxArrays.push(shifted);
    } else {
      const count   = pos.count;
      const trivial = new Uint32Array(count);
      for (let i = 0; i < count; i++) trivial[i] = i + vertOffset;
      idxArrays.push(trivial);
    }
    vertOffset += pos.count;
  });

  const totalVerts = posArrays.reduce((s, a) => s + a.length / 3, 0);
  const totalIdx   = idxArrays.reduce((s, a) => s + a.length, 0);

  const positions = new Float32Array(totalVerts * 3);
  const normals   = normArrays.length === meshes.length ? new Float32Array(totalVerts * 3) : null;
  const uvs       = uvArrays.length   === meshes.length ? new Float32Array(totalVerts * 2) : null;
  const indices   = new Uint32Array(totalIdx);

  let pOff = 0, nOff = 0, uOff = 0, iOff = 0;
  posArrays.forEach((pa, i) => {
    positions.set(pa, pOff); pOff += pa.length;
    if (normals && normArrays[i]) { normals.set(normArrays[i], nOff); nOff += normArrays[i].length; }
    if (uvs     && uvArrays[i])   { uvs.set(uvArrays[i],     uOff); uOff += uvArrays[i].length; }
  });
  idxArrays.forEach(ia => { indices.set(ia, iOff); iOff += ia.length; });

  const result = new THREE.BufferGeometry();
  result.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  if (normals) result.setAttribute('normal',   new THREE.BufferAttribute(normals, 3));
  if (uvs)     result.setAttribute('uv',       new THREE.BufferAttribute(uvs,     2));
  result.setIndex(new THREE.BufferAttribute(indices, 1));
  return result;
}

// Serialize an object to a level-entry-style record (for csgRecipe storage)
function _entryFromObj(obj) {
  const matColor = Array.isArray(obj.material) ? obj.material[0]?.color : obj.material?.color;
  const entry = {
    type:      obj.userData.primType || 'box',
    modelPath: obj.userData.modelPath || null,
    pos:       [+obj.position.x.toFixed(4), +obj.position.y.toFixed(4), +obj.position.z.toFixed(4)],
    rot:       [+(obj.rotation.x*DEG).toFixed(2), +(obj.rotation.y*DEG).toFixed(2), +(obj.rotation.z*DEG).toFixed(2)],
    size:      [+obj.scale.x.toFixed(4), +obj.scale.y.toFixed(4), +obj.scale.z.toFixed(4)],
    color:     matColor ? '#' + matColor.getHexString() : '#aaaacc',
  };
  if (obj.userData.primType === 'csg-result' && obj.userData.csgRecipe) {
    entry.csgRecipe = obj.userData.csgRecipe;
  }
  if (obj.userData.primType === 'merged-model') {
    entry.mergedMeshes = _serializeMergedMeshes(obj);
  }
  return entry;
}

// Rebuild a CSG result from a saved recipe (used in loadLevel)
async function spawnCsgResult(entry, gltfLoader, fbxLoader) {
  const evaluator = new Evaluator();

  const recipe = entry.csgRecipe;

  // Build the base mesh
  const baseObj = await _buildEntryObj(recipe.base, gltfLoader, fbxLoader);
  if (!baseObj) return null;

  let brushA = _meshToBrush(baseObj);
  if (!brushA) return null;

  // Apply each cutter in sequence
  for (const cutEntry of (recipe.cutters || [])) {
    const cutObj = await _buildEntryObj(cutEntry, gltfLoader, fbxLoader);
    if (!cutObj) continue;
    const brushB = _meshToBrush(cutObj);
    if (!brushB) continue;
    brushA.updateMatrixWorld(true);
    brushB.updateMatrixWorld(true);
    try {
      brushA = evaluator.evaluate(brushA, brushB, SUBTRACTION);
      brushA.updateMatrixWorld(true);
    } catch (err) {
      console.warn('CSG evaluate failed for cutter, skipping:', err);
    }
  }

  const result = brushA;
  // Center geometry at bounding box midpoint so gizmo/orbit land on the object.
  result.geometry.computeBoundingBox();
  const _csgCenter = new THREE.Vector3();
  result.geometry.boundingBox.getCenter(_csgCenter);
  result.geometry.translate(-_csgCenter.x, -_csgCenter.y, -_csgCenter.z);
  if (entry.pos && (entry.pos[0] !== 0 || entry.pos[1] !== 0 || entry.pos[2] !== 0)) {
    result.position.set(entry.pos[0], entry.pos[1], entry.pos[2]);
  } else {
    result.position.copy(_csgCenter);
  }
  if (entry.rot && (entry.rot[0] !== 0 || entry.rot[1] !== 0 || entry.rot[2] !== 0)) {
    result.rotation.set(entry.rot[0]*RAD, entry.rot[1]*RAD, entry.rot[2]*RAD);
  } else {
    result.rotation.set(0, 0, 0);
  }
  result.scale.setScalar(1);
  result.castShadow = entry.castShadow !== false;
  result.receiveShadow = true;
  result.userData = {
    primType:   'csg-result',
    editorId:   entry.id,
    label:      entry.label || '',
    collidable: entry.collidable !== false,
    csgRecipe:  recipe,
  };
  result.name = entry.label || ('CSG_' + entry.id);
  if (entry.states?.length)  { result.userData.states = entry.states; result.userData.currentState = 0; }
  if (entry.links?.length)     result.userData.links  = _normalizeLinks(entry.links);
  if (entry.noSelfInteract)    result.userData.noSelfInteract = true;
  if (entry.scripts?.length)   result.userData.scripts = [...entry.scripts];
  if (entry.emissiveIntensity > 0 && result.material) {
    result.userData.emissiveIntensity = entry.emissiveIntensity;
    result.userData.emissiveColor     = entry.emissiveColor ?? '#ffffff';
    const col = new THREE.Color(entry.emissiveColor ?? '#ffffff');
    const mats = Array.isArray(result.material) ? result.material : [result.material];
    mats.forEach(m => { if (m && 'emissive' in m) { m.emissive.copy(col); m.emissiveIntensity = entry.emissiveIntensity; } });
  }
  // Apply saved color to all material slots (CSG result can have array material)
  const _savedColor = entry.color ?? entry.csgRecipe?.base?.color;
  if (_savedColor) {
    result.userData._baseColor = _savedColor;
    const col = new THREE.Color(_savedColor);
    const mats = Array.isArray(result.material) ? result.material : [result.material];
    mats.forEach(m => { if (m?.color) m.color.set(col); });
  }
  if (entry.roughness !== undefined || entry.metalness !== undefined) {
    const mats = Array.isArray(result.material) ? result.material : [result.material];
    mats.forEach(m => {
      if (entry.roughness !== undefined && 'roughness' in m) m.roughness = entry.roughness;
      if (entry.metalness !== undefined && 'metalness' in m) m.metalness = entry.metalness;
    });
  }
  // Restore texture if saved
  if (entry.faceTextures) {
    result.userData.faceTextures = entry.faceTextures;
    applyFaceTextures(result);
  }
  E.placedGroup.add(result);
  return result;
}

// Build a temporary mesh from a recipe entry (for CSG source geometry)
async function _buildEntryObj(e, gltfLoader, fbxLoader) {
  if (e.type === 'csg-result' && e.csgRecipe) {
    const mesh = await spawnCsgResult({ ...e, id: e.id ?? -1 }, gltfLoader, fbxLoader);
    if (mesh) E.placedGroup.remove(mesh);
    return mesh;
  }
  if (e.type === 'merged-model' && e.mergedMeshes?.length) {
    const root = spawnMergedModel({ ...e, id: e.id ?? -1 });
    if (root) { E.placedGroup.remove(root); root.updateMatrixWorld(true); }
    return root;
  }
  if (e.type === 'model' && e.modelPath) {
    return new Promise(resolve => {
      const ext = e.modelPath.split('.').pop().toLowerCase();
      const loader = ext === 'fbx' ? fbxLoader : gltfLoader;
      loader.load(ASSET_ROOT + e.modelPath, result => {
        const root = result.scene || result;
        root.position.set(...e.pos);
        root.rotation.set(e.rot[0]*RAD, e.rot[1]*RAD, e.rot[2]*RAD);
        root.scale.set(...e.size);
        root.updateMatrixWorld(true);
        resolve(root);
      }, undefined, () => resolve(null));
    });
  }
  const mesh = makePrimMesh(e.type, e.color);
  if (!mesh) return null;
  applyEntryTransform(mesh, e);
  mesh.updateMatrixWorld(true);
  return mesh;
}

// â”€â”€â”€ Undo / Redo â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function pushUndo() {
  E.undoStack.push(JSON.stringify(levelToJSON({ includeEditorUi: true })));
  if (E.undoStack.length > 20) E.undoStack.shift();
  E.redoStack = [];
}

async function undo() {
  if (E.isRestoringSnapshot || !E.undoStack.length) return;
  E.redoStack.push(JSON.stringify(levelToJSON({ includeEditorUi: true })));
  await restoreSnapshot(E.undoStack.pop());
  setStatus('Undo');
}

async function redo() {
  if (E.isRestoringSnapshot || !E.redoStack.length) return;
  E.undoStack.push(JSON.stringify(levelToJSON({ includeEditorUi: true })));
  await restoreSnapshot(E.redoStack.pop());
  setStatus('Redo');
}

async function restoreSnapshot(json) {
  E.isRestoringSnapshot = true;
  const data = JSON.parse(json);
  try {
    closeModelEditor();
    clearPlaced();
    E.nextId = data.nextId || 1;
    if (data.editorUi?.groupCollapsed) {
      E.groupCollapsed = { ...data.editorUi.groupCollapsed };
    }
    if (data.editorUi?.stateExpanded) {
      E._stateExpanded = new Set(data.editorUi.stateExpanded);
    }
    if (data.groups) {
      for (const [gid, g] of Object.entries(data.groups)) {
        E.groups[gid] = { name: g.name, ids: new Set(g.ids) };
      }
    }
    E.levelVars = data.vars ? { ...data.vars } : {};
    E.sceneScripts = Array.isArray(data.sceneScripts) ? [...data.sceneScripts] : [];
    E.fogDensity = (data.fogDensity != null) ? data.fogDensity : null;
    E.isZombiesMap = data.isZombiesMap ?? false;
    E.zombiesMapDisplayName = data.zombiesMapDisplayName ?? null;
    E.zombiesConfig = data.zombiesConfig ?? null;
    _updateFogInput();
    const sceneScriptsEl = document.getElementById('scene-scripts');
    if (sceneScriptsEl && document.activeElement !== sceneScriptsEl) {
      sceneScriptsEl.value = _scriptListToText(E.sceneScripts);
    }
    renderVarsPanel();
    const gltfLoader = new GLTFLoader(), fbxLoader = new FBXLoader();
    for (const entry of (data.objects || [])) {
      if (entry.type === 'csg-result')          await spawnCsgResult(entry, gltfLoader, fbxLoader).catch(err => console.warn('CSG spawn failed:', err));
      else if (entry.type === 'model')           await loadModelIntoPlaced(entry, gltfLoader, fbxLoader);
      else if (entry.type === 'merged-model')    spawnMergedModel(entry);
      else if (entry.type === 'image-model')     await spawnImageModel(entry);
      else spawnPrimFromEntry(entry);
    }
    const selectedId = data.editorUi?.selectedId ?? null;
    if (selectedId != null) {
      const selectedObj = E.placedGroup.children.find(o => o.userData.editorId === selectedId);
      if (selectedObj) {
        selectObj(selectedObj);
        if (data.editorUi?.selectedFace != null) {
          E.selectedFace = data.editorUi.selectedFace;
          updateFaceHighlight(E.selected, E.selectedFace);
          refreshTexPanel(E.selected);
        }
      }
    }
    updateSceneList(); updateGroupsPanel(); markDirty();
  } finally {
    E.isRestoringSnapshot = false;
  }
}

// â”€â”€â”€ Dirty / display helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function markDirty() {
  E.isDirty = true;
  refreshLevelNameDisplay();
}

function refreshLevelNameDisplay() {
  const el = document.getElementById('level-name-display');
  if (!el) return;
  el.textContent = E.levelName || '-';
  el.classList.toggle('dirty', E.isDirty);
}

function setStatus(msg) {
  const el = document.getElementById('status');
  if (el) el.textContent = msg;
}

function updatePlacingHint(show) {
  const el = document.getElementById('placing-hint');
  if (el) el.style.display = show ? 'block' : 'none';
}

function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function _scriptListToText(list) {
  return (list || []).join('\n');
}

function _textToScriptList(text) {
  return String(text || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(Boolean);
}

// â”€â”€â”€ Model list â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
async function refreshModelList() {
  if (!window.electron) return;
  try { E.importedModels = await window.electron.listModels(); } catch { E.importedModels = []; }
  renderModelList();
  try { E.importedImages = await window.electron.listImageModels(); } catch { E.importedImages = []; }
  renderImageModelList();
  await refreshTextureList();
  await refreshSoundList();
}

async function refreshActorList() {
  if (!window.electron?.listActors) return;
  try { E.importedActors = await window.electron.listActors(); } catch { E.importedActors = []; }
  renderActorList();
}

function renderActorList() {
  const empty = document.getElementById('actor-empty');
  const list  = document.getElementById('actor-list');
  if (!list) return;
  list.querySelectorAll('.actor-item').forEach(el => el.remove());
  if (!E.importedActors.length) { if (empty) empty.style.display = ''; return; }
  if (empty) empty.style.display = 'none';
  E.importedActors.forEach(a => {
    const div = document.createElement('div');
    div.className = 'actor-item model-item';
    div.textContent = a.name;
    div.title = a.path;
    div.addEventListener('click', () => {
      if (!E.levelName) { setStatus('Open or create a level first'); return; }
      document.querySelectorAll('.prim-btn, .model-item, .actor-item').forEach(b => b.classList.remove('active'));
      div.classList.add('active');
      beginPlace('actor:' + a.path);
    });
    list.appendChild(div);
  });
}

async function refreshTextureList() {
  if (!window.electron?.listTextures) return;
  try { E.availableTextures = await window.electron.listTextures(); } catch { E.availableTextures = []; }
  const dl = document.getElementById('tex-datalist');
  if (!dl) return;
  dl.innerHTML = '';
  E.availableTextures.forEach(name => {
    const opt = document.createElement('option');
    opt.value = name;
    dl.appendChild(opt);
  });
}

async function refreshSoundList() {
  if (!window.electron?.listSounds) return;
  let sounds = [];
  try { sounds = await window.electron.listSounds(); } catch { sounds = []; }
  const dl = document.getElementById('sound-datalist');
  if (!dl) return;
  dl.innerHTML = '';
  sounds.forEach(name => {
    const opt = document.createElement('option');
    opt.value = name;
    dl.appendChild(opt);
  });
}

function renderModelList() {
  const empty   = document.getElementById('palette-empty');
  const palette = document.getElementById('palette-list');
  if (!palette) return;
  palette.querySelectorAll('.model-item').forEach(el => el.remove());
  if (!E.importedModels.length) { if (empty) empty.style.display = ''; return; }
  if (empty) empty.style.display = 'none';
  E.importedModels.forEach(m => {
    const div = document.createElement('div');
    div.className = 'model-item';
    div.textContent = m.name;
    div.title = m.path;
    div.addEventListener('click', () => {
      if (!E.levelName) { setStatus('Open or create a level first'); return; }
      document.querySelectorAll('.prim-btn, .model-item').forEach(b => b.classList.remove('active'));
      div.classList.add('active');
      beginPlace('model:' + m.path);
    });
    palette.appendChild(div);
  });
}

function renderImageModelList() {
  const empty = document.getElementById('image-model-empty');
  const list  = document.getElementById('image-model-list');
  if (!list) return;
  list.querySelectorAll('.image-model-item').forEach(el => el.remove());
  if (!(E.importedImages || []).length) { if (empty) empty.style.display = ''; return; }
  if (empty) empty.style.display = 'none';
  (E.importedImages || []).forEach(img => {
    const div = document.createElement('div');
    div.className = 'image-model-item model-item';
    div.textContent = img.name;
    div.title = img.path;
    div.addEventListener('click', () => {
      if (!E.levelName) { setStatus('Open or create a level first'); return; }
      document.querySelectorAll('.prim-btn, .model-item, .image-model-item').forEach(b => b.classList.remove('active'));
      div.classList.add('active');
      beginPlace('image-model:' + img.path);
    });
    list.appendChild(div);
  });
}

// â”€â”€â”€ Level modal â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
async function openLevelModal() {
  const modal   = document.getElementById('level-modal');
  const listDiv = document.getElementById('level-modal-list');
  if (!modal || !listDiv) return;
  listDiv.innerHTML = '';

  // "main" - always listed first (hard-coded scene base)
  const mainItem = document.createElement('div');
  mainItem.className = 'level-list-item';
  mainItem.dataset.level = 'main';
  mainItem.textContent = 'main';
  mainItem.addEventListener('click', () => {
    listDiv.querySelectorAll('.level-list-item').forEach(el => el.classList.remove('selected'));
    mainItem.classList.add('selected');
    document.getElementById('modal-new-name').value = '';
  });
  listDiv.appendChild(mainItem);

  if (window.electron) {
    try {
      const levels = await window.electron.listLevels();
      levels.filter(n => n !== 'main').forEach(name => {
        const item = document.createElement('div');
        item.className = 'level-list-item';
        item.dataset.level = name;
        item.textContent = name;
        item.addEventListener('click', () => {
          listDiv.querySelectorAll('.level-list-item').forEach(el => el.classList.remove('selected'));
          item.classList.add('selected');
          document.getElementById('modal-new-name').value = name;
        });
        listDiv.appendChild(item);
      });
    } catch { /* ok */ }
  }

  modal.classList.add('open');
}

function closeLevelModal() {
  document.getElementById('level-modal')?.classList.remove('open');
}

// ─── States panel helpers ─────────────────────────────────────────────────────

function captureStateFromObj(obj) {
  const isLight  = isLightType(obj.userData.primType);
  const isSpot   = obj.userData.primType === 'spot-light';
  const stateIdx = obj.userData.states?.length ?? 0;
  const state = {
    name:     'State ' + stateIdx,
    pos:      [+obj.position.x.toFixed(4), +obj.position.y.toFixed(4), +obj.position.z.toFixed(4)],
    rot:      [+(obj.rotation.x * DEG).toFixed(2), +(obj.rotation.y * DEG).toFixed(2), +(obj.rotation.z * DEG).toFixed(2)],
    scale:    [+obj.scale.x.toFixed(4), +obj.scale.y.toFixed(4), +obj.scale.z.toFixed(4)],
    duration: stateIdx === 0 ? 0 : 0.4,
  };
  if (isLight) {
    state.intensity  = obj.userData.intensity  ?? 1;
    state.lightColor = obj.userData.lightColor || '#ffffff';
    state.distance   = obj.userData.distance   ?? (isSpot ? 20 : 10);
    state.decay      = obj.userData.decay      ?? 2;
    if (isSpot) {
      state.angle    = obj.userData.angle    ?? 30;
      state.penumbra = obj.userData.penumbra ?? 0.15;
    }
  }
  return state;
}

function applyStateToEditorObj(obj, state) {
  const posOn      = state.posEnabled   !== false;
  const rotOn      = state.rotEnabled   !== false;
  const scaleOn    = state.scaleEnabled !== false;
  const intOn      = state.intensityEnabled !== false;
  const colOn      = state.lightColorEnabled !== false;
  const distOn     = state.distanceEnabled   !== false;
  const decayOn    = state.decayEnabled      !== false;
  const angleOn    = state.angleEnabled      !== false;
  const penumbraOn = state.penumbraEnabled   !== false;

  if (posOn && state.pos) {
    if (state.posRelative) {
      const rest = obj.userData._restPos ?? obj.position;
      obj.position.set(rest.x + state.pos[0], rest.y + state.pos[1], rest.z + state.pos[2]);
    } else {
      obj.position.set(...state.pos);
    }
  }
  if (rotOn && state.rot) {
    const pivot = (!posOn && obj.userData.pivotOffset)
      ? new THREE.Vector3().fromArray(obj.userData.pivotOffset).applyMatrix4(obj.matrixWorld)
      : null;
    if (state.rotRelative) {
      obj.rotation.x += state.rot[0] * RAD;
      obj.rotation.y += state.rot[1] * RAD;
      obj.rotation.z += state.rot[2] * RAD;
    } else {
      obj.rotation.set(state.rot[0] * RAD, state.rot[1] * RAD, state.rot[2] * RAD);
    }
    if (pivot) {
      obj.updateMatrixWorld(true);
      const newPivotWorld = new THREE.Vector3().fromArray(obj.userData.pivotOffset).applyMatrix4(obj.matrixWorld);
      obj.position.add(pivot.sub(newPivotWorld));
    }
  }
  if (scaleOn && state.scale) {
    const mode = state.scaleMode || 'abs';
    if (mode === 'mul') {
      obj.scale.x *= state.scale[0]; obj.scale.y *= state.scale[1]; obj.scale.z *= state.scale[2];
    } else if (mode === 'add') {
      obj.scale.x += state.scale[0]; obj.scale.y += state.scale[1]; obj.scale.z += state.scale[2];
    } else {
      obj.scale.set(...state.scale);
    }
  }
  if (isLightType(obj.userData.primType)) {
    if (intOn && state.intensity != null) {
      const val = state.intensityRelative ? ((obj.userData.intensity ?? 1) + state.intensity) : state.intensity;
      obj.userData.intensity = val;
      obj.traverse(c => { if (c.isLight) c.intensity = val; });
    }
    if (colOn && state.lightColor != null) {
      obj.userData.lightColor = state.lightColor;
      obj.traverse(c => { if (c.isLight) c.color.set(state.lightColor); });
    }
    if (distOn && state.distance != null) {
      obj.userData.distance = state.distance;
      obj.traverse(c => { if (c.isLight && 'distance' in c) c.distance = state.distance; });
    }
    if (decayOn && state.decay != null) {
      obj.userData.decay = state.decay;
      obj.traverse(c => { if (c.isLight && 'decay' in c) c.decay = state.decay; });
    }
    if (angleOn && state.angle != null && obj.userData.primType === 'spot-light') {
      obj.userData.angle = state.angle;
      obj.traverse(c => { if (c.isSpotLight) c.angle = THREE.MathUtils.degToRad(state.angle); });
    }
    if (penumbraOn && state.penumbra != null && obj.userData.primType === 'spot-light') {
      obj.userData.penumbra = state.penumbra;
      obj.traverse(c => { if (c.isSpotLight) c.penumbra = state.penumbra; });
    }
  }
  if (state.collidableEnabled && state.collidable != null) {
    obj.userData.collidable = state.collidable;
  }
  if (state.castShadowEnabled && state.castShadow != null) {
    const v = !!state.castShadow;
    obj.userData.castShadow = v;
    obj.castShadow = v;
    obj.traverse(c => {
      if (c.isMesh)  c.castShadow = v;
      if (c.isLight) c.castShadow = v;
    });
  }
  if (state.emissiveEnabled) {
    if (state.emissiveIntensity != null) {
      obj.userData.emissiveIntensity = state.emissiveIntensity;
      obj.traverse(c => {
        if (c.isMesh && c.material) {
          const mats = Array.isArray(c.material) ? c.material : [c.material];
          mats.forEach(m => { if ('emissiveIntensity' in m) m.emissiveIntensity = state.emissiveIntensity; });
        }
      });
    }
    if (state.emissiveColor != null) {
      obj.userData.emissiveColor = state.emissiveColor;
      obj.traverse(c => {
        if (c.isMesh && c.material) {
          const mats = Array.isArray(c.material) ? c.material : [c.material];
          mats.forEach(m => { if ('emissive' in m) m.emissive.set(state.emissiveColor); });
        }
      });
    }
  }
  if (state.opacityEnabled && state.opacity != null) {
    const v = Math.max(0, Math.min(1, state.opacity));
    obj.traverse(c => {
      if (c.isMesh && c.material) {
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { m.transparent = v < 1; m.opacity = v; m.needsUpdate = true; });
      }
    });
  }
  if (state.meshColorEnabled && state.meshColor != null) {
    obj.traverse(c => {
      if (c.isMesh && c.material) {
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { if (m.color) { m.color.set(state.meshColor); m.needsUpdate = true; } });
      }
    });
  }
  if (state.textureEnabled && state.textures) {
    if (!obj.userData.faceTextures) obj.userData.faceTextures = {};
    for (const [k, v] of Object.entries(state.textures)) {
      if (!v?.name) delete obj.userData.faceTextures[k];
      else obj.userData.faceTextures[k] = v;
    }
    if (obj.isMesh) applyFaceTextures(obj);
    else obj.traverse(c => { if (c.isMesh && !c.userData.isFaceOverlay) applyFaceTextures(c); });
  }
  obj.updateMatrixWorld(true);
  updateProps(obj);
  markDirty();
}

function renderStatesPanel(obj) {
  const section = document.getElementById('states-section');
  const list    = document.getElementById('states-list');
  if (!section || !list) return;
  section.style.display = obj ? '' : 'none';
  if (!obj) return;

  // Wire the Link-only checkbox
  const chkNoSelf = document.getElementById('chk-no-self-interact');
  if (chkNoSelf) {
    chkNoSelf.checked = !!obj.userData.noSelfInteract;
    chkNoSelf.onchange = e => {
      pushUndo();
      if (e.target.checked) obj.userData.noSelfInteract = true;
      else delete obj.userData.noSelfInteract;
      markDirty();
    };
  }

  list.innerHTML = '';
  const states   = obj.userData.states || [];
  const isLight    = isLightType(obj.userData.primType);
  const isTrigger  = isTriggerType(obj.userData.primType);
  const isSpot     = obj.userData.primType === 'spot-light';
  const isDirLight = obj.userData.primType === 'dir-light';

  states.forEach((state, idx) => {
    const item = document.createElement('div');
    item.className = 'state-item';

    const posEnabled      = state.posEnabled        !== false;
    const rotEnabled      = state.rotEnabled        !== false;
    const scaleEnabled    = state.scaleEnabled      !== false;
    const intEnabled      = state.intensityEnabled  !== false;
    const colEnabled      = state.lightColorEnabled !== false;
    const distEnabled     = state.distanceEnabled   !== false;
    const decayEnabled    = state.decayEnabled      !== false;
    const angleEnabled    = state.angleEnabled      !== false;
    const penumbraEnabled = state.penumbraEnabled   !== false;
    const collidableEnabled  = !!state.collidableEnabled;
    const castShadowEnabled  = !!state.castShadowEnabled;
    const interactiveEnabled = !!state.interactiveEnabled;
    const emissiveEnabled    = !!state.emissiveEnabled;
    const opacityEnabled     = !!state.opacityEnabled;
    const meshColorEnabled   = !!state.meshColorEnabled;
    const textureEnabled     = !!state.textureEnabled;
    const conditionEnabled   = !!state.conditionEnabled;

    const posRel    = !!state.posRelative;
    const rotRel    = !!state.rotRelative;
    const scaleMode = state.scaleMode || 'abs';
    const intRel    = !!state.intensityRelative;
    const pos = state.pos   || [0,0,0];
    const rot = state.rot   || [0,0,0];
    const sc  = state.scale || [1,1,1];

    item.innerHTML = `
      <div class="state-item-header">
        <span data-si="drag-handle" style="cursor:grab;color:#444466;font-size:12px;padding:0 4px 0 0;user-select:none;flex-shrink:0" title="Drag to reorder">&#8942;</span>
        <span style="font-size:10px;color:#5555aa;min-width:16px">${idx}</span>
        <input class="prop-input" data-si="name" value="${escHtml(state.name || ('State '+idx))}" style="flex:1">
        <input class="prop-input" data-si="dur" type="number" step="0.1" min="0" value="${state.duration ?? 0}" style="width:34px" title="Transition duration (s)">s
        <button class="btn" data-si="goto" style="font-size:10px;padding:2px 6px" title="Apply state to object">Go</button>
        <button class="btn btn-del" data-si="del" style="font-size:10px;padding:2px 6px">&times;</button>
      </div>
      <div class="state-item-row">
        <label>Label</label>
        <input class="prop-input" data-si="label" type="text" value="${escHtml(state.interactLabel || '')}" placeholder="[RIGHT CLICK] Interact" style="flex:1">
      </div>
      <div class="state-field-row${posEnabled ? '' : ' sf-disabled'}" data-field="pos">
        <div class="state-field-head">
          <label><input type="checkbox" data-si="posEn" ${posEnabled ? 'checked' : ''}> Pos</label>
          <span class="state-rel-lbl"><input type="checkbox" data-si="posRel" ${posRel ? 'checked' : ''}> +&Delta; offset</span>
        </div>
        <div class="state-field-xyz">
          <span class="xyz-lbl">x</span><input class="prop-input" data-si="pv0" type="number" step="0.01" value="${pos[0]}">
          <span class="xyz-lbl">y</span><input class="prop-input" data-si="pv1" type="number" step="0.01" value="${pos[1]}">
          <span class="xyz-lbl">z</span><input class="prop-input" data-si="pv2" type="number" step="0.01" value="${pos[2]}">
        </div>
      </div>
      <div class="state-field-row${rotEnabled ? '' : ' sf-disabled'}" data-field="rot">
        <div class="state-field-head">
          <label><input type="checkbox" data-si="rotEn" ${rotEnabled ? 'checked' : ''}> Rot (deg)</label>
          <span class="state-rel-lbl"><input type="checkbox" data-si="rotRel" ${rotRel ? 'checked' : ''}> +&Delta; deg</span>
        </div>
        <div class="state-field-xyz">
          <span class="xyz-lbl">x</span><input class="prop-input" data-si="rv0" type="number" step="0.1" value="${rot[0]}">
          <span class="xyz-lbl">y</span><input class="prop-input" data-si="rv1" type="number" step="0.1" value="${rot[1]}">
          <span class="xyz-lbl">z</span><input class="prop-input" data-si="rv2" type="number" step="0.1" value="${rot[2]}">
        </div>
      </div>
      <div class="state-field-row${scaleEnabled ? '' : ' sf-disabled'}" data-field="scale">
        <div class="state-field-head">
          <label><input type="checkbox" data-si="scaleEn" ${scaleEnabled ? 'checked' : ''}> Scale</label>
          <select class="prop-input" data-si="scaleMode" style="width:64px;padding:2px 3px;font-size:10px">
            <option value="abs" ${scaleMode==='abs'?'selected':''}>abs</option>
            <option value="mul" ${scaleMode==='mul'?'selected':''}>&#215; mult</option>
            <option value="add" ${scaleMode==='add'?'selected':''}>+ add</option>
          </select>
        </div>
        <div class="state-field-xyz">
          <span class="xyz-lbl">x</span><input class="prop-input" data-si="sv0" type="number" step="0.001" value="${sc[0]}">
          <span class="xyz-lbl">y</span><input class="prop-input" data-si="sv1" type="number" step="0.001" value="${sc[1]}">
          <span class="xyz-lbl">z</span><input class="prop-input" data-si="sv2" type="number" step="0.001" value="${sc[2]}">
        </div>
      </div>
      ${isLight ? `
      <div class="state-field-row${intEnabled ? '' : ' sf-disabled'}" data-field="intensity">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="intensityEn" ${intEnabled ? 'checked' : ''}> Intensity</label>
          <span class="state-rel-lbl" style="flex:1;justify-content:flex-end;gap:3px">
            <input class="prop-input" data-si="intVal" type="number" step="0.1" min="0" value="${state.intensity ?? 1}" style="width:46px">
            <label style="color:#666688"><input type="checkbox" data-si="intensityRel" ${intRel ? 'checked' : ''}> +&Delta;</label>
          </span>
        </div>
      </div>
      <div class="state-field-row${colEnabled ? '' : ' sf-disabled'}" data-field="lightColor">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="lightColorEn" ${colEnabled ? 'checked' : ''}> Color</label>
          <input class="prop-input" data-si="colVal" type="color" value="${state.lightColor || '#ffffff'}" style="width:44px;height:22px;padding:1px 2px">
        </div>
      </div>
      ${!isDirLight ? `
      <div class="state-field-row${distEnabled ? '' : ' sf-disabled'}" data-field="distance">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="distEn" ${distEnabled ? 'checked' : ''}> Distance</label>
          <input class="prop-input" data-si="distVal" type="number" step="0.5" min="0" value="${state.distance ?? 10}" style="width:50px">
        </div>
      </div>
      <div class="state-field-row${decayEnabled ? '' : ' sf-disabled'}" data-field="decay">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="decayEn" ${decayEnabled ? 'checked' : ''}> Decay</label>
          <input class="prop-input" data-si="decayVal" type="number" step="0.1" min="0" value="${state.decay ?? 2}" style="width:50px">
        </div>
      </div>` : ''}
      ${isSpot ? `
      <div class="state-field-row${angleEnabled ? '' : ' sf-disabled'}" data-field="angle">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="angleEn" ${angleEnabled ? 'checked' : ''}> Angle&deg;</label>
          <input class="prop-input" data-si="angleVal" type="number" step="1" min="1" max="89" value="${state.angle ?? 30}" style="width:50px">
        </div>
      </div>
      <div class="state-field-row${penumbraEnabled ? '' : ' sf-disabled'}" data-field="penumbra">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="penumbraEn" ${penumbraEnabled ? 'checked' : ''}> Penumbra</label>
          <input class="prop-input" data-si="penumbraVal" type="number" step="0.01" min="0" max="1" value="${state.penumbra ?? 0.15}" style="width:50px">
        </div>
      </div>` : ''}
      ` : ''}
      <div class="state-field-row${collidableEnabled ? '' : ' sf-disabled'}" data-field="collidable">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="collidableEn" ${collidableEnabled ? 'checked' : ''}> Collidable</label>
          <label style="color:#888"><input type="checkbox" data-si="collidableVal" ${state.collidable ? 'checked' : ''}> on</label>
        </div>
      </div>
      <div class="state-field-row${castShadowEnabled ? '' : ' sf-disabled'}" data-field="castShadow">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="castShadowEn" ${castShadowEnabled ? 'checked' : ''}> CastShadow</label>
          <label style="color:#888"><input type="checkbox" data-si="castShadowVal" ${(state.castShadow !== false && state.castShadow !== undefined) ? 'checked' : ''}> on</label>
        </div>
      </div>
      <div class="state-field-row${interactiveEnabled ? '' : ' sf-disabled'}" data-field="interactive">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="interactiveEn" ${interactiveEnabled ? 'checked' : ''}> Interactive</label>
          <label style="color:#888"><input type="checkbox" data-si="interactiveVal" ${(state.interactive !== false && state.interactive !== undefined) ? 'checked' : ''}> on</label>
        </div>
      </div>
      ${!isLight && !isTrigger ? `
      <div class="state-field-row${opacityEnabled ? '' : ' sf-disabled'}" data-field="opacity">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="opacityEn" ${opacityEnabled ? 'checked' : ''}> Opacity</label>
          <input class="prop-input" data-si="opacityVal" type="number" step="0.01" min="0" max="1" value="${state.opacity ?? 1}" style="width:50px">
        </div>
      </div>
      <div class="state-field-row${meshColorEnabled ? '' : ' sf-disabled'}" data-field="meshColor">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="meshColorEn" ${meshColorEnabled ? 'checked' : ''}> Color</label>
          <input class="prop-input" data-si="meshColorVal" type="color" value="${state.meshColor || '#ffffff'}" style="width:44px;height:22px;padding:1px 2px">
        </div>
      </div>
      <div class="state-field-row${emissiveEnabled ? '' : ' sf-disabled'}" data-field="emissive">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="emissiveEn" ${emissiveEnabled ? 'checked' : ''}> Emissive</label>
          <input class="prop-input" data-si="emissiveIntensityVal" type="number" step="0.1" min="0" value="${state.emissiveIntensity ?? 0}" style="width:50px" title="Emissive intensity (0 = off)">
          <input class="prop-input" data-si="emissiveColorVal" type="color" value="${state.emissiveColor ?? '#ffffff'}" style="width:36px;padding:1px 2px" title="Emissive color">
        </div>
      </div>
      <div class="state-field-row${textureEnabled ? '' : ' sf-disabled'}" data-field="texture">
        <div class="state-field-head" style="gap:4px">
          <label><input type="checkbox" data-si="texStateEn" ${textureEnabled ? 'checked' : ''}> Textures</label>
          <button data-si="texStateAdd" style="font-size:10px;padding:1px 6px;margin-left:auto">+ Add</button>
        </div>
        <div data-si="texStateList" style="margin-top:3px"></div>
      </div>` : ''}
      <div class="state-field-row${conditionEnabled ? '' : ' sf-disabled'}" data-field="condition">
        <div class="state-field-head" style="gap:3px">
          <label><input type="checkbox" data-si="condEn" ${conditionEnabled ? 'checked' : ''}> If var</label>
          <button data-si="condAdd" style="font-size:10px;padding:1px 6px;margin-left:auto">+ Add</button>
        </div>
        <div data-si="condList" style="display:flex;flex-direction:column;gap:3px;margin-top:3px"></div>
      </div>
      <div class="state-item-row">
        <label style="white-space:nowrap">Active var</label>
        <input class="prop-input" data-si="activeVar" type="text" value="${escHtml(state.activeVar || '')}" placeholder="lv_... (set true when active)" style="flex:1">
      </div>
      <div class="state-item-row">
        <button class="btn" data-si="soundsBtn" style="font-size:11px;padding:3px 10px;width:100%">&#127925; Sounds...</button>
      </div>
    `;

    {
      const stateKey  = `${obj.userData.editorId || 'noeid'}_${idx}`;
      const isCollapsed = !E._stateExpanded.has(stateKey);
      const hdr  = item.querySelector('.state-item-header');
      const body = document.createElement('div');
      body.className = 'state-body';
      if (isCollapsed) body.classList.add('state-body-hidden');
      while (hdr.nextSibling) body.appendChild(hdr.nextSibling);
      item.appendChild(body);
      const colBtn = document.createElement('button');
      colBtn.className = 'state-collapse-btn';
      colBtn.textContent = isCollapsed ? '\u25b6' : '\u25bc';
      hdr.insertBefore(colBtn, hdr.firstChild);
      colBtn.addEventListener('click', e => {
        e.stopPropagation();
        const nowCollapsed = !body.classList.contains('state-body-hidden');
        body.classList.toggle('state-body-hidden', nowCollapsed);
        colBtn.textContent = nowCollapsed ? '\u25b6' : '\u25bc';
        if (nowCollapsed) E._stateExpanded.delete(stateKey); else E._stateExpanded.add(stateKey);
      });
    }

    const g  = sel => item.querySelector(`[data-si="${sel}"]`);
    const st = obj.userData.states[idx];

    g('name').addEventListener('input',  e => { st.name = e.target.value; markDirty(); });
    g('dur').addEventListener('change',  e => { st.duration = parseFloat(e.target.value) || 0; markDirty(); });
    g('label').addEventListener('input', e => {
      const v = e.target.value.trim();
      if (v) st.interactLabel = v; else delete st.interactLabel;
      markDirty();
    });

    // Pos
    g('posEn').addEventListener('change', e => {
      st.posEnabled = e.target.checked;
      item.querySelector('[data-field="pos"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });
    g('posRel').addEventListener('change', e => {
      st.posRelative = e.target.checked;
      if (e.target.checked) { st.pos = [0,0,0]; g('pv0').value=0; g('pv1').value=0; g('pv2').value=0; }
      markDirty();
    });
    [0,1,2].forEach(i => g(`pv${i}`).addEventListener('change', e => { if (!st.pos) st.pos=[0,0,0]; st.pos[i] = parseFloat(e.target.value)||0; markDirty(); }));

    // Rot
    g('rotEn').addEventListener('change', e => {
      st.rotEnabled = e.target.checked;
      item.querySelector('[data-field="rot"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });
    g('rotRel').addEventListener('change', e => {
      st.rotRelative = e.target.checked;
      if (e.target.checked) { st.rot = [0,0,0]; g('rv0').value=0; g('rv1').value=0; g('rv2').value=0; }
      markDirty();
    });
    [0,1,2].forEach(i => g(`rv${i}`).addEventListener('change', e => { if (!st.rot) st.rot=[0,0,0]; st.rot[i] = parseFloat(e.target.value)||0; markDirty(); }));

    // Scale
    g('scaleEn').addEventListener('change', e => {
      st.scaleEnabled = e.target.checked;
      item.querySelector('[data-field="scale"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });
    g('scaleMode').addEventListener('change', e => {
      const prev = st.scaleMode || 'abs';
      st.scaleMode = e.target.value;
      if (prev === 'abs' && e.target.value === 'mul') { st.scale=[1,1,1]; g('sv0').value=1; g('sv1').value=1; g('sv2').value=1; }
      if (prev === 'abs' && e.target.value === 'add') { st.scale=[0,0,0]; g('sv0').value=0; g('sv1').value=0; g('sv2').value=0; }
      markDirty();
    });
    [0,1,2].forEach(i => g(`sv${i}`).addEventListener('change', e => { if (!st.scale) st.scale=[1,1,1]; st.scale[i] = parseFloat(e.target.value)||0; markDirty(); }));

    // Light-specific fields
    if (isLight) {
      g('intensityEn').addEventListener('change', e => {
        st.intensityEnabled = e.target.checked;
        item.querySelector('[data-field="intensity"]').classList.toggle('sf-disabled', !e.target.checked);
        markDirty();
      });
      g('intVal').addEventListener('change', e => { st.intensity = parseFloat(e.target.value) ?? 1; markDirty(); });
      g('intensityRel').addEventListener('change', e => {
        st.intensityRelative = e.target.checked;
        if (e.target.checked) { st.intensity = 0; g('intVal').value = 0; }
        markDirty();
      });
      g('lightColorEn').addEventListener('change', e => {
        st.lightColorEnabled = e.target.checked;
        item.querySelector('[data-field="lightColor"]').classList.toggle('sf-disabled', !e.target.checked);
        markDirty();
      });
      g('colVal').addEventListener('input', e => { st.lightColor = e.target.value; markDirty(); });

      if (!isDirLight) {
        g('distEn').addEventListener('change', e => {
          st.distanceEnabled = e.target.checked;
          item.querySelector('[data-field="distance"]').classList.toggle('sf-disabled', !e.target.checked);
          markDirty();
        });
        g('distVal').addEventListener('change', e => { st.distance = parseFloat(e.target.value) || 0; markDirty(); });
        g('decayEn').addEventListener('change', e => {
          st.decayEnabled = e.target.checked;
          item.querySelector('[data-field="decay"]').classList.toggle('sf-disabled', !e.target.checked);
          markDirty();
        });
        g('decayVal').addEventListener('change', e => { st.decay = parseFloat(e.target.value) || 0; markDirty(); });
      }

      if (isSpot) {
        g('angleEn').addEventListener('change', e => {
          st.angleEnabled = e.target.checked;
          item.querySelector('[data-field="angle"]').classList.toggle('sf-disabled', !e.target.checked);
          markDirty();
        });
        g('angleVal').addEventListener('change', e => { st.angle = parseFloat(e.target.value) || 30; markDirty(); });
        g('penumbraEn').addEventListener('change', e => {
          st.penumbraEnabled = e.target.checked;
          item.querySelector('[data-field="penumbra"]').classList.toggle('sf-disabled', !e.target.checked);
          markDirty();
        });
        g('penumbraVal').addEventListener('change', e => { st.penumbra = parseFloat(e.target.value) ?? 0.15; markDirty(); });
      }
    }

    // Collidable / CastShadow (all objects)
    g('collidableEn').addEventListener('change', e => {
      st.collidableEnabled = e.target.checked;
      item.querySelector('[data-field="collidable"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });
    g('collidableVal').addEventListener('change', e => { st.collidable = e.target.checked; markDirty(); });
    g('castShadowEn').addEventListener('change', e => {
      st.castShadowEnabled = e.target.checked;
      item.querySelector('[data-field="castShadow"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });
    g('castShadowVal').addEventListener('change', e => { st.castShadow = e.target.checked; markDirty(); });
    g('interactiveEn').addEventListener('change', e => {
      st.interactiveEnabled = e.target.checked;
      item.querySelector('[data-field="interactive"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });
    g('interactiveVal').addEventListener('change', e => { st.interactive = e.target.checked; markDirty(); });

    // Emissive / Opacity / Color (non-light, non-trigger only — elements conditionally rendered)
    g('emissiveEn')?.addEventListener('change', e => {
      st.emissiveEnabled = e.target.checked;
      item.querySelector('[data-field="emissive"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });
    g('emissiveIntensityVal')?.addEventListener('change', e => { st.emissiveIntensity = parseFloat(e.target.value) || 0; markDirty(); });
    g('emissiveColorVal')?.addEventListener('change', e => { st.emissiveColor = e.target.value; markDirty(); });
    g('opacityEn')?.addEventListener('change', e => {
      st.opacityEnabled = e.target.checked;
      item.querySelector('[data-field="opacity"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });
    g('opacityVal')?.addEventListener('change', e => { st.opacity = parseFloat(e.target.value) ?? 1; markDirty(); });
    g('meshColorEn')?.addEventListener('change', e => {
      st.meshColorEnabled = e.target.checked;
      item.querySelector('[data-field="meshColor"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });
    g('meshColorVal')?.addEventListener('change', e => { st.meshColor = e.target.value; markDirty(); });

    // Texture state overrides
    const _texKeyOptions = () => {
      const isBox = obj.userData.primType === 'box';
      let opts = `<option value="all">all</option>`;
      if (isBox) for (let i = 0; i < 6; i++) opts += `<option value="${i}">${i}</option>`;
      return opts;
    };
    const _renderTexStateList = () => {
      if (!st.textures) st.textures = {};
      const listEl = g('texStateList');
      if (!listEl) return;
      listEl.innerHTML = '';
      for (const [k, v] of Object.entries(st.textures)) {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;gap:2px;align-items:center;margin-bottom:2px';
        row.innerHTML = `
          <select class="prop-input" style="width:40px;font-size:10px;padding:2px 2px">${_texKeyOptions()}</select>
          <input class="prop-input" list="tex-datalist" value="${escHtml(v?.name ?? '')}" placeholder="texture" style="flex:1;font-size:10px" autocomplete="off">
          <button style="font-size:10px;padding:1px 5px;flex-shrink:0">&times;</button>
        `;
        const keySel = row.children[0];
        const nameIn = row.children[1];
        const delBtn = row.children[2];
        keySel.value = k;
        const _save = () => {
          const oldKey = k;
          const newKey = keySel.value;
          const name   = nameIn.value.trim();
          if (oldKey !== newKey) { delete st.textures[oldKey]; }
          st.textures[newKey] = name ? makeFaceTexConfig(name) : null;
          markDirty();
          _renderTexStateList();
        };
        keySel.addEventListener('change', _save);
        nameIn.addEventListener('change', _save);
        delBtn.addEventListener('click', () => { pushUndo(); delete st.textures[k]; markDirty(); _renderTexStateList(); });
        listEl.appendChild(row);
      }
    };
    g('texStateEn')?.addEventListener('change', e => {
      pushUndo();
      st.textureEnabled = e.target.checked;
      item.querySelector('[data-field="texture"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });
    g('texStateAdd')?.addEventListener('click', () => {
      pushUndo();
      if (!st.textures) st.textures = {};
      if (!st.textures['all']) st.textures['all'] = null;
      _renderTexStateList();
      markDirty();
    });
    _renderTexStateList();

    // Condition
    g('condEn').addEventListener('change', e => {
      pushUndo();
      st.conditionEnabled = e.target.checked;
      item.querySelector('[data-field="condition"]').classList.toggle('sf-disabled', !e.target.checked);
      markDirty();
    });

    const _condVarOptions = () => Object.keys(E.levelVars).map(k => `<option value="${escHtml(k)}">${escHtml(k)}</option>`).join('');
    const _condOpOptions  = () => `<option value="eq">=</option><option value="ne">&ne;</option><option value="lt">&lt;</option><option value="le">&le;</option><option value="gt">&gt;</option><option value="ge">&ge;</option>`;

    const _renderCondList = () => {
      if (!st.conditions?.length && st.condition) {
        st.conditions = [st.condition];
        delete st.condition;
      }
      if (!st.conditions) st.conditions = [];
      const list = g('condList');
      list.innerHTML = '';
      st.conditions.forEach((cond, ci) => {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;gap:3px;align-items:center;';
        row.innerHTML = `
          <select class="prop-input" style="flex:1;font-size:10px;padding:2px 2px">
            <option value="">(none)</option>${_condVarOptions()}
          </select>
          <select class="prop-input" style="width:44px;font-size:10px;padding:2px 2px">${_condOpOptions()}</select>
          <input class="prop-input" type="text" value="${escHtml(String(cond.value ?? ''))}" style="width:44px" placeholder="value">
          <button style="font-size:10px;padding:1px 5px;flex-shrink:0">&times;</button>
        `;
        const varSel = row.children[0];
        const opSel  = row.children[1];
        const valIn  = row.children[2];
        const delBtn = row.children[3];
        varSel.value = cond.var || '';
        opSel.value  = cond.op  || 'eq';
        varSel.addEventListener('change', e => { pushUndo(); cond.var = e.target.value; markDirty(); });
        opSel.addEventListener('change',  e => { pushUndo(); cond.op  = e.target.value; markDirty(); });
        valIn.addEventListener('change',  e => { pushUndo(); cond.value = e.target.value; markDirty(); });
        delBtn.addEventListener('click', () => {
          pushUndo();
          st.conditions.splice(ci, 1);
          _renderCondList();
          markDirty();
        });
        list.appendChild(row);
      });
    };

    g('condAdd').addEventListener('click', () => {
      pushUndo();
      if (!st.conditions) st.conditions = [];
      if (!st.conditionEnabled) {
        st.conditionEnabled = true;
        item.querySelector('[data-field="condition"]').classList.remove('sf-disabled');
        g('condEn').checked = true;
      }
      st.conditions.push({ var: '', op: 'eq', value: '' });
      _renderCondList();
      markDirty();
    });

    _renderCondList();

    g('activeVar').addEventListener('change', e => {
      pushUndo();
      const v = e.target.value.trim();
      if (v) st.activeVar = v; else delete st.activeVar;
      markDirty();
    });

    g('soundsBtn').addEventListener('click', () => openSoundListModal(obj, idx));

    g('goto').addEventListener('click', () => applyStateToEditorObj(obj, obj.userData.states[idx]));
    g('del').addEventListener('click', () => {
      pushUndo();
      obj.userData.states.splice(idx, 1);
      if (!obj.userData.states.length) delete obj.userData.states;
      renderStatesPanel(obj); markDirty();
    });

    // Inputs section — button trigger → var operation bindings
    const inputsSection = document.createElement('div');
    inputsSection.className = 'state-field-row';
    inputsSection.style.marginTop = '4px';
    const inputsHead = document.createElement('div');
    inputsHead.className = 'state-field-head';
    inputsHead.style.gap = '4px';
    const inputsLabel = document.createElement('label');
    inputsLabel.style.cssText = 'font-size:10px;font-weight:bold';
    inputsLabel.textContent = 'Inputs';
    const btnAddInput = document.createElement('button');
    btnAddInput.className = 'btn';
    btnAddInput.style.cssText = 'font-size:10px;padding:2px 6px;margin-left:auto';
    btnAddInput.textContent = '+ Add';
    inputsHead.appendChild(inputsLabel);
    inputsHead.appendChild(btnAddInput);
    inputsSection.appendChild(inputsHead);
    const inputsList = document.createElement('div');
    inputsSection.appendChild(inputsList);

    const renderInputRows = () => {
      inputsList.innerHTML = '';
      (st.buttons || []).forEach((b, bi) => {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;gap:3px;align-items:center;flex-wrap:wrap;margin-top:3px';

        const trigSel = document.createElement('select');
        trigSel.className = 'prop-input';
        trigSel.style.cssText = 'width:96px;font-size:10px;padding:2px';
        [['scrollup','↑ scroll up'],['scrolldown','↓ scroll down'],['rightclick','right-click'],['click','click']].forEach(([v, lbl]) => {
          const o = document.createElement('option');
          o.value = v; o.textContent = lbl;
          if (b.trigger === v) o.selected = true;
          trigSel.appendChild(o);
        });
        trigSel.addEventListener('change', e => { pushUndo(); b.trigger = e.target.value; markDirty(); });

        const opSel = document.createElement('select');
        opSel.className = 'prop-input';
        opSel.style.cssText = 'width:46px;font-size:10px;padding:2px';
        [['set','set'],['add','add'],['sub','sub'],['mul','mul']].forEach(([v, lbl]) => {
          const o = document.createElement('option');
          o.value = v; o.textContent = lbl;
          if (b.varOp === v) o.selected = true;
          opSel.appendChild(o);
        });
        opSel.addEventListener('change', e => { pushUndo(); b.varOp = e.target.value; markDirty(); });

        const varSel = document.createElement('select');
        varSel.className = 'prop-input';
        varSel.style.cssText = 'flex:1;min-width:50px;font-size:10px;padding:2px';
        const noneOpt = document.createElement('option');
        noneOpt.value = ''; noneOpt.textContent = '(none)';
        varSel.appendChild(noneOpt);
        Object.keys(E.levelVars).forEach(k => {
          const o = document.createElement('option');
          o.value = k; o.textContent = k;
          if (b.varName === k) o.selected = true;
          varSel.appendChild(o);
        });
        varSel.addEventListener('change', e => { pushUndo(); b.varName = e.target.value; markDirty(); });

        const valInput = document.createElement('input');
        valInput.className = 'prop-input';
        valInput.type = 'number'; valInput.step = '0.01';
        valInput.style.width = '44px';
        valInput.value = b.varValue ?? 0;
        valInput.addEventListener('change', e => { pushUndo(); b.varValue = parseFloat(e.target.value) || 0; markDirty(); });

        const delBtn = document.createElement('button');
        delBtn.className = 'btn btn-del';
        delBtn.style.cssText = 'font-size:10px;padding:2px 5px';
        delBtn.textContent = '\xd7';
        delBtn.addEventListener('click', () => {
          pushUndo();
          st.buttons.splice(bi, 1);
          if (!st.buttons.length) delete st.buttons;
          renderInputRows();
          markDirty();
        });

        row.appendChild(trigSel); row.appendChild(opSel); row.appendChild(varSel);
        row.appendChild(valInput); row.appendChild(delBtn);
        inputsList.appendChild(row);
      });
    };

    btnAddInput.addEventListener('click', () => {
      pushUndo();
      if (!st.buttons) st.buttons = [];
      st.buttons.push({ trigger: 'scrollup', varOp: 'add', varName: '', varValue: 0 });
      renderInputRows();
      markDirty();
    });

    renderInputRows();
    { const _sb = item.querySelector('.state-body'); (_sb || item).appendChild(inputsSection); }
    _appendBoneOverridesToStateItem(item, obj, idx);

    item.querySelectorAll('input, select').forEach(el => {
      el.addEventListener('focus', () => { if (E.selected) pushUndo(); });
    });

    item.setAttribute('draggable', 'true');
    item.addEventListener('dragstart', e => {
      E._stateDragSrc = idx;
      e.dataTransfer.effectAllowed = 'move';
      item.style.opacity = '0.5';
    });
    item.addEventListener('dragend', () => { item.style.opacity = ''; });
    item.addEventListener('dragover', e => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      item.style.outline = '1px dashed #5577aa';
    });
    item.addEventListener('dragleave', () => { item.style.outline = ''; });
    item.addEventListener('drop', e => {
      e.preventDefault();
      item.style.outline = '';
      if (E._stateDragSrc === undefined || E._stateDragSrc === idx) return;
      pushUndo();
      const [moved] = obj.userData.states.splice(E._stateDragSrc, 1);
      obj.userData.states.splice(idx, 0, moved);
      renderStatesPanel(obj);
      markDirty();
    });

    list.appendChild(item);
  });

  if (!states.length) {
    const hint = document.createElement('div');
    hint.style.cssText = 'font-size:10px;color:#555577;padding:2px 0';
    hint.textContent = 'No states — click + Add to capture object transform as a state';
    list.appendChild(hint);
  }
}

// â”€â”€â”€ UI wiring â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function beginLink() {
  const obj = E.selected;
  if (!obj || obj.userData.isRef) { setStatus('Select a placed object first'); return; }
  E.linkMode   = true;
  E.linkSource = obj;
  document.getElementById('link-hint').style.display = '';
  document.getElementById('btn-add-link').classList.add('active');
  setStatus('Link mode — click the object to wire to this interact (Esc cancels)');
}

function cancelLink() {
  if (!E.linkMode) return;
  E.linkMode   = false;
  E.linkSource = null;
  document.getElementById('link-hint').style.display = 'none';
  document.getElementById('btn-add-link').classList.remove('active');
  setStatus('Link cancelled');
}

function renderLinksPanel(obj) {
  const section = document.getElementById('links-section');
  const list    = document.getElementById('links-list');
  if (!section || !list) return;
  section.style.display = obj ? '' : 'none';
  if (!obj) {
    const hint = document.getElementById('link-hint');
    if (hint) hint.style.display = 'none';
    return;
  }

  list.innerHTML = '';
  const links = obj.userData.links || [];

  links.forEach((link, idx) => {
    let targetName = '#' + link.id;
    E.placedGroup.traverse(o => {
      if (o.userData.editorId === link.id) targetName = o.name || targetName;
    });
    const item = document.createElement('div');
    item.className = 'link-item';
    item.style.cssText = 'display:flex;flex-direction:column;gap:0;padding:4px 0;border-bottom:1px solid #151530';

    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;gap:4px';

    const nameSpan = document.createElement('span');
    nameSpan.style.cssText = 'flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
    nameSpan.title = targetName;
    nameSpan.textContent = targetName;

    const keyBtn = document.createElement('button');
    keyBtn.style.cssText = 'font-size:10px;min-width:32px;padding:2px 5px;background:#112233;border:1px solid #2255aa;color:' + (link.key ? '#88ffaa' : '#88aaff') + ';cursor:pointer;border-radius:3px';
    keyBtn.title = 'Click to bind a key (Esc to clear)';
    keyBtn.textContent = link.key ? _edKeyDisplay(link.key) : '—';

    const delBtn = document.createElement('button');
    delBtn.className = 'btn btn-del';
    delBtn.style.cssText = 'font-size:10px;padding:2px 6px';
    delBtn.textContent = '×';

    row.appendChild(nameSpan);
    row.appendChild(keyBtn);
    row.appendChild(delBtn);

    const labelInput = document.createElement('input');
    labelInput.type = 'text';
    labelInput.value = link.label || '';
    labelInput.placeholder = 'Tooltip text (auto from target state)';
    labelInput.style.cssText = 'margin-top:3px;width:100%;font-size:10px;background:#0a0e14;border:1px solid #223355;color:#99aacc;padding:2px 4px;box-sizing:border-box;border-radius:2px';

    item.appendChild(row);
    item.appendChild(labelInput);

    keyBtn.addEventListener('click', () => {
      pushUndo();
      keyBtn.textContent = 'Press...';
      keyBtn.style.color = '#ffaa44';
      function onKey(e) {
        e.preventDefault();
        e.stopImmediatePropagation();
        document.removeEventListener('keydown', onKey, true);
        document.removeEventListener('mousedown', onMouse, true);
        if (e.code === 'Escape') {
          delete link.key;
          keyBtn.textContent = '—';
          keyBtn.style.color = '#88aaff';
        } else {
          link.key = e.code;
          keyBtn.textContent = _edKeyDisplay(e.code);
          keyBtn.style.color = '#88ffaa';
        }
        markDirty();
      }
      function onMouse(e) {
        if (e.button !== 0 && e.button !== 2) return;
        e.preventDefault();
        e.stopImmediatePropagation();
        document.removeEventListener('mousedown', onMouse, true);
        document.removeEventListener('keydown', onKey, true);
        link.key = e.button === 0 ? 'MouseLeft' : 'MouseRight';
        keyBtn.textContent = _edKeyDisplay(link.key);
        keyBtn.style.color = '#88ffaa';
        markDirty();
      }
      document.addEventListener('keydown', onKey, true);
      document.addEventListener('mousedown', onMouse, true);
    });

    labelInput.addEventListener('focus', () => pushUndo());
    labelInput.addEventListener('input', () => {
      const v = labelInput.value.trim();
      if (v) link.label = v; else delete link.label;
      markDirty();
    });

    delBtn.addEventListener('click', () => {
      pushUndo();
      obj.userData.links.splice(idx, 1);
      if (!obj.userData.links.length) delete obj.userData.links;
      renderLinksPanel(obj); markDirty();
    });

    list.appendChild(item);
  });

  if (!links.length) {
    const hint = document.createElement('div');
    hint.style.cssText = 'font-size:10px;color:#555577;padding:2px 0';
    hint.textContent = 'No links — click + Link then click a target object';
    list.appendChild(hint);
  }
}

// ─── Variables panel ──────────────────────────────────────────────────────────
function renderVarsPanel() {
  const list = document.getElementById('vars-list');
  if (!list) return;
  list.innerHTML = '';

  const entries = Object.entries(E.levelVars);
  if (!entries.length) {
    const hint = document.createElement('div');
    hint.style.cssText = 'font-size:10px;color:#445566;padding:2px 0';
    hint.textContent = 'No variables — click + Add to define a level variable';
    list.appendChild(hint);
    return;
  }

  entries.forEach(([fullName, v]) => {
    const shortName = fullName.startsWith('lv_') ? fullName.slice(3) : fullName;
    const row = document.createElement('div');
    row.className = 'prop-row';
    row.style.cssText = 'align-items:center;gap:3px;flex-wrap:nowrap';
    row.innerHTML = `
      <span style="font-size:10px;color:#7799bb;white-space:nowrap">lv_</span>
      <input class="prop-input" data-vi="name" value="${escHtml(shortName)}" style="flex:1;min-width:40px" placeholder="name">
      <select class="prop-input" data-vi="type" style="width:60px;padding:2px 2px;font-size:10px">
        <option value="number" ${v.type==='number'?'selected':''}>number</option>
        <option value="bool"   ${v.type==='bool'  ?'selected':''}>bool</option>
        <option value="string" ${v.type==='string'?'selected':''}>string</option>
      </select>
      <input class="prop-input" data-vi="initial" value="${escHtml(String(v.initial ?? ''))}" style="width:44px" placeholder="init" title="Initial value when level loads">
      <button class="btn btn-del" data-vi="del" style="font-size:10px;padding:2px 5px" title="Delete variable">&times;</button>
    `;

    const g = sel => row.querySelector(`[data-vi="${sel}"]`);

    const rename = newShort => {
      const newFull = 'lv_' + newShort.replace(/[^a-zA-Z0-9_]/g, '_');
      if (newFull === fullName) return fullName;
      if (E.levelVars[newFull]) return fullName; // conflict — keep old
      E.levelVars[newFull] = E.levelVars[fullName];
      delete E.levelVars[fullName];
      return newFull;
    };

    g('name').addEventListener('change', e => {
      pushUndo();
      const newFull = rename(e.target.value.trim() || 'var');
      e.target.value = newFull.startsWith('lv_') ? newFull.slice(3) : newFull;
      markDirty();
      refreshVarDropdowns();
    });
    g('type').addEventListener('change', e => {
      pushUndo();
      E.levelVars[fullName].type = e.target.value;
      markDirty();
    });
    g('initial').addEventListener('change', e => {
      pushUndo();
      const vd = E.levelVars[fullName];
      if (!vd) return;
      const raw = e.target.value;
      vd.initial = vd.type === 'number' ? (parseFloat(raw) || 0)
                 : vd.type === 'bool'   ? (raw === 'true' || raw === '1')
                 : raw;
      markDirty();
    });
    g('del').addEventListener('click', () => {
      pushUndo();
      delete E.levelVars[fullName];
      markDirty();
      renderVarsPanel();
      refreshVarDropdowns();
    });

    list.appendChild(row);
  });
}

function refreshVarDropdowns() {
  // Update all trigger-var-name dropdowns (there's one in the trigger props panel)
  _populateVarSelect(document.getElementById('trigger-presence-var'), null);
  _populateVarSelect(document.getElementById('trigger-var-name'), null);
  // Re-render states panel to update condition var dropdowns (if obj selected)
  if (E.selected) renderStatesPanel(E.selected);
}

function _populateVarSelect(selectEl, currentVal) {
  if (!selectEl) return;
  const prev = currentVal ?? selectEl.value;
  selectEl.innerHTML = '<option value="">(none)</option>';
  Object.keys(E.levelVars).forEach(k => {
    const opt = document.createElement('option');
    opt.value = k;
    opt.textContent = k;
    if (k === prev) opt.selected = true;
    selectEl.appendChild(opt);
  });
}

function setupUI() {
  // Links panel — "+ Link" button
  document.getElementById('btn-add-link')?.addEventListener('click', () => {
    if (E.linkMode) cancelLink();
    else beginLink();
  });

  // States panel — "Add State" button
  document.getElementById('btn-add-state')?.addEventListener('click', () => {
    const obj = E.selected;
    if (!obj) { setStatus('Select an object first'); return; }
    pushUndo();
    if (!obj.userData.states) obj.userData.states = [];
    obj.userData.states.push(captureStateFromObj(obj));
    renderStatesPanel(obj);
    markDirty();
  });

  // Variables panel — "Add Variable" button
  document.getElementById('btn-add-var')?.addEventListener('click', () => {
    pushUndo();
    let n = 1;
    while (E.levelVars['lv_var' + n]) n++;
    E.levelVars['lv_var' + n] = { type: 'number', initial: 0 };
    renderVarsPanel();
    refreshVarDropdowns();
    markDirty();
  });

  // Level toolbar
  document.getElementById('btn-new-level').addEventListener('click',  openLevelModal);
  document.getElementById('btn-open-level').addEventListener('click', openLevelModal);
  document.getElementById('btn-save-level').addEventListener('click', saveLevel);

  // Modal
  document.getElementById('modal-cancel').addEventListener('click', closeLevelModal);
  document.getElementById('modal-confirm').addEventListener('click', async () => {
    const nameInput = document.getElementById('modal-new-name').value.trim();
    const selected  = document.querySelector('#level-modal-list .level-list-item.selected');
    const name = nameInput || selected?.dataset.level || '';
    if (!name) { setStatus('Enter a level name or select one'); return; }
    closeLevelModal();
    await loadLevel(name);
  });
  document.getElementById('level-modal-list').addEventListener('dblclick', async e => {
    const item = e.target.closest('.level-list-item');
    if (!item) return;
    closeLevelModal();
    await loadLevel(item.dataset.level);
  });

  // Transform mode buttons
  document.getElementById('btn-move').addEventListener('click',   () => setTransformMode('translate'));
  document.getElementById('btn-rotate').addEventListener('click', () => setTransformMode('rotate'));
  document.getElementById('btn-scale').addEventListener('click',  () => setTransformMode('scale'));

  // Toolbar toggles
  document.getElementById('btn-grid').addEventListener('click', () => {
    E.showGrid = !E.showGrid;
    E.gridHelper.visible = E.showGrid;
    document.getElementById('btn-grid').classList.toggle('active', E.showGrid);
  });
  document.getElementById('btn-colliders').addEventListener('click', () => {
    E.showColliders = !E.showColliders;
    document.getElementById('btn-colliders').classList.toggle('active', E.showColliders);
    updateColliderHelpers();
  });

  document.getElementById('btn-preview-lighting').addEventListener('click', () => {
    E.previewLighting = !E.previewLighting;
    document.getElementById('btn-preview-lighting').classList.toggle('active', E.previewLighting);
    applyLightingMode();
  });

  function applyLightingMode() {
    const preview = E.previewLighting;
    // Swap ambient lights
    const editorAmbient  = E.scene.getObjectByName('__editorAmbient__');
    const editorSun      = E.scene.getObjectByName('__editorSun__');
    const previewAmbient = E.scene.getObjectByName('__previewAmbient__');
    if (editorAmbient)  editorAmbient.visible  = !preview;
    if (editorSun)      editorSun.visible       = !preview;
    if (previewAmbient) previewAmbient.visible  =  preview;

    // Tone mapping — match game's ACESFilmic exposure 1.4 vs flat editor look
    E.renderer.toneMapping         = preview ? THREE.ACESFilmicToneMapping : THREE.NoToneMapping;
    E.renderer.toneMappingExposure = preview ? 1.4 : 1.0;

    // Background and fog
    if (preview) {
      E.scene.background = new THREE.Color(0x000000);
      E.scene.fog        = new THREE.FogExp2(0x000000, 0.1);
    } else {
      E.scene.background = null;
      E.scene.fog        = null;
    }

    // Force material updates so tone-mapping change takes effect immediately
    E.scene.traverse(obj => { if (obj.isMesh && obj.material) obj.material.needsUpdate = true; });

    // Show/hide range wires on all placed lights
    E.placedGroup.children.forEach(obj => {
      if (!obj.userData.isLightGroup) return;
      const wire = obj.getObjectByName('__rangeWire__');
      if (wire) wire.visible = !preview;
    });
  }

  // Primitives palette
  document.querySelectorAll('.prim-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!E.levelName) { setStatus('Open or create a level first'); return; }
      const type = btn.dataset.prim;
      if (E.placingType === type) { cancelPlace(); return; }
      document.querySelectorAll('.prim-btn, .model-item').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      beginPlace(type);
    });
  });

  // Import model
  document.getElementById('btn-import-model').addEventListener('click', async () => {
    if (!window.electron) { setStatus('Model import requires Electron'); return; }
    const p = await window.electron.importModel();
    if (p) {
      await refreshModelList();
      if (E.levelName) {
        document.querySelectorAll('.prim-btn, .model-item').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.model-item').forEach(el => {
          if (el.title === p) el.classList.add('active');
        });
        beginPlace('model:' + p);
        setStatus(`Imported "${p.split(/[\\/]/).pop()}" — click in viewport to place`);
      } else {
        setStatus(`Imported: ${p.split(/[\\/]/).pop()} — open a level to place it`);
      }
    }
  });

  document.getElementById('btn-import-mtl')?.addEventListener('click', async () => {
    if (!window.electron?.importMtl) { setStatus('MTL import requires Electron'); return; }
    const name = await window.electron.importMtl();
    if (name) setStatus(`Imported MTL: ${name} — re-place your OBJ to apply it`);
  });

  document.getElementById('btn-import-image-model')?.addEventListener('click', async () => {
    if (!window.electron) { setStatus('Image import requires Electron'); return; }
    const p = await window.electron.importImageModel();
    if (p) {
      await refreshModelList();
      if (E.levelName) {
        document.querySelectorAll('.prim-btn, .model-item, .image-model-item').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.image-model-item').forEach(el => {
          if (el.title === p) el.classList.add('active');
        });
        beginPlace('image-model:' + p);
        setStatus(`Imported "${p.split(/[\\/]/).pop()}" — click in viewport to place`);
      } else {
        setStatus(`Imported: ${p.split(/[\\/]/).pop()} — open a level to place it`);
      }
    }
  });

  // Right-panel property inputs - live sync to selected object
  function bindProp(id, apply) {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('focus', () => { if (E.selected) pushUndo(); });
    const cb = () => { if (E.selected) { apply(parseFloat(el.value) || 0); markDirty(); } };
    el.addEventListener('input',  cb);
    el.addEventListener('change', cb);
  }
  bindProp('px', v => { E.selected.position.x = v; if (E.selected.userData._restPos) E.selected.userData._restPos.x = v; });
  bindProp('py', v => { E.selected.position.y = v; if (E.selected.userData._restPos) E.selected.userData._restPos.y = v; });
  bindProp('pz', v => { E.selected.position.z = v; if (E.selected.userData._restPos) E.selected.userData._restPos.z = v; });
  bindProp('sx', v => E.selected.scale.x = Math.max(0.001, v));
  bindProp('sy', v => E.selected.scale.y = Math.max(0.001, v));
  bindProp('sz', v => E.selected.scale.z = Math.max(0.001, v));
  bindProp('rx', v => E.selected.rotation.x = v * RAD);
  bindProp('ry', v => E.selected.rotation.y = v * RAD);
  bindProp('rz', v => E.selected.rotation.z = v * RAD);

  document.getElementById('obj-color').addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('obj-color').addEventListener('input', e => {
    if (!E.selected) return;
    const hexEl = document.getElementById('obj-color-hex');
    if (hexEl) hexEl.value = e.target.value;
    _applyColor(E.selected, e.target.value);
  });
  document.getElementById('obj-color-hex')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('obj-color-hex')?.addEventListener('input', e => {
    if (!E.selected) return;
    const hex = e.target.value.trim();
    if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return;
    const colEl = document.getElementById('obj-color');
    if (colEl) colEl.value = hex;
    _applyColor(E.selected, hex);
  });
  document.getElementById('chk-collidable').addEventListener('mousedown', () => { if (E.selected) pushUndo(); });
  document.getElementById('chk-collidable').addEventListener('change', e => {
    if (E.selected) { E.selected.userData.collidable = e.target.checked; markDirty(); }
  });
  document.getElementById('chk-shadow').addEventListener('mousedown', () => { if (E.selected) pushUndo(); });
  document.getElementById('chk-shadow').addEventListener('change', e => {
    if (!E.selected) return;
    if (isLightType(E.selected.userData.primType)) {
      E.selected.userData.castShadow = e.target.checked;
      E.selected.traverse(c => { if (c.isLight) c.castShadow = e.target.checked; });
    } else {
      const v = e.target.checked;
      E.selected.userData.castShadow = v;
      E.selected.castShadow = v;
      E.selected.traverse(c => { if (c.isMesh) c.castShadow = v; });
    }
    markDirty();
  });
  document.getElementById('obj-emissive-color')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('obj-emissive-color')?.addEventListener('input', e => {
    if (!E.selected) return;
    E.selected.userData.emissiveColor = e.target.value;
    const col = new THREE.Color(e.target.value);
    E.selected.traverse(c => {
      if (c.isMesh && c.material) {
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { if ('emissive' in m) m.emissive.copy(col); });
      }
    });
    markDirty();
  });
  document.getElementById('obj-emissive-intensity')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('obj-emissive-intensity')?.addEventListener('input', e => {
    if (!E.selected) return;
    const v = parseFloat(e.target.value) || 0;
    E.selected.userData.emissiveIntensity = v;
    E.selected.traverse(c => {
      if (c.isMesh && c.material) {
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { if ('emissiveIntensity' in m) m.emissiveIntensity = v; });
      }
    });
    markDirty();
  });
  document.getElementById('obj-roughness')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('obj-roughness')?.addEventListener('input', e => {
    if (!E.selected) return;
    const v = Math.max(0, Math.min(1, parseFloat(e.target.value) ?? 1));
    E.selected.userData.roughness = v;
    E.selected.traverse(c => {
      if (c.isMesh && c.material) {
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { if ('roughness' in m) { m.roughness = v; m.needsUpdate = true; } });
      }
    });
    markDirty();
  });
  document.getElementById('obj-metalness')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('obj-metalness')?.addEventListener('input', e => {
    if (!E.selected) return;
    const v = Math.max(0, Math.min(1, parseFloat(e.target.value) ?? 0));
    E.selected.userData.metalness = v;
    E.selected.traverse(c => {
      if (c.isMesh && c.material) {
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { if ('metalness' in m) { m.metalness = v; m.needsUpdate = true; } });
      }
    });
    markDirty();
  });
  document.getElementById('chk-double-side')?.addEventListener('mousedown', () => { if (E.selected) pushUndo(); });
  document.getElementById('chk-double-side')?.addEventListener('change', e => {
    if (!E.selected) return;
    const v = e.target.checked;
    E.selected.userData.doubleSide = v || undefined;
    E.selected.traverse(c => {
      if (c.isMesh && c.material) {
        const mats = Array.isArray(c.material) ? c.material : [c.material];
        mats.forEach(m => { m.side = v ? THREE.DoubleSide : THREE.FrontSide; m.needsUpdate = true; });
      }
    });
    markDirty();
  });
  document.getElementById('chk-invert-normals')?.addEventListener('mousedown', () => { if (E.selected) pushUndo(); });
  document.getElementById('chk-invert-normals')?.addEventListener('change', e => {
    if (!E.selected) return;
    E.selected.userData.invertNormals = e.target.checked || undefined;
    E.selected.traverse(c => { if (c.isMesh && c.geometry) _flipGeometryNormals(c.geometry); });
    markDirty();
  });
  document.getElementById('btn-convert-pbr')?.addEventListener('click', () => {
    if (!E.selected) return;
    pushUndo();
    const roughness = E.selected.userData.roughness ?? 1;
    const metalness = E.selected.userData.metalness ?? 0;
    E.selected.traverse(c => {
      if (!c.isMesh) return;
      const mats = Array.isArray(c.material) ? c.material : [c.material];
      const newMats = mats.map(m => {
        if (!m || 'roughness' in m) return m;
        const pbr = new THREE.MeshStandardMaterial({
          color:      m.color?.clone() ?? new THREE.Color(0xffffff),
          map:        m.map        ?? null,
          normalMap:  m.normalMap  ?? null,
          emissiveMap: m.emissiveMap ?? null,
          aoMap:      m.aoMap      ?? null,
          emissive:   m.emissive?.clone() ?? new THREE.Color(0x000000),
          emissiveIntensity: m.emissiveIntensity ?? 1,
          roughness,
          metalness,
          side:       m.side,
          transparent: m.transparent,
          opacity:    m.opacity,
        });
        return pbr;
      });
      c.material = Array.isArray(c.material) ? newMats : newMats[0];
    });
    E.selected.userData.pbrConverted = true;
    markDirty();
    updateProps(E.selected);
  });
  document.getElementById('model-colorspace')?.addEventListener('change', e => {
    if (!E.selected) return;
    pushUndo();
    const cs = e.target.value;
    E.selected.userData.colorSpace = cs === 'srgb' ? undefined : cs;
    const threeCS = cs === 'linear' ? THREE.LinearSRGBColorSpace : THREE.SRGBColorSpace;
    E.selected.traverse(c => {
      if (!c.isMesh) return;
      const mats = Array.isArray(c.material) ? c.material : [c.material];
      mats.forEach(m => {
        if (!m) return;
        ['map','emissiveMap','normalMap','roughnessMap','metalnessMap','aoMap'].forEach(k => {
          if (m[k]) { m[k].colorSpace = threeCS; m[k].needsUpdate = true; }
        });
        m.needsUpdate = true;
      });
    });
    markDirty();
  });
  document.getElementById('obj-opacity')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('obj-opacity')?.addEventListener('input', e => {
    if (!E.selected || !E.selected.material) return;
    const parsed = parseFloat(e.target.value);
    const v = Math.max(0, Math.min(1, isNaN(parsed) ? 1 : parsed));
    E.selected.userData._opacity = v < 1 ? v : undefined;
    setMeshOpacity(E.selected, v);
    syncOpacityWireframe(E.selected);
    markDirty();
  });

  // ─── Geometry param inputs ──────────────────────────────────────────────────
  function setGeomParam(key, rawVal, isCheckbox) {
    const obj = E.selected;
    if (!obj || !GEOM_DEFAULTS[obj.userData.primType]) return;
    if (!obj.userData.geomParams) obj.userData.geomParams = {};
    obj.userData.geomParams[key] = isCheckbox ? rawVal : (parseFloat(rawVal) || 0);
    rebuildGeometry(obj);
    // If per-face textures exist, re-apply since the geometry groups are the same
    if (obj.userData.faceTextures) applyFaceTextures(obj);
  }
  const geomBindings = [
    // [inputId, paramKey, isCheckbox]
    ['geom-bevel',      'bevel',    false],
    ['geom-bevel-segs', 'bevelSegs',false],
    ['geom-box-ws',     'wSegs',    false],
    ['geom-box-hs',     'hSegs',    false],
    ['geom-box-ds',     'dSegs',    false],
    ['geom-sph-ws',     'wSegs',    false],
    ['geom-sph-hs',     'hSegs',    false],
    ['geom-sph-phi',    'phi',      false],
    ['geom-sph-theta',  'theta',    false],
    ['geom-cyl-rs',     'radSegs',  false],
    ['geom-cyl-hs',     'hSegs',    false],
    ['geom-cyl-rt',     'radTop',   false],
    ['geom-cyl-open',   'open',     true],
    ['geom-plane-ws',   'wSegs',      false],
    ['geom-plane-hs',   'hSegs',      false],
    ['geom-rope-len',   'ropeLength', false],
    ['geom-rope-rad',   'ropeRadius', false],
    ['geom-rope-segs',  'ropeSegs',   false],
    ['geom-rope-sag',   'ropeSag',    false],
    ['geom-rope-damp',  'ropeDamping',false],
  ];
  geomBindings.forEach(([id, key, isChk]) => {
    const el = document.getElementById(id);
    if (!el) return;
    const ev = isChk ? 'change' : 'change';
    el.addEventListener(ev, () => setGeomParam(key, isChk ? el.checked : el.value, isChk));
  });

  ['geom-rope-bx', 'geom-rope-by', 'geom-rope-bz'].forEach((id, axis) => {
    document.getElementById(id)?.addEventListener('change', () => {
      const obj = E.selected;
      if (!obj || obj.userData.primType !== 'rope') return;
      const p = obj.userData.geomParams ??= {};
      const d = GEOM_DEFAULTS.rope;
      const off = p.anchorBOffset ? [...p.anchorBOffset] : [...d.anchorBOffset];
      off[axis] = parseFloat(document.getElementById(id).value) || 0;
      p.anchorBOffset = off;
      rebuildGeometry(obj);
    });
  });

  document.getElementById('geom-rope-bid')?.addEventListener('change', e => {
    const obj = E.selected;
    if (!obj || obj.userData.primType !== 'rope') return;
    const v = e.target.value.trim();
    (obj.userData.geomParams ??= {}).anchorBId = v ? parseInt(v) : null;
    markDirty();
  });

  document.getElementById('btn-rope-attach-a')?.addEventListener('click', () => {
    if (E.ropeAnchorMode === 'A') cancelRopeAnchor();
    else beginRopeAnchor('A');
  });
  document.getElementById('btn-rope-attach-b')?.addEventListener('click', () => {
    if (E.ropeAnchorMode === 'B') cancelRopeAnchor();
    else beginRopeAnchor('B');
  });
  document.getElementById('btn-rope-detach-a')?.addEventListener('click', () => {
    const obj = E.selected;
    if (!obj || obj.userData.primType !== 'rope') return;
    pushUndo();
    const p = obj.userData.geomParams ??= {};
    delete p.anchorAId;
    delete p.anchorAOffset;
    refreshGeomPanel(obj);
    markDirty();
  });
  document.getElementById('btn-rope-detach-b')?.addEventListener('click', () => {
    const obj = E.selected;
    if (!obj || obj.userData.primType !== 'rope') return;
    pushUndo();
    const p = obj.userData.geomParams ??= {};
    delete p.anchorBId;
    delete p.anchorBWorldOffset;
    refreshGeomPanel(obj);
    markDirty();
  });

  // Save trigger inputs
  document.getElementById('trigger-slot')?.addEventListener('input', e => {
    if (E.selected && E.selected.userData.primType === 'save-trigger') {
      if (!E._triggerSlotUndoActive) { pushUndo(); E._triggerSlotUndoActive = true; }
      E.selected.userData.saveSlot = e.target.value.trim() || 'autosave'; markDirty();
    }
  });
  document.getElementById('trigger-slot')?.addEventListener('change', () => { E._triggerSlotUndoActive = false; });
  document.getElementById('trigger-once')?.addEventListener('change', e => {
    if (E.selected && E.selected.userData.primType === 'save-trigger') {
      pushUndo();
      E.selected.userData.onceOnly = e.target.checked; markDirty();
    }
  });
  document.getElementById('trigger-presence-var')?.addEventListener('change', e => {
    if (E.selected && E.selected.userData.primType === 'custom-trigger') {
      pushUndo();
      E.selected.userData.presenceVar = e.target.value; markDirty();
    }
  });
  document.getElementById('trigger-var-name')?.addEventListener('change', e => {
    if (E.selected && E.selected.userData.primType === 'custom-trigger') {
      pushUndo();
      E.selected.userData.triggerVar = e.target.value; markDirty();
    }
  });
  document.getElementById('trigger-var-op')?.addEventListener('change', e => {
    if (E.selected && E.selected.userData.primType === 'custom-trigger') {
      pushUndo();
      E.selected.userData.triggerVarOp = e.target.value; markDirty();
    }
  });
  document.getElementById('trigger-var-value')?.addEventListener('change', e => {
    if (E.selected && E.selected.userData.primType === 'custom-trigger') {
      pushUndo();
      E.selected.userData.triggerVarValue = e.target.value; markDirty();
    }
  });

  // Light property inputs
  function applyLightParam(param, getValue) {
    return () => {
      if (!E.selected || !isLightType(E.selected.userData.primType)) return;
      const val = getValue();
      E.selected.userData[param] = val;
      E.selected.traverse(child => {
        if (!child.isLight) return;
        if (param === 'intensity') child.intensity = val;
        else if (param === 'distance' && child.distance !== undefined) child.distance = val;
        else if (param === 'decay'    && child.decay    !== undefined) child.decay    = val;
        else if (param === 'angle'    && child.angle    !== undefined) child.angle    = THREE.MathUtils.degToRad(val);
        else if (param === 'penumbra' && child.penumbra !== undefined) child.penumbra = val;
      });
      // Rebuild range wire if shape-defining params change
      if (param === 'distance' || param === 'angle') updateLightRangeHelper(E.selected);
      markDirty();
    };
  }
  function bindLightProp(id, param, parseFn = parseFloat) {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('focus', () => { if (E.selected) pushUndo(); });
    const fn = applyLightParam(param, () => parseFn(el.value) || 0);
    el.addEventListener('input', fn);
    el.addEventListener('change', fn);
  }
  bindLightProp('light-intensity', 'intensity');
  bindLightProp('light-distance',  'distance');
  bindLightProp('light-angle',     'angle');
  bindLightProp('light-penumbra',  'penumbra');
  bindLightProp('light-decay',     'decay');

  // ─── Model maps panel wiring ──────────────────────────────────────────────
  ['diffuse','normal','roughness','metalness'].forEach(slot => {
    document.getElementById(`btn-mmap-import-${slot}`)?.addEventListener('click', async () => {
      if (!window.electron?.importTexture) return;
      const name = await window.electron.importTexture();
      if (!name) return;
      await refreshTextureList();
      const el = document.getElementById(`mmap-${slot}`);
      if (el) el.value = name;
      if (E.selected) { pushUndo(); await applyModelMapSlot(E.selected, slot, name); }
    });
    document.getElementById(`btn-mmap-clear-${slot}`)?.addEventListener('click', async () => {
      const el = document.getElementById(`mmap-${slot}`);
      if (el) el.value = '';
      if (E.selected) { pushUndo(); await applyModelMapSlot(E.selected, slot, ''); }
    });
    document.getElementById(`mmap-${slot}`)?.addEventListener('change', async e => {
      if (E.selected) { pushUndo(); await applyModelMapSlot(E.selected, slot, e.target.value.trim()); }
    });
    document.getElementById(`mmap-res-${slot}`)?.addEventListener('change', async e => {
      if (!E.selected) return;
      pushUndo();
      const val = parseInt(e.target.value) || null;
      if (!E.selected.userData.modelMapRes) E.selected.userData.modelMapRes = {};
      if (val) E.selected.userData.modelMapRes[slot] = val;
      else delete E.selected.userData.modelMapRes[slot];
      if (!Object.keys(E.selected.userData.modelMapRes).length) delete E.selected.userData.modelMapRes;
      const texName = E.selected.userData.modelMaps?.[slot];
      if (texName) await applyModelMapSlot(E.selected, slot, texName);
      markDirty();
    });
  });

  // ─── Texture panel wiring ──────────────────────────────────────────────────
  // Import texture
  document.getElementById('btn-import-tex')?.addEventListener('click', async () => {
    if (!window.electron?.importTexture) return;
    const name = await window.electron.importTexture();
    if (!name) return;
    await refreshTextureList();
    const el = document.getElementById('tex-name');
    if (el) el.value = name;
    applyCurrentFaceConfig();
    setStatus(`Texture "${name}" imported`);
  });

  document.getElementById('btn-import-normal')?.addEventListener('click', async () => {
    if (!window.electron?.importTexture) return;
    const name = await window.electron.importTexture();
    if (!name) return;
    await refreshTextureList();
    const el = document.getElementById('tex-normal-map');
    if (el) el.value = name;
    applyCurrentFaceConfig();
    setStatus(`Normal map "${name}" imported`);
  });

  document.getElementById('btn-import-roughness')?.addEventListener('click', async () => {
    if (!window.electron?.importTexture) return;
    const name = await window.electron.importTexture();
    if (!name) return;
    await refreshTextureList();
    const el = document.getElementById('tex-roughness-map');
    if (el) el.value = name;
    applyCurrentFaceConfig();
    setStatus(`Roughness map "${name}" imported`);
  });

  // Face dropdown
  document.getElementById('tex-face')?.addEventListener('change', e => {
    const val = e.target.value;
    E.selectedFace = val === 'all' ? null : parseInt(val);
    updateFaceHighlight(E.selected, E.selectedFace);
    refreshTexPanel(E.selected);
  });

  // Pick face button
  document.getElementById('btn-pick-face')?.addEventListener('click', () => {
    E.facePickMode ? cancelFacePick() : beginFacePick();
  });

  // Texture name (apply on change/datalist pick)
  const texNameEl = document.getElementById('tex-name');
  if (texNameEl) {
    texNameEl.addEventListener('change', applyCurrentFaceConfig);
    texNameEl.addEventListener('input', () => {
      if (E.availableTextures.includes(texNameEl.value)) applyCurrentFaceConfig();
    });
  }

  // Tiling mode
  document.getElementById('tex-tiling-mode')?.addEventListener('change', e => {
    _syncTilingModeUI(e.target.value);
    applyCurrentFaceConfig();
  });

  // Repeat, world scale, offset, wrap — all trigger applyCurrentFaceConfig
  ['tex-repeat-x','tex-repeat-y','tex-world-scale','tex-offset-x','tex-offset-y','tex-wrap'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', applyCurrentFaceConfig);
  });

  // Clear texture
  document.getElementById('btn-clear-tex')?.addEventListener('click', () => {
    const el = document.getElementById('tex-name');
    if (el) el.value = '';
    applyCurrentFaceConfig();
  });
  document.getElementById('btn-clear-normal')?.addEventListener('click', () => {
    const el = document.getElementById('tex-normal-map');
    if (el) el.value = '';
    applyCurrentFaceConfig();
  });
  document.getElementById('btn-clear-roughness')?.addEventListener('click', () => {
    const el = document.getElementById('tex-roughness-map');
    if (el) el.value = '';
    applyCurrentFaceConfig();
  });

  document.getElementById('btn-import-bump')?.addEventListener('click', async () => {
    if (!window.electron?.importTexture) return;
    const name = await window.electron.importTexture();
    if (!name) return;
    await refreshTextureList();
    const el = document.getElementById('tex-bump-map');
    if (el) el.value = name;
    applyCurrentFaceConfig();
    setStatus(`Bump map "${name}" imported`);
  });
  document.getElementById('btn-clear-bump')?.addEventListener('click', () => {
    const el = document.getElementById('tex-bump-map');
    if (el) el.value = '';
    applyCurrentFaceConfig();
  });

  // Normal/roughness/bump map inputs trigger applyCurrentFaceConfig on change
  document.getElementById('tex-normal-map')?.addEventListener('change', applyCurrentFaceConfig);
  document.getElementById('tex-roughness-map')?.addEventListener('change', applyCurrentFaceConfig);
  document.getElementById('tex-bump-map')?.addEventListener('change', applyCurrentFaceConfig);
  document.getElementById('tex-bump-scale')?.addEventListener('change', applyCurrentFaceConfig);

  // Edit UV button
  document.getElementById('btn-uv-edit')?.addEventListener('click', openUVEditor);

  // Edit Meshes button + mesh modal wiring
  document.getElementById('btn-mesh-edit')?.addEventListener('click', openMeshEditor);
  document.getElementById('btn-mesh-close')?.addEventListener('click', closeMeshEditor);

  makeDraggable('uv-modal', 'uv-modal-drag');
  makeDraggable('mesh-modal', 'mesh-modal-drag');
  makeDraggable('sound-list-modal', 'sound-list-modal-drag');
  makeDraggable('actor-mesh-modal', 'actor-mesh-modal-drag');

  document.getElementById('btn-sound-list-close')?.addEventListener('click', closeSoundListModal);

  // UV modal wiring
  document.getElementById('btn-uv-close')?.addEventListener('click', closeUVEditor);
  document.getElementById('btn-uv-apply')?.addEventListener('click', () => {
    const obj = E.selected;
    if (!obj) { closeUVEditor(); return; }
    pushUndo();
    const faceKey = E.selectedFace !== null ? String(E.selectedFace) : 'all';
    const existing = getFaceConfig(obj, faceKey) ?? {};
    existing.ox = parseFloat(document.getElementById('uv-ox').value) || 0;
    existing.oy = parseFloat(document.getElementById('uv-oy').value) || 0;
    existing.rx = Math.max(0.01, parseFloat(document.getElementById('uv-rx').value) || 1);
    existing.ry = Math.max(0.01, parseFloat(document.getElementById('uv-ry').value) || 1);
    setFaceConfig(obj, faceKey, existing);
    // Sync panel inputs too
    document.getElementById('tex-repeat-x').value = existing.rx.toFixed(2);
    document.getElementById('tex-repeat-y').value = existing.ry.toFixed(2);
    document.getElementById('tex-offset-x').value = existing.ox.toFixed(3);
    document.getElementById('tex-offset-y').value = existing.oy.toFixed(3);
    closeUVEditor();
  });

  // Click outside UV modal to close
  document.getElementById('uv-modal')?.addEventListener('click', e => {
    if (e.target === document.getElementById('uv-modal')) closeUVEditor();
  });

  // UV canvas drag
  _setupUVCanvasDrag();

  const sceneScriptsEl = document.getElementById('scene-scripts');
  if (sceneScriptsEl) {
    sceneScriptsEl.value = _scriptListToText(E.sceneScripts);
    sceneScriptsEl.addEventListener('focus', () => { if (E.levelName) pushUndo(); });
    sceneScriptsEl.addEventListener('change', e => {
      E.sceneScripts = _textToScriptList(e.target.value);
      markDirty();
    });
  }
  const objScriptsEl = document.getElementById('obj-scripts');
  if (objScriptsEl) {
    objScriptsEl.addEventListener('focus', () => { if (E.selected) pushUndo(); });
    objScriptsEl.addEventListener('change', e => {
      if (!E.selected) return;
      const scripts = _textToScriptList(e.target.value);
      if (scripts.length) E.selected.userData.scripts = scripts;
      else delete E.selected.userData.scripts;
      markDirty();
    });
  }

  document.getElementById('obj-label').addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('obj-label').addEventListener('input', e => {
    if (!E.selected) return;
    E.selected.userData.label = e.target.value;
    E.selected.name = e.target.value || (E.selected.userData.primType + '_' + E.selected.userData.editorId);
    document.getElementById('sel-name').textContent = E.selected.name;
    updateSceneList(); markDirty();
  });

  // Groups
  const groupNameRow    = document.getElementById('group-name-row');
  const groupNameInput  = document.getElementById('group-name-input');
  const groupPickRow    = document.getElementById('group-pick-row');
  const groupPickSelect = document.getElementById('group-pick-select');

  function hideGroupInputs() {
    groupNameRow.style.display  = 'none';
    groupPickRow.style.display  = 'none';
    groupNameInput.value = '';
  }

  document.getElementById('btn-new-group').addEventListener('click', () => {
    hideGroupInputs();
    groupNameRow.style.display = '';
    groupNameInput.focus();
  });

  function commitNewGroup() {
    const name = groupNameInput.value.trim();
    hideGroupInputs();
    if (!name) return;
    pushUndo();
    const gid = 'g_' + Date.now();
    E.groups[gid] = { name, ids: new Set() };
    if (E.selected) {
      E.groups[gid].ids.add(E.selected.userData.editorId);
      setGroupDisplay(gid);
    }
    updateGroupsPanel(); markDirty();
  }
  document.getElementById('group-name-ok').addEventListener('click', commitNewGroup);
  document.getElementById('group-name-cancel').addEventListener('click', hideGroupInputs);
  groupNameInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.stopPropagation(); commitNewGroup(); }
    if (e.key === 'Escape') { e.stopPropagation(); hideGroupInputs(); }
  });

  document.getElementById('btn-add-to-group').addEventListener('click', () => {
    if (!E.selected) { setStatus('Select an object first'); return; }
    const gids = Object.keys(E.groups);
    if (!gids.length) { setStatus('No groups yet — create one first'); return; }
    hideGroupInputs();
    groupPickSelect.innerHTML = '';
    gids.forEach(gid => {
      const opt = document.createElement('option');
      opt.value = gid;
      opt.textContent = E.groups[gid].name;
      groupPickSelect.appendChild(opt);
    });
    groupPickRow.style.display = '';
  });

  function commitAddToGroup() {
    const gid = groupPickSelect.value;
    hideGroupInputs();
    if (!gid || !E.groups[gid] || !E.selected) return;
    pushUndo();
    E.groups[gid].ids.add(E.selected.userData.editorId);
    setGroupDisplay(gid); updateGroupsPanel(); markDirty();
  }
  document.getElementById('group-pick-ok').addEventListener('click', commitAddToGroup);
  document.getElementById('group-pick-cancel').addEventListener('click', hideGroupInputs);
  document.getElementById('btn-move-group').addEventListener('click', () => {
    beginGroupTransform(findGroupOfObj(E.selected));
  });
  document.getElementById('btn-ungroup').addEventListener('click', () => {
    if (!E.selected) return;
    pushUndo();
    const id = E.selected.userData.editorId;
    for (const g of Object.values(E.groups)) g.ids.delete(id);
    for (const gid of Object.keys(E.groups)) { if (E.groups[gid].ids.size === 0) delete E.groups[gid]; }
    setGroupDisplay(null); updateGroupsPanel(); markDirty();
  });

  document.getElementById('btn-export-group-glb').addEventListener('click', exportGroupGLB);
  document.getElementById('btn-model-editor').addEventListener('click', () => openModelEditor(E.selected));

  document.getElementById('btn-toggle-groups-panel').addEventListener('click', () => {
    const p = document.getElementById('groups-panel');
    const open = p.style.display !== 'none';
    p.style.display = open ? 'none' : '';
    document.getElementById('btn-toggle-groups-panel').textContent = open ? '>' : 'v';
  });

  // Actions
  document.getElementById('btn-clone').addEventListener('click', cloneSelected);
  document.getElementById('btn-del').addEventListener('click', deleteSelected);
  document.getElementById('btn-cut').addEventListener('click', () => {
    if (E.cutMode) cancelCut();
    else beginCut();
  });
  document.getElementById('btn-set-pivot').addEventListener('click', () => {
    if (E.pivotMode) cancelPivot();
    else beginPivot();
  });
  document.getElementById('btn-reset-pivot').addEventListener('click', resetPivot);
  document.getElementById('btn-merge').addEventListener('click', openMergeDialog);
  document.getElementById('btn-export-uv').addEventListener('click', e => {
    e.stopPropagation();
    const menu = document.getElementById('export-maps-menu');
    if (!menu) { exportUVMap(); return; }
    menu.style.display = menu.style.display === 'none' ? '' : 'none';
  });
  document.getElementById('export-maps-menu')?.querySelectorAll('[data-maptype]').forEach(btn => {
    btn.addEventListener('click', () => {
      const t = btn.dataset.maptype;
      document.getElementById('export-maps-menu').style.display = 'none';
      if (t === 'uv') exportUVMap(false);
      else if (t === 'uv-clean') exportUVMap(true);
      else exportRawMap(t);
    });
  });
  document.addEventListener('click', () => {
    const menu = document.getElementById('export-maps-menu');
    if (menu) menu.style.display = 'none';
  });
  document.getElementById('btn-face-mode').addEventListener('click', () => { if (E.faceModeActive) exitFaceMode(); else enterFaceMode(); });
  document.getElementById('btn-merge-confirm').addEventListener('click', executeMerge);
  document.getElementById('btn-merge-modal-close').addEventListener('click', closeMergeDialog);

  // Scene list collapse
  document.getElementById('btn-toggle-scene-list').addEventListener('click', () => {
    const wrap = document.getElementById('scene-list-wrap');
    const open = wrap.style.display !== 'none';
    wrap.style.display = open ? 'none' : '';
    document.getElementById('btn-toggle-scene-list').textContent = open ? '>' : 'v';
    const ss = document.getElementById('scene-search');
    if (ss) ss.style.display = open ? 'none' : '';
  });

  // Left panel search — filters models, image models, actors
  document.getElementById('left-search')?.addEventListener('input', e => {
    const q = e.target.value.trim().toLowerCase();
    document.querySelectorAll('#palette-list .model-item, #image-model-list .image-model-item, #actor-list .actor-item').forEach(el => {
      el.style.display = (!q || el.textContent.toLowerCase().includes(q)) ? '' : 'none';
    });
  });

  // Scene list search
  document.getElementById('scene-search')?.addEventListener('input', e => {
    const q = e.target.value.trim().toLowerCase();
    document.querySelectorAll('#scene-list .scene-list-item').forEach(el => {
      el.style.display = (!q || el.textContent.toLowerCase().includes(q)) ? '' : 'none';
    });
  });

  document.getElementById('toggle-triggers-visible')?.addEventListener('change', e => {
    const visible = e.target.checked;
    E.placedGroup.traverse(o => {
      if (isTriggerType(o.userData.primType)) o.visible = visible;
    });
  });

  // Actor import
  document.getElementById('btn-set-spawn')?.addEventListener('click', () => {
    const existing = E.placedGroup.children.find(o => o.userData.primType === 'player-spawn');
    const p = E.camera.position;
    if (existing) {
      pushUndo();
      existing.position.set(p.x, p.y, p.z);
      markDirty();
    } else {
      pushUndo();
      const id = E.nextId++;
      spawnPrimFromEntry({
        id, label: 'player_spawn', type: 'player-spawn',
        pos: [+p.x.toFixed(3), +p.y.toFixed(3), +p.z.toFixed(3)],
        rot: [0, 0, 0], size: [1, 1, 1], collidable: false,
      });
      markDirty();
    }
    updateSceneList();
  });
  document.getElementById('btn-clear-spawn')?.addEventListener('click', () => {
    const existing = E.placedGroup.children.find(o => o.userData.primType === 'player-spawn');
    if (existing) {
      pushUndo();
      E.placedGroup.remove(existing);
      if (E.selected === existing) { E.transform.detach(); E.selected = null; updateProps(null); }
      markDirty();
      updateSceneList();
    }
  });

  document.getElementById('fog-density')?.addEventListener('change', (e) => {
    pushUndo();
    const v = parseFloat(e.target.value);
    E.fogDensity = isNaN(v) || e.target.value.trim() === '' ? null : Math.max(0, v);
    markDirty();
  });
  document.getElementById('btn-fog-clear')?.addEventListener('click', () => {
    pushUndo();
    E.fogDensity = null;
    _updateFogInput();
    markDirty();
  });

  document.getElementById('btn-import-actor')?.addEventListener('click', async () => {
    if (!window.electron?.importActor) { setStatus('Actor import requires Electron'); return; }
    const p = await window.electron.importActor();
    if (p) {
      await refreshActorList();
      setStatus(`Imported actor: ${p.split(/[\\/]/).pop()}`);
    }
  });

  // Actor spawn property inputs
  document.getElementById('actor-spawn-radius')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('actor-spawn-radius')?.addEventListener('input', e => {
    if (E.selected?.userData.primType === 'actor-spawn') {
      E.selected.userData.spawnRadius = parseFloat(e.target.value) || 0;
      markDirty();
    }
  });
  document.getElementById('actor-persistent')?.addEventListener('change', e => {
    if (E.selected?.userData.primType === 'actor-spawn') {
      pushUndo();
      E.selected.userData.persistent = e.target.checked;
      markDirty();
    }
  });
  document.getElementById('actor-single-instance')?.addEventListener('change', e => {
    if (E.selected?.userData.primType === 'actor-spawn') {
      pushUndo();
      E.selected.userData.singleInstance = e.target.checked;
      markDirty();
    }
  });

  // Actor modal buttons
  document.getElementById('btn-actor-mesh-edit')?.addEventListener('click', openActorMeshEditor);
  document.getElementById('btn-actor-anims')?.addEventListener('click', openActorAnimsModal);
  document.getElementById('btn-actor-mesh-close')?.addEventListener('click', closeActorMeshEditor);
  document.getElementById('btn-actor-anims-close')?.addEventListener('click', closeActorAnimsModal);
  document.getElementById('btn-actor-import-anim')?.addEventListener('click', async () => {
    const obj = E.selected;
    if (!obj || obj.userData.primType !== 'actor-spawn') return;
    if (!window.electron?.importActorAnim) return;
    const filePath = await window.electron.importActorAnim(obj.userData.actorModel);
    if (!filePath) return;
    pushUndo();
    if (!obj.userData.animations) obj.userData.animations = [];
    const clipName = filePath.split('/').pop().replace(/\.[^.]+$/, '');
    obj.userData.animations.push({ name: clipName, file: filePath });
    _refreshActorAnimsList(obj);
    markDirty();
  });
  document.getElementById('btn-actor-variants')?.addEventListener('click', openActorVariantsModal);
  document.getElementById('btn-actor-variants-close')?.addEventListener('click', closeActorVariantsModal);
  document.getElementById('btn-actor-add-variant')?.addEventListener('click', () => {
    const obj = E.selected;
    if (!obj || obj.userData.primType !== 'actor-spawn') return;
    pushUndo();
    if (!Array.isArray(obj.userData.actorVariants)) obj.userData.actorVariants = [];
    obj.userData.actorVariants.push({ model: obj.userData.actorModel || '', weight: 1 });
    _refreshActorVariantsList(obj);
    markDirty();
  });
  document.getElementById('btn-actor-pick-model')?.addEventListener('click', () => {
    openActorModelPicker(result => {
      const obj = E.selected;
      if (!obj || obj.userData.primType !== 'actor-spawn') return;
      pushUndo();
      obj.userData.actorModel   = result.model;
      obj.userData.actorSourceId = result.sourceId;
      const el = document.getElementById('actor-spawn-model-name');
      if (el) el.textContent = result.model.split('/').pop() || '-';
      markDirty();
    });
  });
  document.getElementById('btn-actor-model-picker-close')?.addEventListener('click', () => {
    document.getElementById('actor-model-picker').style.display = 'none';
    E._actorModelPickerCallback = null;
  });
  document.getElementById('btn-actor-ai')?.addEventListener('click', () => {
    document.getElementById('actor-ai-modal').style.display = '';
  });
  document.getElementById('btn-actor-pathfinding')?.addEventListener('click', () => {
    document.getElementById('actor-pathfinding-modal').style.display = '';
  });
  document.getElementById('btn-actor-ai-close')?.addEventListener('click', () => {
    document.getElementById('actor-ai-modal').style.display = 'none';
  });
  document.getElementById('btn-actor-pathfinding-close')?.addEventListener('click', () => {
    document.getElementById('actor-pathfinding-modal').style.display = 'none';
  });

  const _actorNumProp = (id, prop) => {
    document.getElementById(id)?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
    document.getElementById(id)?.addEventListener('input', e => {
      if (E.selected?.userData.primType !== 'actor-spawn') return;
      const v = e.target.value.trim();
      E.selected.userData[prop] = v === '' ? null : parseFloat(v);
      markDirty();
    });
  };
  _actorNumProp('actor-spawn-interval', 'actorSpawnInterval');
  _actorNumProp('actor-spawn-max',      'actorSpawnMax');
  _actorNumProp('actor-health',         'actorHealth');
  _actorNumProp('actor-speed',          'actorSpeed');
  _actorNumProp('actor-damage',         'actorDamage');
  _actorNumProp('actor-crit',           'actorCrit');

  // Wall buy weapon definition inputs
  const _wbStr = (id, prop) => {
    document.getElementById(id)?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
    document.getElementById(id)?.addEventListener('input', e => {
      if (E.selected?.userData.primType !== 'zom-wallbuy') return;
      if (!E.selected.userData.weaponDef) E.selected.userData.weaponDef = {};
      E.selected.userData.weaponDef[prop] = e.target.value;
      markDirty();
    });
  };
  document.getElementById('wb-slug')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('wb-slug')?.addEventListener('input', e => {
    if (E.selected?.userData.primType !== 'zom-wallbuy') return;
    E.selected.userData.weaponSlug = e.target.value;
    markDirty();
  });
  const _wbNum = (id, prop, topLevel = false) => {
    document.getElementById(id)?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
    document.getElementById(id)?.addEventListener('input', e => {
      if (E.selected?.userData.primType !== 'zom-wallbuy') return;
      const v = parseFloat(e.target.value);
      if (isNaN(v)) return;
      if (topLevel) {
        E.selected.userData[prop] = v;
        if (prop === 'weaponModelOpacity') {
          const preview = E.selected.children.find(c => c.userData.isWbModelPreview);
          if (preview) preview.traverse(c => { if (c.isMesh && c.material) { (Array.isArray(c.material) ? c.material : [c.material]).forEach(m => { m.transparent = v < 1; m.opacity = v; m.needsUpdate = true; }); } });
        }
      }
      else { if (!E.selected.userData.weaponDef) E.selected.userData.weaponDef = {}; E.selected.userData.weaponDef[prop] = v; }
      markDirty();
    });
  };
  _wbStr('wb-label', 'label');
  _wbNum('wb-cost',      'wallBuyCost',    true);
  _wbNum('wb-ammo-cost', 'wallBuyAmmoCost',true);
  _wbNum('wb-damage',    'damage');
  _wbNum('wb-clip',      'clipSize');
  _wbNum('wb-reserve',   'reserveAmmo');
  _wbNum('wb-reload',    'reloadTime');
  _wbNum('wb-firerate',  'fireRate');
  _wbNum('wb-spread',    'spreadAngle');
  _wbNum('wb-pellets',   'pelletsPerShot');
  _wbNum('wb-model-opacity', 'weaponModelOpacity', true);
  document.getElementById('wb-auto')?.addEventListener('change', e => {
    if (E.selected?.userData.primType !== 'zom-wallbuy') return;
    pushUndo();
    if (!E.selected.userData.weaponDef) E.selected.userData.weaponDef = {};
    E.selected.userData.weaponDef.isAuto = e.target.checked;
    markDirty();
  });
  document.getElementById('btn-wb-pick-model')?.addEventListener('click', async () => {
    if (!E.selected || E.selected.userData.primType !== 'zom-wallbuy') return;
    if (!window.electron?.importModel) return;
    const p = await window.electron.importModel();
    if (!p) return;
    pushUndo();
    E.selected.userData.weaponModelPath = p;
    const el = document.getElementById('wb-model-name');
    if (el) el.textContent = p.split('/').pop() || p;
    _attachWallBuyModel(E.selected);
    markDirty();
  });
  document.getElementById('btn-wb-clear-model')?.addEventListener('click', () => {
    if (E.selected?.userData.primType !== 'zom-wallbuy') return;
    pushUndo();
    E.selected.userData.weaponModelPath = '';
    const el = document.getElementById('wb-model-name');
    if (el) el.textContent = '-';
    _attachWallBuyModel(E.selected);
    markDirty();
  });

  // Zombie spawn inputs
  const _zsNum = (id, prop) => {
    document.getElementById(id)?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
    document.getElementById(id)?.addEventListener('input', e => {
      if (E.selected?.userData.primType !== 'zombie-spawn') return;
      const v = e.target.value.trim();
      E.selected.userData[prop] = v === '' ? null : parseFloat(v);
      markDirty();
    });
  };
  _zsNum('zs-radius',    'spawnRadius');
  _zsNum('zs-round-min', 'roundMin');
  _zsNum('zs-round-max', 'roundMax');
  document.getElementById('btn-zs-pick-model')?.addEventListener('click', async () => {
    if (!E.selected || E.selected.userData.primType !== 'zombie-spawn') return;
    if (!window.electron?.importActorModel) return;
    const p = await window.electron.importActorModel();
    if (!p) return;
    pushUndo();
    E.selected.userData.actorModel = p;
    const el = document.getElementById('zs-model-name');
    if (el) el.textContent = p.split('/').pop() || p;
    markDirty();
  });

  // Perk inputs
  document.getElementById('perk-id')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('perk-id')?.addEventListener('input', e => {
    if (E.selected?.userData.primType !== 'zom-perk') return;
    E.selected.userData.perkId = e.target.value;
    markDirty();
  });
  document.getElementById('perk-cost')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('perk-cost')?.addEventListener('input', e => {
    if (E.selected?.userData.primType !== 'zom-perk') return;
    const v = parseFloat(e.target.value);
    E.selected.userData.perkCost = isNaN(v) ? null : v;
    markDirty();
  });
  document.getElementById('perk-require-power')?.addEventListener('change', e => {
    if (E.selected?.userData.primType !== 'zom-perk') return;
    pushUndo();
    E.selected.userData.requirePower = e.target.checked;
    markDirty();
  });

  // Mystery box inputs
  document.getElementById('mystery-cost')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('mystery-cost')?.addEventListener('input', e => {
    if (E.selected?.userData.primType !== 'zom-mystery') return;
    const v = parseFloat(e.target.value);
    E.selected.userData.mysteryBoxCost = isNaN(v) ? null : v;
    markDirty();
  });
  document.getElementById('mystery-pool')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('mystery-pool')?.addEventListener('input', e => {
    if (E.selected?.userData.primType !== 'zom-mystery') return;
    E.selected.userData.weaponPool = e.target.value.split('\n').map(s => s.trim()).filter(Boolean);
    markDirty();
  });

  // Pack-a-Punch inputs
  document.getElementById('pap-tiers')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('pap-tiers')?.addEventListener('input', e => {
    if (E.selected?.userData.primType !== 'zom-pap') return;
    const v = parseInt(e.target.value, 10);
    E.selected.userData.tierCount = isNaN(v) ? null : v;
    markDirty();
  });
  document.getElementById('pap-require-power')?.addEventListener('change', e => {
    if (E.selected?.userData.primType !== 'zom-pap') return;
    pushUndo();
    E.selected.userData.requirePower = e.target.checked;
    markDirty();
  });

  // Ammo station input
  document.getElementById('ammo-cost')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('ammo-cost')?.addEventListener('input', e => {
    if (E.selected?.userData.primType !== 'zom-ammo') return;
    E.selected.userData.ammoCost = parseFloat(e.target.value) || 500;
    markDirty();
  });

  // Door input
  document.getElementById('door-cost')?.addEventListener('focus', () => { if (E.selected) pushUndo(); });
  document.getElementById('door-cost')?.addEventListener('input', e => {
    if (E.selected?.userData.primType !== 'zom-door') return;
    E.selected.userData.doorCost = parseFloat(e.target.value) || 750;
    markDirty();
  });

  // Zombies tree toggle
  document.getElementById('zombies-prim-header')?.addEventListener('click', () => {
    const tree  = document.getElementById('zombies-prim-tree');
    const arrow = document.getElementById('zombies-prim-arrow');
    if (!tree) return;
    const open = tree.style.display === 'none';
    tree.style.display  = open ? '' : 'none';
    if (arrow) arrow.innerHTML = open ? '&#9660;' : '&#9654;';
  });

  window.addEventListener('resize', resizeRenderer);

  // Zombies map settings modal
  function _openZombiesSettings() {
    const modal = document.getElementById('zombies-settings-modal');
    if (!modal) return;
    const cfg = E.zombiesConfig ?? {};
    const setV = (id, val, fallback) => {
      const el = document.getElementById(id);
      if (el) el.value = (val !== undefined && val !== null) ? val : (fallback !== undefined ? fallback : '');
    };
    const chk = document.getElementById('zms-is-zombies-map');
    if (chk) chk.checked = !!E.isZombiesMap;
    const dnEl = document.getElementById('zms-display-name');
    if (dnEl) dnEl.value = E.zombiesMapDisplayName ?? '';
    setV('zms-base-hp',        cfg.baseZombieHp);
    setV('zms-hp-scale',       cfg.hpScale);
    setV('zms-base-dmg',       cfg.baseDamage);
    setV('zms-dmg-scale',      cfg.dmgScale);
    setV('zms-base-count',     cfg.baseZombiesPerRound);
    setV('zms-count-mult',     cfg.zombiesPerRoundMult);
    setV('zms-count-cap',      cfg.zombiesPerRoundCap);
    setV('zms-round-cap',      cfg.roundCap);
    setV('zms-spawn-interval', cfg.baseSpawnInterval);
    setV('zms-spawn-decay',    cfg.spawnIntervalDecay);
    setV('zms-min-interval',   cfg.minSpawnInterval);
    setV('zms-inter-round',    cfg.interRoundDelay);
    setV('zms-start-pts',      cfg.startingPoints);
    setV('zms-pts-kill',       cfg.pointsPerKill);
    setV('zms-kill-scale',     cfg.killScalePerRound);
    setV('zms-round-bonus',    cfg.endRoundBonus);
    setV('zms-hs-bonus',       cfg.headShotBonus);
    setV('zms-melee-bonus',    cfg.meleeBonus);
    setV('zms-mystery-cost',   cfg.mysteryBoxCost);
    setV('zms-drop-chance',    cfg.dropChancePerKill);
    setV('zms-powerup-dur',    cfg.powerupDuration);
    setV('zms-revive-time',    cfg.reviveTime);

    const DEFAULT_PAP_TIERS = [
      { cost: 5000,  damageMult: 2.0 },
      { cost: 10000, damageMult: 3.5 },
      { cost: 20000, damageMult: 6.0 },
      { cost: 40000, damageMult: 10.0 },
      { cost: 80000, damageMult: 16.0 },
    ];
    const papTiers = cfg.papTiers?.length ? cfg.papTiers : DEFAULT_PAP_TIERS;
    const tiersEl = document.getElementById('zms-pap-tiers');
    if (tiersEl) {
      tiersEl.innerHTML = '';
      papTiers.forEach((t, i) => {
        const row = document.createElement('div');
        row.className = 'prop-row pap-tier-row';
        row.style.cssText = 'gap:6px';
        row.innerHTML = `<label style="font-size:10px;color:#666688;min-width:54px">Tier ${i + 1}</label>`
          + `<input class="prop-input pap-cost" type="number" step="500" placeholder="Cost" value="${t.cost ?? ''}" style="flex:1;font-size:11px">`
          + `<input class="prop-input pap-dmg" type="number" step="0.25" placeholder="DmgMult" value="${t.damageMult ?? ''}" style="flex:1;font-size:11px">`
          + `<input class="prop-input pap-clip" type="number" step="0.25" placeholder="ClipMult" value="${t.clipMult ?? ''}" style="flex:1;font-size:11px">`;
        tiersEl.appendChild(row);
      });
    }

    modal.style.display = 'flex';
  }
  document.getElementById('btn-zms-add-tier')?.addEventListener('click', () => {
    const tiersEl = document.getElementById('zms-pap-tiers');
    if (!tiersEl || tiersEl.children.length >= 5) return;
    const i = tiersEl.children.length;
    const row = document.createElement('div');
    row.className = 'prop-row pap-tier-row';
    row.style.cssText = 'gap:6px';
    row.innerHTML = `<label style="font-size:10px;color:#666688;min-width:54px">Tier ${i + 1}</label>`
      + `<input class="prop-input pap-cost" type="number" step="500" placeholder="Cost" style="flex:1;font-size:11px">`
      + `<input class="prop-input pap-dmg" type="number" step="0.25" placeholder="DmgMult" style="flex:1;font-size:11px">`
      + `<input class="prop-input pap-clip" type="number" step="0.25" placeholder="ClipMult" style="flex:1;font-size:11px">`;
    tiersEl.appendChild(row);
  });
  document.getElementById('btn-zms-remove-tier')?.addEventListener('click', () => {
    const tiersEl = document.getElementById('zms-pap-tiers');
    if (tiersEl && tiersEl.children.length > 1) tiersEl.removeChild(tiersEl.lastChild);
  });
  function _applyZombiesSettings() {
    const modal = document.getElementById('zombies-settings-modal');
    pushUndo();
    const getN = id => { const el = document.getElementById(id); if (!el || el.value.trim() === '') return undefined; return parseFloat(el.value); };
    const getI = id => { const el = document.getElementById(id); if (!el || el.value.trim() === '') return undefined; return parseInt(el.value, 10); };
    E.isZombiesMap = document.getElementById('zms-is-zombies-map')?.checked ?? false;
    const dn = document.getElementById('zms-display-name')?.value.trim();
    E.zombiesMapDisplayName = dn || null;
    const cfg = { ...(E.zombiesConfig ?? {}) };
    const _set = (k, v) => { if (v !== undefined && !isNaN(v)) cfg[k] = v; };
    _set('baseZombieHp',        getN('zms-base-hp'));
    _set('hpScale',             getN('zms-hp-scale'));
    _set('baseDamage',          getN('zms-base-dmg'));
    _set('dmgScale',            getN('zms-dmg-scale'));
    _set('baseZombiesPerRound', getI('zms-base-count'));
    _set('zombiesPerRoundMult', getN('zms-count-mult'));
    _set('zombiesPerRoundCap',  getI('zms-count-cap'));
    _set('roundCap',            getI('zms-round-cap'));
    _set('baseSpawnInterval',   getN('zms-spawn-interval'));
    _set('spawnIntervalDecay',  getN('zms-spawn-decay'));
    _set('minSpawnInterval',    getN('zms-min-interval'));
    _set('interRoundDelay',     getN('zms-inter-round'));
    _set('startingPoints',      getI('zms-start-pts'));
    _set('pointsPerKill',       getI('zms-pts-kill'));
    _set('killScalePerRound',   getN('zms-kill-scale'));
    _set('endRoundBonus',       getI('zms-round-bonus'));
    _set('headShotBonus',       getI('zms-hs-bonus'));
    _set('meleeBonus',          getI('zms-melee-bonus'));
    _set('mysteryBoxCost',      getI('zms-mystery-cost'));
    _set('dropChancePerKill',   getN('zms-drop-chance'));
    _set('powerupDuration',     getN('zms-powerup-dur'));
    _set('reviveTime',          getN('zms-revive-time'));

    const papTierRows = document.querySelectorAll('#zms-pap-tiers .pap-tier-row');
    const papTiers = [];
    papTierRows.forEach(row => {
      const cost    = parseFloat(row.querySelector('.pap-cost')?.value);
      const dmgMult = parseFloat(row.querySelector('.pap-dmg')?.value);
      const clipMult = parseFloat(row.querySelector('.pap-clip')?.value);
      if (!isNaN(cost) && !isNaN(dmgMult)) {
        const tier = { cost, damageMult: dmgMult };
        if (!isNaN(clipMult)) tier.clipMult = clipMult;
        papTiers.push(tier);
      }
    });
    if (papTiers.length > 0) cfg.papTiers = papTiers; else delete cfg.papTiers;

    E.zombiesConfig = Object.keys(cfg).length ? cfg : null;
    if (modal) modal.style.display = 'none';
    markDirty();
  }
  document.getElementById('btn-zms-close')?.addEventListener('click',  () => { document.getElementById('zombies-settings-modal').style.display = 'none'; });
  document.getElementById('btn-zms-cancel')?.addEventListener('click', () => { document.getElementById('zombies-settings-modal').style.display = 'none'; });
  document.getElementById('btn-zms-apply')?.addEventListener('click',  _applyZombiesSettings);
  window.electron?.onMenuAction?.('open-zombies-settings', _openZombiesSettings);
}

function setTransformMode(mode) {
  E.transform.setMode(mode);
  document.getElementById('btn-move').classList.toggle('active',   mode === 'translate');
  document.getElementById('btn-rotate').classList.toggle('active', mode === 'rotate');
  document.getElementById('btn-scale').classList.toggle('active',  mode === 'scale');
  updateTransformSnap(); // re-evaluate snap for new mode
}

// Update TransformControls translation snap based on Ctrl key state.
// Called on keydown, keyup, and mode change.
function updateTransformSnap() {
  const ctrl = E.keys['ControlLeft'] || E.keys['ControlRight'];
  E.transform.setTranslationSnap(ctrl ? 0.25 : null);
}

// Snap obj's nearest face to the nearest face of any other placed mesh (Alt-snap).
// Each axis is evaluated independently so e.g. floor-snap (Y) doesn't block wall-snap (X).
function snapToNearestFace(obj) {
  const THRESHOLD = 0.35;
  const box = new THREE.Box3().setFromObject(obj);
  const best = { x: null, y: null, z: null };

  E.placedGroup.children.forEach(other => {
    if (other === obj || other.userData.isEditorHelper || other.userData.isLightGroup) return;
    const otherBox = new THREE.Box3().setFromObject(other);
    ['x','y','z'].forEach(axis => {
      const perp = axis === 'x' ? ['y','z'] : axis === 'y' ? ['x','z'] : ['x','y'];
      // Only snap faces that actually overlap in the perpendicular axes
      if (box.max[perp[0]] <= otherBox.min[perp[0]] || box.min[perp[0]] >= otherBox.max[perp[0]]) return;
      if (box.max[perp[1]] <= otherBox.min[perp[1]] || box.min[perp[1]] >= otherBox.max[perp[1]]) return;
      // selected +face vs other -face
      const d1 = Math.abs(box.max[axis] - otherBox.min[axis]);
      if (d1 < THRESHOLD && (!best[axis] || d1 < best[axis].dist))
        best[axis] = { delta: otherBox.min[axis] - box.max[axis], dist: d1 };
      // selected -face vs other +face
      const d2 = Math.abs(box.min[axis] - otherBox.max[axis]);
      if (d2 < THRESHOLD && (!best[axis] || d2 < best[axis].dist))
        best[axis] = { delta: otherBox.max[axis] - box.min[axis], dist: d2 };
    });
  });

  let snapped = false;
  ['x','y','z'].forEach(axis => {
    if (best[axis]) { obj.position[axis] += best[axis].delta; snapped = true; }
  });
  if (snapped) obj.updateMatrixWorld(true);
}

// â”€â”€â”€ Collider helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function updateColliderHelpers() {
  E.colHelpers.forEach(h => E.scene.remove(h));
  E.colHelpers = [];
  if (!E.showColliders) return;
  E.placedGroup.children.forEach(obj => {
    if (!obj.userData.collidable || obj.userData.isEditorHelper || obj.userData.isLightGroup) return;
    const h = new THREE.BoxHelper(obj, 0x00ffcc);
    h.userData.isEditorHelper = true;
    E.scene.add(h);
    E.colHelpers.push(h);
  });
}

// â”€â”€â”€ Keyboard â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function setupKeys() {
  window.addEventListener('keydown', e => {
    if (e.ctrlKey && e.code === 'KeyS')                         { e.preventDefault(); saveLevel(); return; }
    if (e.ctrlKey && !e.shiftKey && e.code === 'KeyZ')          { e.preventDefault(); undo(); return; }
    if (e.ctrlKey && (e.shiftKey && e.code === 'KeyZ' || e.code === 'KeyY')) { e.preventDefault(); redo(); return; }

    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
    if (e.code === 'Space') e.preventDefault(); // prevent page scroll
    E.keys[e.code] = true;

    if (e.ctrlKey && e.code === 'KeyD')                         { e.preventDefault(); cloneSelected(); return; }

    if (e.ctrlKey && e.code === 'KeyW') { e.preventDefault(); setTransformMode('translate'); return; }
    if (e.ctrlKey && e.code === 'KeyE') { e.preventDefault(); setTransformMode('rotate');    return; }
    if (e.ctrlKey && e.code === 'KeyR') { e.preventDefault(); setTransformMode('scale');     return; }

    if (e.code === 'KeyG') {
      if (E.groupPivot) finalizeGroupTransform();
      else { const gid = findGroupOfObj(E.selected); if (gid) beginGroupTransform(gid); }
    }

    if (e.code === 'KeyX') {
      if (E.cutMode) cancelCut();
      else beginCut();
    }

    if (e.code === 'Delete' || e.code === 'Backspace') deleteSelected();

    if (e.code === 'KeyF') {
      if (E.faceModeActive) exitFaceMode();
      else enterFaceMode();
      return;
    }

    if (e.code === 'Escape') {
      if (_rulerState.active) { _rulerExit(); return; }
      if (E.faceModeActive)  { exitFaceMode(); return; }
      if (E.facePickMode){ cancelFacePick(); return; }
      if (E.pivotMode)   { cancelPivot(); return; }
      if (E.linkMode)    { cancelLink(); return; }
      if (E.ropeAnchorMode) { cancelRopeAnchor(); return; }
      if (E.cutMode)     { cancelCut(); return; }
      if (E.placingType) { cancelPlace(); return; }
      if (E.groupPivot)  { finalizeGroupTransform(); return; }
      deselect();
    }
    updateTransformSnap();
  });
  window.addEventListener('keyup', e => {
    delete E.keys[e.code];
    updateTransformSnap();
  });
  window.addEventListener('blur', () => {
    E.keys = {};
    updateTransformSnap();
  });
}

// â”€â”€â”€ Mouse â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const _ray  = new THREE.Raycaster();
const _ndcM = new THREE.Vector2();

function mouseToNDC(e) {
  const vp   = document.getElementById('viewport');
  const rect = vp.getBoundingClientRect();
  _ndcM.x =  ((e.clientX - rect.left) / rect.width)  * 2 - 1;
  _ndcM.y = -((e.clientY - rect.top)  / rect.height) * 2 + 1;
}

function worldFromMouse(e) {
  mouseToNDC(e);
  _ray.setFromCamera(_ndcM, E.camera);
  const hits = _ray.intersectObject(E.floorPlane);
  if (hits.length) return hits[0].point.clone();
  // fallback if camera is looking straight down
  const dir = _ray.ray.direction, o = _ray.ray.origin;
  const t = -o.y / dir.y;
  return t > 0 ? o.clone().addScaledVector(dir, t) : null;
}

// ─── Ruler tool ───────────────────────────────────────────────────────────────
// Reference: 1 Three.js unit ≈ 20 inches (calibrated to standard 80" interior door)
const INCHES_PER_UNIT = 20;

const _rulerState = { active: false, dragging: false, start: null, end: null };
let   _rulerLine  = null;
let   _rulerTicks = null;

function _rulerRaycast(e) {
  mouseToNDC(e);
  _ray.setFromCamera(_ndcM, E.camera);
  const candidates = [];
  E.placedGroup.traverse(o => { if (o.isMesh && !o.userData.isEditorHelper && o.visible) candidates.push(o); });
  if (E.groupPivot) E.groupPivot.traverse(o => { if (o.isMesh && !o.userData.isEditorHelper && o.visible) candidates.push(o); });
  const hits = _ray.intersectObjects(candidates, false);
  if (hits.length) return hits[0].point.clone();
  const floorHits = _ray.intersectObject(E.floorPlane);
  if (floorHits.length) return floorHits[0].point.clone();
  return null;
}

function _rulerClearScene() {
  if (_rulerLine)  { E.scene.remove(_rulerLine);  _rulerLine.geometry.dispose();  _rulerLine.material.dispose();  _rulerLine = null; }
  if (_rulerTicks) { E.scene.remove(_rulerTicks); _rulerTicks.geometry.dispose(); _rulerTicks.material.dispose(); _rulerTicks = null; }
}

function _rulerUpdate(start, end) {
  _rulerClearScene();
  if (!start || !end) return;

  const dist       = start.distanceTo(end);
  const totalInch  = dist * INCHES_PER_UNIT;
  const feet       = Math.floor(totalInch / 12);
  const inches     = totalInch - feet * 12;
  const readout    = feet > 0 ? `${feet}' ${inches.toFixed(1)}"  (${totalInch.toFixed(1)}")` : `${inches.toFixed(1)}"`;

  const rEl = document.getElementById('ruler-readout');
  if (rEl) { rEl.textContent = readout; rEl.style.display = 'block'; }

  // Main line
  const lineMat = new THREE.LineBasicMaterial({ color: 0xffee44, depthTest: false });
  const lineGeo = new THREE.BufferGeometry().setFromPoints([start, end]);
  _rulerLine = new THREE.Line(lineGeo, lineMat);
  _rulerLine.renderOrder = 999;
  E.scene.add(_rulerLine);

  // Tick marks at every foot along the line
  const dir = end.clone().sub(start).normalize();
  const perp = new THREE.Vector3(-dir.z, 0, dir.x).normalize();
  if (perp.lengthSq() < 0.001) perp.set(0, 1, 0);
  const FOOT_UNITS = 12 / INCHES_PER_UNIT;
  const tickPoints = [];
  const tickCount  = Math.floor(dist / FOOT_UNITS);
  for (let i = 1; i <= tickCount; i++) {
    const p = start.clone().addScaledVector(dir, i * FOOT_UNITS);
    const hs = i % 12 === 0 ? 0.12 : (i % 3 === 0 ? 0.08 : 0.05);
    tickPoints.push(p.clone().addScaledVector(perp, -hs), p.clone().addScaledVector(perp, hs));
  }
  if (tickPoints.length) {
    const tickGeo = new THREE.BufferGeometry().setFromPoints(tickPoints);
    const tickMat = new THREE.LineSegmentsGeometry ? undefined : new THREE.LineBasicMaterial({ color: 0xffee44, depthTest: false });
    _rulerTicks = new THREE.LineSegments(tickGeo, tickMat ?? new THREE.LineBasicMaterial({ color: 0xffee44, depthTest: false }));
    _rulerTicks.renderOrder = 999;
    E.scene.add(_rulerTicks);
  }
}

function _rulerExit() {
  _rulerState.active   = false;
  _rulerState.dragging = false;
  _rulerState.start    = null;
  _rulerState.end      = null;
  _rulerClearScene();
  const rEl = document.getElementById('ruler-readout');
  if (rEl) rEl.style.display = 'none';
  document.getElementById('btn-ruler')?.classList.remove('active');
  document.getElementById('viewport')?.style?.setProperty('cursor', '');
}

function setupRuler() {
  document.getElementById('btn-ruler').addEventListener('click', () => {
    if (_rulerState.active) { _rulerExit(); return; }
    _rulerState.active = true;
    document.getElementById('btn-ruler').classList.add('active');
    document.getElementById('viewport').style.cursor = 'crosshair';
    setStatus('Ruler: click and drag to measure. Click again to reset. Esc to exit.');
  });

  const vp = document.getElementById('viewport');

  vp.addEventListener('mousedown', e => {
    if (!_rulerState.active || e.button !== 0) return;
    const pt = _rulerRaycast(e);
    if (!pt) return;
    e.stopPropagation();
    _rulerState.dragging = true;
    _rulerState.start    = pt;
    _rulerState.end      = pt.clone();
    _rulerUpdate(_rulerState.start, _rulerState.end);
  }, true);

  vp.addEventListener('mousemove', e => {
    if (!_rulerState.active || !_rulerState.dragging) return;
    const pt = _rulerRaycast(e);
    if (!pt) return;
    _rulerState.end = pt;
    _rulerUpdate(_rulerState.start, _rulerState.end);
  }, true);

  vp.addEventListener('mouseup', e => {
    if (!_rulerState.active || e.button !== 0) return;
    _rulerState.dragging = false;
  }, true);
}

function setupMouse() {
  const vp = document.getElementById('viewport');

  vp.addEventListener('mousemove', e => {
    if (E.faceModeActive) { _faceModeHover(e); }
    if (!E.ghostMesh) return;
    const pos = worldFromMouse(e);
    if (pos) {
      E.ghostMesh.position.set(
        Math.round(pos.x * 4) / 4,
        0.5,      // slightly above floor
        Math.round(pos.z * 4) / 4
      );
    }
  });

  let _speedHudTimer = null;
  function _showSpeedHud() {
    let hud = document.getElementById('__pan-speed-hud__');
    if (!hud) {
      hud = document.createElement('div');
      hud.id = '__pan-speed-hud__';
      hud.style.cssText = 'position:fixed;bottom:48px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,0.7);color:#fff;font-size:13px;padding:5px 14px;border-radius:6px;pointer-events:none;z-index:9999;transition:opacity 0.3s';
      document.body.appendChild(hud);
    }
    hud.textContent = `Camera speed: ${E.panSpeed.toFixed(1)}`;
    hud.style.opacity = '1';
    clearTimeout(_speedHudTimer);
    _speedHudTimer = setTimeout(() => { hud.style.opacity = '0'; }, 1200);
  }

  vp.addEventListener('wheel', e => {
    if (!(e.ctrlKey || E.keys['ControlLeft'] || E.keys['ControlRight'])) return;
    e.preventDefault();
    e.stopPropagation();
    const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
    E.panSpeed = Math.max(0.5, Math.min(200, E.panSpeed * factor));
    _showSpeedHud();
  }, { passive: false, capture: true });

  vp.addEventListener('click', e => {
    if (e.button !== 0) return;

    // Placement commit
    if (E.placingType) {
      const pos = worldFromMouse(e);
      if (pos) commitPlace(new THREE.Vector3(
        Math.round(pos.x * 4) / 4, 0,
        Math.round(pos.z * 4) / 4
      ));
      return;
    }

    if (E.wasDragging) return;

    // Face mode click — intercept before normal selection
    if (E.faceModeActive) {
      _faceModeClick();
      return;
    }

    // Selection - only placed objects, not ref
    mouseToNDC(e);
    _ray.setFromCamera(_ndcM, E.camera);

    // Bone marker click — check first when model editor is open
    if (E._modelEditorObj && E._boneMarkerGroup) {
      const boneMarkers = [];
      E._boneMarkerGroup.traverse(o => { if (o.isMesh) boneMarkers.push(o); });
      const boneHits = _ray.intersectObjects(boneMarkers, false);
      if (boneHits.length) {
        selectBone(boneHits[0].object.userData.boneId);
        return;
      }
    }

    const candidates = [];
    E.placedGroup.traverse(o => { if (o.isMesh && !o.userData.isEditorHelper && o.visible) candidates.push(o); });
    // When group pivot is active its members live under E.groupPivot, not E.placedGroup.
    if (E.groupPivot) E.groupPivot.traverse(o => { if (o.isMesh && !o.userData.isEditorHelper && o.visible) candidates.push(o); });
    const hits = _ray.intersectObjects(candidates, false);

    // Link mode — click target to wire to link source
    if (E.linkMode) {
      if (hits.length) {
        let obj = hits[0].object;
        while (obj.parent && obj.parent !== E.placedGroup) obj = obj.parent;
        if (obj !== E.linkSource) {
          const targetId = obj.userData.editorId;
          if (targetId !== undefined) {
            if (!E.linkSource.userData.links) E.linkSource.userData.links = [];
            if (!E.linkSource.userData.links.some(l => l.id === targetId)) {
              pushUndo();
              E.linkSource.userData.links.push({ id: targetId });
              markDirty();
            }
            renderLinksPanel(E.linkSource);
          }
          cancelLink();
          return;
        }
      }
      setStatus('Click a different object to link to it \u2014 Esc cancels');
      return;
    }

    // Face pick mode — click the selected object to pick a face
    if (E.facePickMode && E.selected) {
      const faceHits = _ray.intersectObject(E.selected, false);
      if (faceHits.length) {
        const hit = faceHits[0];
        const faceIdx = hit.face?.materialIndex ?? 0;
        applyFacePick(faceIdx);
      } else {
        setStatus('Click a face on the selected box - Esc cancels');
      }
      return;
    }

    // Pivot mode — click any surface to define pivot point
    if (E.pivotMode) {
      // Raycast against ALL placed meshes and the floor
      const allCandidates = [];
      E.placedGroup.traverse(o => { if (o.isMesh && !o.userData.isEditorHelper) allCandidates.push(o); });
      allCandidates.push(E.floorPlane);
      const pivotHits = _ray.intersectObjects(allCandidates, false);
      if (pivotHits.length) {
        applyPivot(pivotHits[0].point);
      } else {
        setStatus('Pivot mode — click any surface to set pivot (Esc cancels)');
      }
      return;
    }

    // Rope anchor attach mode — click any surface to set the endpoint
    if (E.ropeAnchorMode) {
      const allCandidates = [];
      E.placedGroup.traverse(o => { if (o.isMesh && !o.userData.isEditorHelper && o !== E.ropeAnchorSource) allCandidates.push(o); });
      allCandidates.push(E.floorPlane);
      const ropeHits = _ray.intersectObjects(allCandidates, false);
      if (ropeHits.length) {
        const hit = ropeHits[0];
        let hitObj = hit.object;
        while (hitObj.parent && hitObj.parent !== E.placedGroup) hitObj = hitObj.parent;
        if (hitObj === E.floorPlane) hitObj = null;
        applyRopeAnchor(hit.point, hitObj);
      } else {
        setStatus(`Rope End ${E.ropeAnchorMode} — click any surface to attach (Esc cancels)`);
      }
      return;
    }

    // Cut mode — click target to subtract cutter from it
    if (E.cutMode) {
      if (hits.length) {
        let obj = hits[0].object;
        while (obj.parent && obj.parent !== E.placedGroup) obj = obj.parent;
        if (obj !== E.cutSource) { performCut(obj); return; }
      }
      setStatus('Click a different object to cut into it \u2014 Esc cancels');
      return;
    }

    // Normal selection
    if (hits.length) {
      let obj = hits[0].object;
      // Walk up to the direct child of placedGroup OR groupPivot (whichever is immediate parent).
      while (obj.parent && obj.parent !== E.placedGroup && obj.parent !== E.groupPivot) obj = obj.parent;
      // If group mode is active and this object belongs to the active group, keep group mode
      // (i.e. the click is just acknowledging a group member — don't exit group mode).
      if (E.groupPivot && E.groupPivotMembers.includes(obj)) {
        // Stay in group mode; nothing to do
      } else {
        selectObj(obj);
      }
    } else {
      deselect();
    }
  });
}

// â”€â”€â”€ WASD camera pan â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function updateCameraPan(delta) {
  // Don't pan while typing in inputs
  if (document.activeElement?.tagName === 'INPUT') return;
  // Don't pan while Ctrl is held (avoid Ctrl+W/D/S/E triggering movement)
  if (E.keys['ControlLeft'] || E.keys['ControlRight']) return;
  const speed = E.panSpeed;  // Space/Shift handle up/down; no sprint modifier needed
  const fwd = new THREE.Vector3();
  E.camera.getWorldDirection(fwd); fwd.y = 0; fwd.normalize();
  const right = new THREE.Vector3().crossVectors(fwd, E.camera.up).normalize();
  const pan = (dir, s) => { E.camera.position.addScaledVector(dir, s); E.orbit.target.addScaledVector(dir, s); };

  if (E.keys['KeyA']) pan(right, -speed * delta);
  if (E.keys['KeyD']) pan(right,  speed * delta);
  if (E.keys['KeyW']) pan(fwd,    speed * delta);
  if (E.keys['KeyS']) pan(fwd,   -speed * delta);
  if (E.keys['Space'])      { E.camera.position.y += speed * delta; E.orbit.target.y += speed * delta; }
  if (E.keys['ShiftLeft'] || E.keys['ShiftRight']) { E.camera.position.y -= speed * delta; E.orbit.target.y -= speed * delta; }
}

// â”€â”€â”€ Animate â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function animate(now = 0) {
  requestAnimationFrame(animate);
  const delta = Math.min((now - E.lastTime) / 1000, 0.1);
  E.lastTime = now;

  updateCameraPan(delta);
  _updatePivotDot();
  // Keep player origin dot tracking camera XZ at ground level
  const originDot   = E.scene.getObjectByName('__playerOrigin__');
  const originCross = E.scene.getObjectByName('__playerOriginCross__');
  if (originDot || originCross) {
    const t = E.orbit.target;
    if (originDot)   originDot.position.copy(t);
    if (originCross) originCross.position.copy(t);
    const dist = E.camera.position.distanceTo(t);
    const s = dist * 0.04;
    if (originDot)   originDot.scale.setScalar(s);
    if (originCross) originCross.scale.setScalar(s);
  }
  if (E._modelEditorObj) _syncBoneMarkersToWorld();
  _updateSpawnCoords();
  E.orbit.update();
  E.renderer.render(E.scene, E.camera);
}

// â”€â”€â”€ Boot â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export function initEditor() { return init().catch(console.error); }


