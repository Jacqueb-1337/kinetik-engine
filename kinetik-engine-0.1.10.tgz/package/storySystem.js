import * as THREE from 'three';
import { gameState } from './globals.js';
import { onObjectStateAdvanced } from './stateManager.js';

const DEFAULT_OBJECTIVE = 'Explore the area.';

let _catalog = {};
let _defaultScene = null;
let _defaultObjective = DEFAULT_OBJECTIVE;
let _poiMeshes = new Map();
let _consumedPois = new Set();
let _dialogueSeen = new Set();
let _currentScene = null;
let _objectiveText = DEFAULT_OBJECTIVE;
let _objectiveSubtitle = '';
let _warble = 0;
let _hookRegistered = false;

function _flags() {
  const flags = gameState.flags || {};
  return flags.story ?? (flags.story = {});
}

function _ensureHud() {
  let el = document.getElementById('story-objective');
  if (!el) {
    const hud = document.querySelector('.hud') || document.body;
    el = document.createElement('div');
    el.id = 'story-objective';
    el.innerHTML = '<div class="story-objective-label">OBJECTIVE</div><div class="story-objective-text"></div><div class="story-objective-subtitle"></div>';
    hud.appendChild(el);
  }
  return el;
}

function _setObjective(text, subtitle = '') {
  _objectiveText = text || _defaultObjective;
  _objectiveSubtitle = subtitle || '';
  const el = _ensureHud();
  const textEl = el.querySelector('.story-objective-text');
  const subEl = el.querySelector('.story-objective-subtitle');
  if (textEl) textEl.textContent = _objectiveText;
  if (subEl) {
    subEl.textContent = _objectiveSubtitle;
    subEl.style.display = _objectiveSubtitle ? '' : 'none';
  }
}

function _applyIntensity(value) {
  _warble = Math.max(0, Math.min(1, value ?? 0));
  globalThis.__kinetikGameHooks?.setWarbleIntensity?.(_warble);
}

function _sceneDef(sceneId) {
  return _catalog?.[sceneId] || null;
}

function _applyScene(sceneId) {
  _currentScene = sceneId;
  const scene = _sceneDef(sceneId);
  if (!scene) return;
  _setObjective(scene.objective || _defaultObjective, scene.title || '');
  _applyIntensity(scene.intensity ?? 0);
  const flags = _flags();
  flags.scene = sceneId;
  flags.objective = scene.objective || _defaultObjective;
  flags.intensity = _warble;
}

function _meta(obj) {
  return obj?.userData?.storyPoi || obj?.userData?.storyBeat || null;
}

function _shouldShowPoi(obj) {
  const meta = _meta(obj);
  if (!meta) return false;
  if (meta.hidden) return false;
  if (meta.requiresFlags?.length) {
    const flags = _flags();
    for (const req of meta.requiresFlags) if (!flags[req]) return false;
  }
  if (meta.unlockFlags?.length) {
    const flags = _flags();
    if (!meta.unlockFlags.some(k => flags[k])) return false;
  }
  const id = String(meta.id || obj.userData.editorId || '');
  if (meta.oneShot && _consumedPois.has(id)) return false;
  return true;
}

function _poiMat() {
  return new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.92, depthWrite: false, toneMapped: false });
}

function _marker() {
  const g = new THREE.Group();
  const core = new THREE.Mesh(new THREE.SphereGeometry(0.045, 12, 12), _poiMat());
  const glow = new THREE.Mesh(new THREE.SphereGeometry(0.09, 12, 12), new THREE.MeshBasicMaterial({
    color: 0xbfd7ff, transparent: true, opacity: 0.18, depthWrite: false, toneMapped: false
  }));
  g.add(core, glow);
  g.userData._core = core;
  g.userData._glow = glow;
  g.renderOrder = 999;
  return g;
}

function _syncPois() {
  for (const obj of gameState.statefulObjects || []) {
    const ok = _shouldShowPoi(obj);
    let marker = _poiMeshes.get(obj);
    if (ok && !marker) {
      marker = _marker();
      marker.position.set(0, 0.95, 0);
      obj.add(marker);
      _poiMeshes.set(obj, marker);
    } else if (!ok && marker) {
      marker.removeFromParent();
      _poiMeshes.delete(obj);
    }
    marker = _poiMeshes.get(obj);
    if (!marker) continue;
    const t = performance.now() * 0.004 + (obj.userData.editorId || 0);
    const pulse = 1 + Math.sin(t) * 0.14;
    marker.scale.setScalar(Math.max(0.7, (obj.userData.storyPoi?.markerScale ?? 1) * pulse));
    const alpha = 0.6 + Math.max(0, Math.sin(t * 1.7)) * 0.3;
    if (marker.userData._core?.material) marker.userData._core.material.opacity = alpha;
    if (marker.userData._glow?.material) marker.userData._glow.material.opacity = alpha * 0.28;
  }
}

function _trigger(meta, obj) {
  if (!meta) return;
  const flags = _flags();
  const nodeId = meta.dialogueId || meta.storyId || meta.id || String(obj?.userData?.editorId ?? '');
  if (nodeId) _dialogueSeen.add(nodeId);
  if (meta.scene) _applyScene(meta.scene);
  if (meta.objective) _setObjective(meta.objective, meta.title || meta.scene || '');
  if (meta.intensity != null) _applyIntensity(meta.intensity);
  if (meta.setFlags) for (const [k, v] of Object.entries(meta.setFlags)) flags[k] = v;
  if (meta.unlockFlags?.length) for (const k of meta.unlockFlags) flags[k] = true;
  if (meta.oneShot && meta.id != null) _consumedPois.add(String(meta.id));
  if (meta.storyAction && _sceneDef(meta.storyAction)) _applyScene(meta.storyAction);
}

function _applyState(obj) {
  const meta = obj?.userData?.storyPoi;
  if (!meta) return;
  if ((obj.userData.currentState ?? 0) === 1) {
    _trigger(meta, obj);
    if (meta.oneShot) {
      obj.userData.noSelfInteract = true;
      obj.userData.stateInteractive = false;
    }
  }
}

export function configureStorySystem({ catalog = {}, defaultScene = null, defaultObjective = DEFAULT_OBJECTIVE } = {}) {
  _catalog = catalog || {};
  _defaultScene = defaultScene;
  _defaultObjective = defaultObjective || DEFAULT_OBJECTIVE;
}

export function initStorySystem() {
  if (!_hookRegistered) {
    _hookRegistered = true;
    onObjectStateAdvanced((editorId, stateIdx) => {
      const obj = (gameState.statefulObjects || []).find(o => String(o.userData.editorId) === String(editorId));
      if (!obj) return;
      obj.userData.currentState = stateIdx;
      _applyState(obj);
      if (obj.userData.storyBeat?.scene && stateIdx === 1) _applyScene(obj.userData.storyBeat.scene);
    });
  }
  _ensureHud();
  _setObjective(_defaultObjective);
  if (_defaultScene) _applyScene(_defaultScene);
}

export function registerStoryObject(obj, meta = {}) {
  if (!obj) return;
  obj.userData.storyPoi = meta;
  if (!obj.userData.states?.length) {
    obj.userData.states = [
      { interactLabel: meta.label || '[RIGHT CLICK] Inspect', interactiveEnabled: true, interactive: true },
      { interactLabel: meta.label || '[RIGHT CLICK] Inspect', interactiveEnabled: true, interactive: true },
    ];
    obj.userData.currentState = 0;
  }
  if (meta.scene && !_sceneDef(meta.scene)) {
    // no-op, game repo can define the catalog
  }
  _applyState(obj);
}

export function setStoryScene(sceneId) { _applyScene(sceneId); }
export function getStoryScene() { return _currentScene; }
export function setStoryObjective(text, subtitle = '') { _setObjective(text, subtitle); _flags().objective = text; }
export function setStoryIntensity(value) { _applyIntensity(value); }
export function getStoryIntensity() { return _warble; }
export function consumeStoryPoi(id) { if (id != null) { _consumedPois.add(String(id)); _syncPois(); } }
export function advanceStoryFromInteract(obj) { if (!obj?.userData?.storyPoi) return false; _trigger(obj.userData.storyPoi, obj); if (obj.userData.storyPoi.oneShot) consumeStoryPoi(obj.userData.storyPoi.id); return true; }

export function getStorySaveData() {
  return {
    currentScene: _currentScene,
    objectiveText: _objectiveText,
    objectiveSubtitle: _objectiveSubtitle,
    intensity: _warble,
    consumedPois: [..._consumedPois],
    dialogueSeen: [..._dialogueSeen],
    flags: { ...(gameState.flags?.story || {}) },
  };
}

export function restoreStorySaveData(data) {
  if (!data) return;
  _currentScene = data.currentScene ?? _currentScene;
  _consumedPois = new Set((data.consumedPois || []).map(String));
  _dialogueSeen = new Set((data.dialogueSeen || []).map(String));
  _objectiveText = data.objectiveText || _objectiveText;
  _objectiveSubtitle = data.objectiveSubtitle || '';
  _ensureHud();
  _setObjective(_objectiveText, _objectiveSubtitle);
  _applyIntensity(data.intensity ?? _warble);
  if (!gameState.flags) gameState.flags = {};
  gameState.flags.story = { ...(data.flags || {}) };
  _syncPois();
}

export function refreshStorySystem() { _syncPois(); }
export function updateStorySystem() { _syncPois(); }
